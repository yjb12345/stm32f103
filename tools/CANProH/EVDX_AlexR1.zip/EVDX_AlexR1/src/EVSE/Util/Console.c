/*
 * Console.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : Console.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Debug Uart Console Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

Console.c is a module for checking debugging messages.
It is made of a ring buffer structure.

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "Console.h"
#include <string.h>

#define MESSAGEQ 0

#define MAX_UART_BUF 4096
typedef struct
{
  uint8_t Buff[MAX_UART_BUF];
  uint16_t Head;
  uint16_t Tail;
  uint16_t Count;
} ConsoleBuffer;

#if 1
// alex marked
/* Private variables ---------------------------------------------------------*/
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif
#endif
/* Private variables ---------------------------------------------------------*/
extern UART_HandleTypeDef huart1;
// UART_HandleTypeDef ConsoleHandle;
ConsoleBuffer ConsoleTxBuffer;
ConsoleBuffer ConsoleRxBuffer;
#ifdef _GRIDWIZ_CONSOLE_USED_
// alex mareked, 원래 사용을 않하네.
// SemaphoreHandle_t xSemaphore = NULL;
//---------------------------------
#endif
uint8_t rxCharacter;
uint8_t prevrxCharacter;

// #include "uart.h"
extern osThreadId ConsoleTaskId;
/* Private function prototypes -----------------------------------------------*/
osMessageQDef(ConsoleMQ, MAX_UART_BUF, char);

#ifdef _ORGINAL_
PUTCHAR_PROTOTYPE
{
  if (osKernelRunning())
  {

    ConsoleTxBuffer.Buff[ConsoleTxBuffer.Head] = ch;
    ConsoleTxBuffer.Head = (ConsoleTxBuffer.Head + 1) % MAX_UART_BUF;
    ConsoleTxBuffer.Count++;

    if (ConsoleTxBuffer.Count >= MAX_UART_BUF)
    {
      ConsoleTxBuffer.Count = MAX_UART_BUF;
      ConsoleTxBuffer.Head = ConsoleTxBuffer.Tail;
    }

#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ConsoleTaskId, 0x0001);
#else
    osSignalSet(ConsoleTaskId, 0x0001);
#endif
  }
  else
  {
    HAL_NVIC_DisableIRQ(USART1_IRQn);
    // HAL_UART_Transmit(&ConsoleHandle, (uint8_t *)&ch, 1, 0xFFFF);
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  }
  return ch;
}
#else

PUTCHAR_PROTOTYPE
{
  // osKernelGetState

#ifdef _ALEX_CMSIS_V2_
  if (osKernelGetState() == osKernelRunning)
#else
  if (osKernelRunning())
    if (osKernelGetState() == osKernelRunning)
#endif

  {
#if 0
    ConsoleTxBuffer.Buff[ConsoleTxBuffer.Head] = ch;
    ConsoleTxBuffer.Head = (ConsoleTxBuffer.Head + 1) % MAX_UART_BUF;
    ConsoleTxBuffer.Count++;

    if (ConsoleTxBuffer.Count >= MAX_UART_BUF)
    {
      ConsoleTxBuffer.Count = MAX_UART_BUF;
      ConsoleTxBuffer.Head = ConsoleTxBuffer.Tail;
    }
    // osSignalSet(ConsoleTaskId, 0x0001);
    //HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF); // ALEX ADDED
#else
    // HAL_NVIC_DisableIRQ(USART1_IRQn);
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
    // HAL_NVIC_EnableIRQ(USART1_IRQn);
#endif
  }

  else
  {
    // HAL_NVIC_DisableIRQ(USART1_IRQn);
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
    // HAL_NVIC_EnableIRQ(USART1_IRQn);
  }
  return ch;
}
#endif
/*
 *                  osKernelGetState
 osKernelState_t    osKernelGetState (void) {
  osKernelState_t state;

  switch (xTaskGetSchedulerState()) {
    case taskSCHEDULER_RUNNING:
      state = osKernelRunning;
 */
void GW_ConsoleInit()
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  printf("GW_ConsoleInit called\n\r");
  HAL_UART_Receive_IT(&huart1, &rxCharacter, 1); // alex moved from ConsoleTask.
#if 0
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  // already done : bspInit->MX_USART1_UART_Init(소프트웨어 설정)
  //                HAL_UART_Init-> HAL_UART_MspInit() // 물리적인 포트 설정
  ConsoleHandle.Instance = GW_CONSOLE_INSTANCE;
  ConsoleHandle.Init.BaudRate = GW_CONSOLE_BAUDRATE;
  ConsoleHandle.Init.WordLength = UART_WORDLENGTH_8B;
  ConsoleHandle.Init.StopBits = UART_STOPBITS_1;
  ConsoleHandle.Init.Parity = UART_PARITY_NONE;
  ConsoleHandle.Init.Mode = UART_MODE_TX_RX;
  ConsoleHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  ConsoleHandle.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&ConsoleHandle) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  // CubeMX making bug, hard coding!

  __HAL_RCC_USART1_CLK_ENABLE();

  __HAL_RCC_GPIOA_CLK_ENABLE();

  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
#endif

#endif
}

void GW_ConsoleDeInit(void)
{
#ifndef _GRIDWIZ_CONSOLE_USED_
  printf("GW_ConsoleDeInit is not used\n\r");
#else
  ;
#endif
}

void GW_Console_NVIC_Init(void)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  HAL_NVIC_SetPriority(GW_CONSOLE_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(GW_CONSOLE_IRQn);
#endif
}

void GW_Console_NVIC_DeInit(void)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  HAL_NVIC_DisableIRQ(GW_CONSOLE_IRQn);
#endif
}

void GW_ConsoleRxNotifyActivation(void)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  //__HAL_UART_ENABLE_IT(&ConsoleHandle, UART_IT_RXNE);
  __HAL_UART_ENABLE_IT(&huart1, UART_IT_RXNE);

#endif
}

void GW_ConsoleRxNotifyDeactivation(void)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  // printf("GW_ConsoleRxNotifyDeactivation is not used\n\r");
  //__HAL_UART_DISABLE_IT(&ConsoleHandle, UART_IT_RXNE);
  __HAL_UART_DISABLE_IT(&huart1, UART_IT_RXNE);

#endif
}

uint8_t GW_ConsoleGetch(void)
{
#ifdef _GRIDWIZ_CONSOLE_USED_

  uint8_t ch;

  if (ConsoleRxBuffer.Count)
  {
    ch = ConsoleRxBuffer.Buff[ConsoleRxBuffer.Tail];
    ConsoleRxBuffer.Count--;
    ConsoleRxBuffer.Tail = (ConsoleRxBuffer.Tail + 1) % MAX_UART_BUF;
  }

  return ch;
#else
  printf("alex ==>GW_ConsoleGetch is not used\n\r");
  return 0;
#endif
}

void GW_ConsolePutch(uint8_t ch)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  ConsoleRxBuffer.Buff[ConsoleRxBuffer.Head] = ch;
  ConsoleRxBuffer.Head = (ConsoleRxBuffer.Head + 1) % MAX_UART_BUF;
  ConsoleRxBuffer.Count++;

  if (ConsoleRxBuffer.Count >= MAX_UART_BUF)
  {
    ConsoleRxBuffer.Count = MAX_UART_BUF;
    ConsoleRxBuffer.Head = ConsoleRxBuffer.Tail;
  }
#else
  printf("alex=> GW_ConsolePutch is not used\n\r");
#endif
}

// #include "bsp.h"
extern UART_HandleTypeDef huart1;
void ConsoleTask(void const *argument)
{

#ifdef _GRIDWIZ_CONSOLE_USED_
  char ch;
  // xSemaphore = xSemaphoreCreateMutex(); // alex marked

  // HAL_UART_Receive_IT(&ConsoleHandle, &rxCharacter, 1);
  // HAL_UART_Receive_IT(&huart1, &rxCharacter, 1); // 여기 있으면 동작하지 않을듯...

  for (;;)
  {
    // for UART RX
    if (rxCharacter)
    {
      // printf("rx=%c  prev=%c\n\r", rxCharacter, prevrxCharacter);
      GW_ConsoleRxHandler();
      prevrxCharacter = rxCharacter;
      GW_EventNotify(GW_EVENT_KEY_PRESSED); // alex : 나중에 GW_ConsoleRxHandler()으로 옮기자.{
      rxCharacter = 0;
    }
    // for UART TX
    while (ConsoleTxBuffer.Count)
    {
      ch = ConsoleTxBuffer.Buff[ConsoleTxBuffer.Tail];
      ConsoleTxBuffer.Count--;
      ConsoleTxBuffer.Tail = (ConsoleTxBuffer.Tail + 1) % MAX_UART_BUF;
      HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
    }
    osDelay(1);
  }

#else
  char ch;
  // xSemaphore = xSemaphoreCreateMutex();
  // HAL_UART_Receive_IT(&ConsoleHandle, &rxCharacter, 1);

#ifdef _THREAD_TEST_ONLY_
  printf("ConsoleTask  start\n\r");
  for (;;)
  {
    printf("ConsoleTask runnint\n\r");
    osDelay(3000);
  }
#endif
  for (;;)
  {
    // osSignalWait(0x0001, 10);
    osDelay(1);
    while (ConsoleTxBuffer.Count)
    {
      ch = ConsoleTxBuffer.Buff[ConsoleTxBuffer.Tail];
      ConsoleTxBuffer.Count--;
      ConsoleTxBuffer.Tail = (ConsoleTxBuffer.Tail + 1) % MAX_UART_BUF;

      // HAL_NVIC_DisableIRQ(USART1_IRQn);
      // HAL_UART_Transmit(&ConsoleHandle, (uint8_t *)&ch, 1, 0xFFFF);
      // HAL_NVIC_EnableIRQ(USART1_IRQn);
      HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
    }
  }
#endif
}

void _Error_Handler(char *file, int line)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
  printf("_Error_Handler called\n\r");
  TRACE_ERROR("file:[%s], line:[%d]", file, line);
  while (1)
  {
  }
#endif
}

/* Callback Function ---------------------------------------------------------*/
void GW_ConsoleRxHandler(void)
{
#ifdef _GRIDWIZ_CONSOLE_USED_
#if _ORIGINAL_CODE
  // alex marked below codes, 새 칩에는 DR 레지스트가 없다.=> Compile error
  uint8_t ch;
  ch = ConsoleHandle.Instance->DR;
  ConsoleRxBuffer.Buff[ConsoleRxBuffer.Head] = ch;
#else
  // rxCharacter를 바로 사용한다.

  ConsoleRxBuffer.Buff[ConsoleRxBuffer.Head] = rxCharacter ? rxCharacter : 'Z';
#endif
  // printf("GW_ConsoleRxHandler,rxCharacter=%c\n\r", rxCharacter);
  ConsoleRxBuffer.Head = (ConsoleRxBuffer.Head + 1) % MAX_UART_BUF;
  ConsoleRxBuffer.Count++;
  if (ConsoleRxBuffer.Count >= MAX_UART_BUF)
  {
    ConsoleRxBuffer.Count = MAX_UART_BUF;
    ConsoleRxBuffer.Head = ConsoleRxBuffer.Tail;
  }
#endif
}

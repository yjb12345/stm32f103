/*
 * Tools.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : Tools.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Secc Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

Tools.c is a module that organizes util codes used in EVSEC sample codes.

******************************************************************************
*/

#include "Tools.h"
#include <math.h>

TickType_t diffTick(TickType_t startTick, TickType_t endTick)
{
    TickType_t diffTick;

    if (startTick <= endTick)
    {
        diffTick = endTick - startTick;
    }
    else // Overflow
    {
#if configUSE_16_BIT_TICKS
        diffTick = (uint6_t)0xffff - endTick + startTick;
#else
        diffTick = (uint32_t)0xffffffff - endTick + startTick;
#endif
    }
    return diffTick;
}

#include "cmsis_os2.h"
uint32_t xTaskAlexGetTickCount()
{
    // printf("x=%0x\n", 1 << 2);
    return osKernelGetTickCount();
}

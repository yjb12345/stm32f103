/*
 * Console.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_UTIL_CONSOLE_H_
#define AP_UTIL_CONSOLE_H_

#include <stdio.h>
#include "EventControl.h"
#include "EvseConfig.h"

#define TRACE_MSG(fmt, ...) printf(fmt "\r\n", ##__VA_ARGS__)
#define TRACE_COLOR(COLOR_CODE, fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", COLOR_CODE, ##__VA_ARGS__)

#define TRACE_COLOR_RED(fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", ANSI_COLOR_RED, ##__VA_ARGS__)
#define TRACE_COLOR_GREEN(fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", ANSI_COLOR_GREEN, ##__VA_ARGS__)
#define TRACE_COLOR_YELLOW(fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", ANSI_COLOR_YELLOW, ##__VA_ARGS__)
#define TRACE_COLOR_BLUE(fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", ANSI_COLOR_BLUE, ##__VA_ARGS__)
#define TRACE_COLOR_MAGENTA(fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", ANSI_COLOR_MAGENTA, ##__VA_ARGS__)
#define TRACE_COLOR_CYAN(fmt, ...) printf("\033[%xm" fmt "\033[m\r\n", ANSI_COLOT_CYAN, ##__VA_ARGS__)

#define TRACE_DEBUG(fmt, ...) TRACE_MSG("%09d DEBUG " fmt, xTaskAlexGetTickCount(), ##__VA_ARGS__)
#define TRACE_INFO(fmt, ...) TRACE_COLOR_GREEN("%09d INFO  " fmt, xTaskAlexGetTickCount(), ##__VA_ARGS__)
#define TRACE_TRACE(fmt, ...) TRACE_COLOR_YELLOW("%09d TRACE " fmt, xTaskAlexGetTickCount(), ##__VA_ARGS__)
#define TRACE_WARN(fmt, ...) TRACE_COLOR_CYAN("%09d WARN  " fmt, xTaskAlexGetTickCount(), ##__VA_ARGS__)
#define TRACE_ERROR(fmt, ...) TRACE_COLOR_RED("%09d ERROR " fmt, xTaskAlexGetTickCount(), ##__VA_ARGS__)

#define TRACE_MSG_WITHOUT_NL(fmt, ...) printf(fmt, ##__VA_ARGS__)
#define TRACE_COLOR_WITHOUT_NL(COLOR_CODE, fmt, ...) printf("\033[%xm" fmt "\033[m", COLOR_CODE, ##__VA_ARGS__)
#define TRACE_COLOR_RED_WITHOUT_NL(fmt, ...) printf("\033[%xm" fmt "\033[m", ANSI_COLOR_RED, ##__VA_ARGS__)
#define TRACE_COLOR_GREEN_WITHOUT_NL(fmt, ...) printf("\033[%xm" fmt "\033[m", ANSI_COLOR_GREEN, ##__VA_ARGS__)
#define TRACE_COLOR_YELLOW_WITHOUT_NL(fmt, ...) printf("\033[%xm" fmt "\033[m", ANSI_COLOR_YELLOW, ##__VA_ARGS__)
#define TRACE_COLOR_BLUE_WITHOUT_NL(fmt, ...) printf("\033[%xm" fmt "\033[m", ANSI_COLOR_BLUE, ##__VA_ARGS__)
#define TRACE_COLOR_MAGENTA_WITHOUT_NL(fmt, ...) printf("\033[%xm" fmt "\033[m", ANSI_COLOR_MAGENTA, ##__VA_ARGS__)
#define TRACE_COLOR_CYAN_WITHOUT_NL(fmt, ...) printf("\033[%xm" fmt "\033[m", ANSI_COLOT_CYAN, ##__VA_ARGS__)

#define TRACE_DEBUG_WITHOUT_NL(fmt, ...) TRACE_MSG_WITHOUT_NL(fmt, ##__VA_ARGS__)
#define TRACE_INFO_WITHOUT_NL(fmt, ...) TRACE_COLOR_GREEN(fmt, ##__VA_ARGS__)
#define TRACE_WARN_WITHOUT_NL(fmt, ...) TRACE_COLOR_CYAN(fmt, ##__VA_ARGS__)
#define TRACE_ERROR_WITHOUT_NL(fmt, ...) TRACE_COLOR_RED(fmt, ##__VA_ARGS__)

void GW_ConsoleInit();
void GW_ConsoleDeInit();
void GW_Console_NVIC_Init();
void GW_Console_NVIC_DeInit();

void GW_ConsoleRxNotifyActivation(void);
void GW_ConsoleRxHandler(void);

uint8_t GW_ConsoleGetch(void);
void GW_ConsolePutch(uint8_t ch);

void ConsoleTask(void const *argument);

void _Error_Handler(char *file, int line);
#ifdef _GRIDWIZ_CONSOLE_USED_
// extern SemaphoreHandle_t xSemaphore;  // Fixme : alex marked
#endif

#endif /* AP_UTIL_CONSOLE_H_ */

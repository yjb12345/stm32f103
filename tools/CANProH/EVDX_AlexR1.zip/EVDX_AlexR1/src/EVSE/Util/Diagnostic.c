/*
 * Diagnostic.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : Diagnostic.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Charger Context Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

Diagnostic.c is a module for checking the diagnostic data of the charger.
Defines console debugging messages.

******************************************************************************
*/

#include "Diagnostic.h"
#include "EvseContext.h"
#include "PowerModule.h"
// #include "IsolationMonitor.h"
#include "Peppermint4xCan.h"
#include "Tools.h"

#include <math.h>

extern ChargerContext ChargerCtx;

static const char *SeccStateLegacyString[];
static const char *EvseProcessingString[];
static const char *EvseIsolationString[];
static const char *EvseIsolationMonitorString[];
static const char *EvseRenegotiationString[];
static const char *EvseChargingControlString[];
static const char *EvErrorString[];
static const char *SeccErrorString(int8_t code);
static const char *TlsErrorString(int8_t code);
static const char *SeccEstablishedInfoString[];
static const char *SeccSaInitResultString[];
static const char *SeccSaCommString(uint8_t code);
static const char *SeccPncReadyString[];
static const char *SeccEvServiceSelectionChargingProtocolString(uint8_t code);
static const char *SeccEvServiceSelectionPaymentOptionString(uint8_t code);
static const char *SeccEvServiceSelectionEnergyTransferModeString(uint8_t code);

#define _NO_TRACE_FUNC_BY_ALEX
void ChargerPrintDiagInfo()
{
  // #ifndef _NO_TRACE_FUNC_BY_ALEX

  TRACE_WARN("================== DIAGNOTIC INFOMATION CAPTURE ==============");
  TRACE_WARN("------------------ EVSE STATUS ------------------------------");
  TRACE_WARN("SECC STATE TRACE   [%s]->*[%s]*->[%s]",
             SeccStateString(ChargerCtx.PrevState), SeccStateString(ChargerCtx.CurrState), SeccStateString(ChargerCtx.NextState));
  TRACE_WARN("EVSE CHARGING CTL  [%s]", EvseChargingControlString[ChargerCtx.EVSE_STATUS.CHARGING_CONTROL]);
  TRACE_WARN("EVSE ISOLATION     [%s]", EvseIsolationString[ChargerCtx.EVSE_STATUS.EVSE_ISOLATION_STATUS]);
  TRACE_WARN("EVSE AUTH EIM      [%s]", EvseProcessingString[ChargerCtx.EVSE_STATUS.EVSE_PROCESSING_AUTH_EIM]);
  TRACE_WARN("EVSE CPD           [%s]", EvseProcessingString[ChargerCtx.EVSE_STATUS.EVSE_PROCESSING_CPD]);
  TRACE_WARN("EVSE CABLE CHECK   [%s]", EvseProcessingString[ChargerCtx.EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK]);
  TRACE_WARN("EVSE ISOLATION MON [%s]", EvseIsolationMonitorString[ChargerCtx.EVSE_STATUS.ISOLATION_MONITORING_ACTIVE]);
  TRACE_WARN("EVSE RENEGOTIATION [%s]", EvseRenegotiationString[ChargerCtx.EVSE_STATUS.TRIGGER_RE_NEGOTIATION]);
  TRACE_WARN("------------------ EVSE PARAMETER ---------------------------");
  TRACE_WARN("EVSE PRESENT V     [%5.1f]", ChargerGetPresentVoltage() / pow(10, 3));
  TRACE_WARN("EVSE PRESENT I     [%5.1f]", ChargerGetPresentCurrent() / pow(10, 3));
  TRACE_WARN("MAX VOLTAGE LIMIT  [%5.1f]", ChargerGetMaximumVoltageLimit() / pow(10, 3));
  TRACE_WARN("MAX CURRENT LIMIT  [%5.1f]", ChargerGetMaximumCurrentLimit() / pow(10, 3));
  TRACE_WARN("MAX POWER LIMIT    [%5.1f]", ChargerGetMaximumPowerLimit() / pow(10, 3));
  TRACE_WARN("DC OUTPUT          [%s]", GW_PowerModuleGetOutputStatus() ? "Off" : "On");
  uint32_t mV, mA;
  GW_PowerModuleGetTotalOutput(&mV, &mA);
  TRACE_WARN("DC OUTPUT V        [%5.1f]", mV / pow(10, 3));
  TRACE_WARN("DC OUTPUT I        [%5.1f]", mA / pow(10, 3));
  TRACE_WARN("------------------ SECC STATUS ------------------------------");
  TRACE_WARN("SECC VERSION       [%d.%d.%d]", ChargerCtx.SECC_STATUS_LEGACY.SECC_VERSION_MAJOR, ChargerCtx.SECC_STATUS_LEGACY.SECC_VERSION_MINOR, ChargerCtx.SECC_STATUS_LEGACY.SECC_VERSION_PATCH);
  TRACE_WARN("SECC STATUS(legacy)[%s]", SeccStateLegacyString[ChargerCtx.SECC_STATUS_LEGACY.SECC_STATUS_CODE_LEGACY]);
  TRACE_WARN("SECC EV ERROR      [%s]", EvErrorString[ChargerCtx.SECC_STATUS_LEGACY.EV_ERROR_CODE]);
  TRACE_WARN("SECC ERROR         [%s]", SeccErrorString(ChargerCtx.SECC_STATUS_LEGACY.SECC_ERROR_CODE));
  TRACE_WARN("SECC PnC READY     [%s]", SeccPncReadyString[ChargerCtx.SECC_STATUS_LEGACY.PNC_READY]);
  TRACE_WARN("SECC CP OSCILLATOR [%s]", ChargerCtx.SECC_CP_PP_STATUS.CP_OSCILLATOR ? "ON" : "OFF");
  TRACE_WARN("SECC CP VOLT       [%5.1f]", (float)(ChargerGetCpVoltage() / pow(10, 3)));
  TRACE_WARN("SECC HPGP LINK     [%s]", ChargerCtx.SECC_CP_PP_STATUS.HPGP_LINK_STATUS ? "UP" : "DOWN");
  TRACE_WARN("SECC TLS ERROR ALT [%s]", TlsErrorString(ChargerCtx.SECC_CP_PP_STATUS.TLS_ERROR_ALERT));
  TRACE_WARN("------------------ EV SERVICE SELECTION ---------------------");
  TRACE_WARN("CHARGING PROTOCOL  [%s]", SeccEvServiceSelectionChargingProtocolString(ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_CHARGING_PROTOCOL));
  TRACE_WARN("PAYMENT OPTION     [%s]", SeccEvServiceSelectionPaymentOptionString(ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_PAYMENT_OPTION));
  TRACE_WARN("EV CHARGING        [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_SERVICE_EV_CHARGING ? "Selected" : "Not Selected");
  TRACE_WARN("INTERNET           [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_SERVICE_INTERNET ? "Selected" : "Not Selected");
  TRACE_WARN("CONTRACT CERT      [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_SERVICE_CONTRACT_CERT ? "Selected" : "Not Selected");
  TRACE_WARN("OTHER CUSTOM       [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_SERVICE_OTHER_CUSTOM ? "Selected" : "Not Selected");
  TRACE_WARN("HPC1               [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_SERVICE_HPC1 ? "Selected" : "Not Selected");
  TRACE_WARN("CONT SERV INSTALL  [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_CONTRACT_SERVICE_INSTALLATION ? "Selected" : "Not Selected");
  TRACE_WARN("CONT SERV UPDATE   [%s]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_CONTRACT_SERVICE_UPDATE ? "Selected" : "Not Selected");
  TRACE_WARN("ENERGY TRANS MODE  [%s]", SeccEvServiceSelectionEnergyTransferModeString(ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_ENERGY_TRANSFER_MODE));
  TRACE_WARN("SA SCHED TUPLE ID  [%02d]", ChargerCtx.SECC_EV_SERVICE_SELECTION.SELECTED_SA_SCHEDULE_TUPLE_ID);
  TRACE_WARN("------------------ SECC PnC STATUS --------------------------");
  TRACE_WARN("SECC STATUS        [%s]", SeccStateString(ChargerCtx.SECC_STATUS.SECC_STATUS_CODE));
  TRACE_WARN("SECC ESTABLISHED   [%s]", SeccEstablishedInfoString[ChargerCtx.SECC_STATUS.SECC_ESTABLISHED_INFO]);
  TRACE_WARN("------------------ SECC SA AGENT INFO -----------------------");
  TRACE_WARN("SECC IP            [%d.%d.%d.%d]", ChargerCtx.SECC_IP_STATUS.SECC_IP_ADDR_1, ChargerCtx.SECC_IP_STATUS.SECC_IP_ADDR_2, ChargerCtx.SECC_IP_STATUS.SECC_IP_ADDR_3, ChargerCtx.SECC_IP_STATUS.SECC_IP_ADDR_4);
  TRACE_WARN("INIT RESULT        [%s]", SeccSaInitResultString[ChargerCtx.SECC_SA_COMM_STATUS.SA_AGENT_INIT_RESULT]);
  TRACE_WARN("INIT DETAILS       [%s]", SeccSaCommString(ChargerCtx.SECC_SA_COMM_STATUS.SA_AGENT_INIT_DETAILS));
  TRACE_WARN("CERT INST DETAILS  [%s]", SeccSaCommString(ChargerCtx.SECC_SA_COMM_STATUS.SA_AGENT_CERT_INSTALLATION_DETAILS));
  TRACE_WARN("CERT UPDA DETAILS  [%s]", SeccSaCommString(ChargerCtx.SECC_SA_COMM_STATUS.SA_AGENT_CERT_UPDATE_DETAILS));
  TRACE_WARN("AUTH RESP DETAILS  [%s]", SeccSaCommString(ChargerCtx.SECC_SA_COMM_STATUS.SA_AGENT_AUTHORIZE_RESP_DETAILS));
  TRACE_WARN("------------------ CHARGING INFO ----------------------------");
  TRACE_WARN("CHARGING START     [%d]", ChargerCtx.StartChargingTime);
  TRACE_WARN("CHARGING END       [%d]", ChargerCtx.EndChargingTime);
  TRACE_WARN("=============================================================");
  // #endif
}

void ChargerPrintTerminationReason()
{
#ifndef _NO_TRACE_FUNC_BY_ALEX
  TRACE_WARN("== DIAGNOTIC INFOMATION =====================================");
  TRACE_WARN(" %s TERMINATION", SeccStateString(ChargerCtx.PrevState));
  if (ChargerCtx.EVSE_STATUS.CHARGING_CONTROL == CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP)
  {
    TRACE_WARN(" REASON: EVSE EMERGENCY STOP");
  }
  else if (ChargerCtx.EVSE_STATUS.CHARGING_CONTROL == CHARGING_CTRL_EVSE_INITIATED_NORMAL_STOP)
  {
    TRACE_WARN(" REASON: EVSE NORMAL STOP");
  }
  else
  {
    TRACE_WARN(" REASON: EV STOP");
  }

  TRACE_WARN(" SECC ERROR [%02d]", ChargerCtx.SECC_STATUS_LEGACY.SECC_ERROR_CODE);
  TRACE_WARN(" EV   ERROR [%02d]", ChargerCtx.SECC_STATUS_LEGACY.EV_ERROR_CODE);
  TRACE_WARN("-------------------------------------------------------------");
  TRACE_WARN(" ELAPSED TIME      [%d]", diffTick(ChargerCtx.StartChargingTime, ChargerCtx.EndChargingTime));
  TRACE_WARN("=============================================================");
#endif
}
void ChargerPrintChargeParamDiscoveryInfo()
{
#ifndef _NO_TRACE_FUNC_BY_ALEX
  TRACE_INFO("EVSE MAX VOLTAGE LIMIT  [%5.1f]", ChargerGetMaximumVoltageLimit() / pow(10, 3));
  TRACE_INFO("EVSE MAX CURRENT LIMIT  [%5.1f]", ChargerGetMaximumCurrentLimit() / pow(10, 3));
  TRACE_INFO("EV   MAX VOLTAGE LIMIT  [%5.1f]", ChargerGetEvMaximumVoltageLimit() / pow(10, 3));
  TRACE_INFO("EV   MAX CURRENT LIMIT  [%5.1f]", ChargerGetEvMaximumCurrentLimit() / pow(10, 3));
  TRACE_INFO("EV   SOC                [%d]", ChargerCtx.SECC_EV_SOC_RELATED.EVSOC);
  TRACE_INFO("EV   FULL SOC           [%d]", ChargerCtx.SECC_EV_SOC_RELATED.FULLSOC);
  TRACE_INFO("EV   BULK SOC           [%d]", ChargerCtx.SECC_EV_SOC_RELATED.BULKSOC);
#endif
}

char *ChargerPrintEvseIsolationStatus(unsigned value)
{
  if (value == 0)
    return "INVALID";
  else if (value == 1)
    return "VAILD";
  else if (value == 2)
    return "WARING";
  else if (value == 3)
    return "FAULT";
  else
    return "NT";
}
void ChargerPrintCableCheckInfo()
{
  TRACE_INFO("CABLECHECK: V:[%5.1f][%5.1f][%5.1f] I:[%5.1f][%5.1f][%5.1f] CP:[%5.1f]",
             ChargerGetCableCheckVoltage() / pow(10, 3),
             ChargerGetEvMaximumVoltageLimit() / pow(10, 3),
             ChargerGetPresentVoltage() / pow(10, 3),
             ChargerGetCableCheckCurrent() / pow(10, 3),
             ChargerGetEvMaximumCurrentLimit() / pow(10, 3),
             ChargerGetPresentCurrent() / pow(10, 3),
             ChargerGetCpVoltage() / pow(10, 3));
}

void ChargerPrintCableCheckInfoWithADC(uint32_t dcType, double voltage)
{
  TRACE_INFO("CABLECHECK: V:[%5.1f][%5.1f] I:[%5.1f][%5.1f] CP:[%5.1f] DC%c:[%5.1f]",
             ChargerGetCableCheckVoltage() / pow(10, 3),
             ChargerGetPresentVoltage() / pow(10, 3),
             ChargerGetCableCheckCurrent() / pow(10, 3),
             ChargerGetPresentCurrent() / pow(10, 3),
             ChargerGetCpVoltage() / pow(10, 3),
             !dcType ? '+' : '-', voltage);
}

void ChargerPrintPreChargeInfo()
{
  TRACE_INFO("PRECHARGE: V:[%5.1f][%5.1f] I:[%5.1f][%5.1f] CP:[%5.1f] IS[%7s]",
             ChargerGetEvTargetVoltage() / pow(10, 3),
             ChargerGetPresentVoltage() / pow(10, 3),
             ChargerGetEvTargetCurrent() / pow(10, 3),
             ChargerGetPresentCurrent() / pow(10, 3),
             ChargerGetCpVoltage() / pow(10, 3),
             ChargerPrintEvseIsolationStatus(ChargerGetEvseIsolationStatus()));
}

void ChargerPrintChargingInfo()
{
#ifndef _NO_TRACE_FUNC_BY_ALEX
  TRACE_INFO("CHARGING: V:[%5.1f][%5.1f] I:[%5.1f][%5.1f] CP:[%5.1f] SOC:[%3d] REMAINING:[%4d] IS[%7s]",
             ChargerGetEvTargetVoltage() / pow(10, 3),
             ChargerGetPresentVoltage() / pow(10, 3),
             ChargerGetEvTargetCurrent() / pow(10, 3),
             ChargerGetPresentCurrent() / pow(10, 3),
             ChargerGetCpVoltage() / pow(10, 3),
             ChargerCtx.SECC_EV_SOC_RELATED.EVSOC,
             ChargerCtx.SECC_EV_SOC_RELATED.REMAINING_TIME_TO_FULLSOC * 10 / 60,
             ChargerPrintEvseIsolationStatus(ChargerGetEvseIsolationStatus()));
#endif
}

void ChargerPrintRenegoInfo()
{
  TRACE_INFO("RENEGOCIATION: V:[%5.1f][%5.1f] I:[%5.1f][%5.1f] CP:[%5.1f]",
             ChargerGetEvTargetVoltage() / pow(10, 3),
             ChargerGetPresentVoltage() / pow(10, 3),
             ChargerGetEvTargetCurrent() / pow(10, 3),
             ChargerGetPresentCurrent() / pow(10, 3),
             ChargerGetCpVoltage() / pow(10, 3));
}

void ChargerPrintTerminationInfo()
{

  TRACE_INFO("TERMINATION: SECC[%03d] STATUS[%02d] ERR[%02d] V:[%5.1f] I:[%5.1f] CP:[%5.1f]",
             ChargerCtx.SECC_STATUS_LEGACY.SECC_HEARBEAT,
             ChargerCtx.SECC_STATUS_LEGACY.SECC_STATUS_CODE_LEGACY,
             ChargerCtx.SECC_STATUS_LEGACY.SECC_ERROR_CODE,
             ChargerGetPresentVoltage() / pow(10, 3),
             ChargerGetPresentCurrent() / pow(10, 3),
             ChargerGetCpVoltage() / pow(10, 3));
}

static const char *SeccStateLegacyString[] =
    {
        "CHARGE_STATE_IDLE_WAIT",
        "CHARGE_STATE_IDLE",
        "CHARGE_STATE_READY",
        "CHARGE_STATE_LOW_LEVEL_COMM",
        "CHARGE_STATE_HIGH_LEVEL_COMM",
        "CHARGE_STATE_AUTHENTICATION",
        "CHARGE_STATE_CHARGE_PARAMETER_DISCOVERY",
        "CHARGE_STATE_CABLE_CHECK",
        "CHARGE_STATE_PRE_CHARGE",
        "CHARGE_STATE_CHARGING",
        "CHARGE_STATE_RENEGO",
        "CHARGE_STATE_EV_INIT_STOP_CHARGING",
        "CHARGE_STATE_EVSE_INIT_STOP_CHARGING",
        "CHARGE_STATE_PAUSE",
        "CHARGE_STATE_TERMINATE",
        "CHARGE_STATE_CERTIFICATE_INSTALLATION",
        "CHARGE_STATE_CERTIFICATE_UPDATE",
        "CHARGE_STATE_ERROR",
};

static const char *EvseProcessingString[] =
    {
        "Ongoing",
        "Finished"};

static const char *EvseChargingControlString[] =
    {
        "NONE",
        "Initialize PPMT",
        "Start charging",
        "EVSE initiated normal stop",
        "EVSE initiated emergency stop"};

static const char *EvseIsolationString[] =
    {
        "Invalid",
        "Valid",
        "Warning",
        "Fault",
        "No_IMD"};

static const char *EvseIsolationMonitorString[] =
    {
        "Not active",
        "Active"};

static const char *EvseRenegotiationString[] =
    {
        "None",
        "Request ReNegotiation"};

static const char *EvErrorString[] =
    {
        "NO_ERROR",
        "FAILED_RESSTemperatureInhibit",
        "FAILED_EVShiftPosition",
        "FAILED_ChargerConnectorLockFault",
        "FAILED_EVRESSMalfunction",
        "FAILED_ChargingCurrentdifferential",
        "FAILED_ChargingVoltageOutOfRange",
        "Reserved_A",
        "Reserved_B",
        "Reserved_C",
        "FAILED_ChargingSystemIncompatibility",
        "NoData"};

static const char *SeccErrorString(int8_t code)
{
  char *ret;

  switch (code)
  {
  case SECC_ERR_NO_ERROR:
    ret = "NO_ERROR";
    break;
  case SECC_ERR_FAILED:
    ret = "FAILED";
    break;
  case SECC_ERR_SEQUENCE_ERROR:
    ret = "FAILED_SequenceError";
    break;
  case SECC_ERR_SERVICE_ID_INVAILD:
    ret = "FAILED_ServiceIDInvalid";
    break;
  case SECC_ERR_UNKNOWN_SESSION:
    ret = "FAILED_UnknownSession";
    break;
  case SECC_ERR_SERVICE_SELECTION_INVAILD:
    ret = "FAILED_ServiceSelectionInvalid";
    break;
  case SECC_ERR_PAYMENT_SELECTION_INVAILD:
    ret = "FAILED_PaymentSelectionInvalid";
    break;
  case SECC_ERR_CERTIFICATION_EXPIRED:
    ret = "FAILED_CertificateExpired";
    break;
  case SECC_ERR_SIGNATURE_ERROR:
    ret = "FAILED_SignatureError";
    break;
  case SECC_ERR_NO_CERTIFICATE_AVAILABLE:
    ret = "FAILED_NoCertificateAvailable";
    break;
  case SECC_ERR_CERT_CHAIN_ERROR:
    ret = "FAILED_CertChainError";
    break;
  case SECC_ERR_CHALLENGE_INVALID:
    ret = "FAILED_ChallengeInvalid";
    break;
  case SECC_ERR_CONTRACT_CANCELED:
    ret = "FAILED_ContractCanceled";
    break;
  case SECC_ERR_WRONG_CHARGE_PARAMETER:
    ret = "FAILED_WrongChargeParameter";
    break;
  case SECC_ERR_POWER_DELIVERY_NOT_APPLIED:
    ret = "FAILED_PowerDeliveryNotApplied";
    break;
  case SECC_ERR_TARIFF_SELECTION_INVAILD:
    ret = "FAILED_TariffSelectionInvalid";
    break;
  case SECC_ERR_CHARGING_PROFILE_INVAILD:
    ret = "FAILED_ChargingProfileInvalid";
    break;
  case SECC_ERR_METERING_SIGNATURE_NOT_VAILD:
    ret = "FAILED_MeteringSignatureNotValid";
    break;
  case SECC_ERR_NO_CHARGE_SERVICE_SELECTED:
    ret = "FAILED_NoChargeServiceSelected";
    break;
  case SECC_ERR_WRONG_ENERGY_TRANSFER_MODE:
    ret = "FAILED_WrongEnergyTransferMode";
    break;
  case SECC_ERR_CERTIFICATE_REVOKED:
    ret = "FAILED_CertificateRevoked";
    break;
  case SECC_ERR_NO_NEGOTIATION:
    ret = "FAILED_NoNegotiation";
    break;
  case SECC_ERR_TIMEOUT_COMMUNICATION_SETUP:
    ret = "TIMEOUT_CommunicationSetup";
    break;
  case SECC_ERR_TIMEOUT_SEQUENCE:
    ret = "TIMEOUT_Sequence";
    break;
  case SECC_ERR_TIMEOUT_NOTIFICATION_MAX_DELAY:
    ret = "TIMEOUT_NotificationMaxDelay";
    break;
  case SECC_ERR_TIMEOUT_WELDING_DETECTION:
    ret = "TIMEOUT_WeldingDetection";
    break;
  case SECC_ERR_WRONG_CP_LEVEL:
    ret = "FAULT_WrongCPLevel";
    break;
  case SECC_ERR_PROXMITY_ERROR:
    ret = "FAULT_ProximityError";
    break;
  case SECC_ERR_HLC_ERROR:
    ret = "FAULT_HLCError";
    break;
  case SECC_ERR_HEARTBEAT_ERROR:
    ret = "FAULT_HeartbeatError";
    break;
  case SECC_ERR_EVSE_CAN_INIT:
    ret = "FAULT_EVSECANInit";
    break;
  case SECC_ERR_HPGP_LINK_DOWN:
    ret = "FAULT_HPGPLinkDown";
    break;
  case SECC_ERR_TLS_ERROR_ALERT:
    ret = "FAULT_TLS_ErrorAlert";
    break;
  default:
    ret = "RESERVED";
    break;
  }
  return ret;
}

static const char *TlsErrorString(int8_t code)
{
  char *ret;

  switch (code)
  {
  case TLS_ERR_CLOSE_NOTIFY:
    ret = "close_notify";
    break;

  case TLS_ERR_UNEXPECTED_MSG:
    ret = "unexpected_message";
    break;

  case TLS_ERR_BAD_RECORD_MAC:
    ret = "bad_record_mac";
    break;

  case TLS_ERR_DECRYPTION_FAILED_RESERVED:
    ret = "decryption_failed_RESERVED";
    break;

  case TLS_ERR_RECORD_OVERFLOW:
    ret = "record_overflow";
    break;

  case TLS_ERR_DECOMPRESSION_FAILURE:
    ret = "decompression_failure";
    break;

  case TLS_ERR_HANDSHAKE_FAILURE:
    ret = "handshake_failure";
    break;

  case TLS_ERR_NO_CERTIFICATE_RESERVED:
    ret = "no_certificate_RESERVED";
    break;

  case TLS_ERR_BAD_CERTIFICATE:
    ret = "bad_certificate";
    break;

  case TLS_ERR_UNSUPPORTED_CERTIFICATE:
    ret = "unsupported_certificate";
    break;

  case TLS_ERR_CERTIFICATE_REVOKED:
    ret = "certificate_revoked";
    break;

  case TLS_ERR_CERTIFICATE_EXPIRED:
    ret = "certificate_expired";
    break;

  case TLS_ERR_CERTIFICATE_UNKNOWN:
    ret = "certificate_unknown";
    break;

  case TLS_ERR_ILLEGAL_PARAMETER:
    ret = "illegal_parameter";
    break;

  case TLS_ERR_UNKNOWN_CA:
    ret = "unknown_ca";
    break;

  case TLS_ERR_ACCESS_DENIED:
    ret = "access_denied";
    break;

  case TLS_ERR_DECODE_ERROR:
    ret = "decode_error";
    break;

  case TLS_ERR_DECRYPT_ERROR:
    ret = "decrypt_error";
    break;

  case TLS_ERR_EXPORT_RESTRICTION_RESERVED:
    ret = "export_restriction_RESERVED";
    break;

  case TLS_ERR_PROTOCOL_VERSION:
    ret = "protocol_version";
    break;

  case TLS_ERR_INSUFFICIENT_SECURITY:
    ret = "insufficient_security";
    break;

  case TLS_ERR_INTERNAL_ERROR:
    ret = "internal_error";
    break;

  case TLS_ERR_USER_CANCELED:
    ret = "user_canceled";
    break;

  case TLS_ERR_NO_RENEGOTIATION:
    ret = "no_renegotiation";
    break;

  case TLS_ERR_UNSUPPORTED_EXTENSION:
    ret = "unsupported_extension";
    break;

  default:
    ret = "RESERVED";
    break;
  }
  return ret;
}

const char *SeccStateString(uint8_t code)
{
  char *ret;

  switch (code)
  {
  case SECC_STATUS_IDLE:
    ret = "IDLE";
    break;

  case SECC_STATUS_INITIALIZED:
    ret = "Initialized";
    break;

  case SECC_STATUS_WAITING_PLUG_IN:
    ret = "Waiting Plug-in";
    break;

  case SECC_STATUS_WAITING_SLAC:
    ret = "Waiting SLAC";
    break;

  case SECC_STATUS_PROCESSING_SLAC:
    ret = "Processing SLAC";
    break;

  case SECC_STATUS_SDP:
    ret = "SDP";
    break;

  case SECC_STATUS_ESTABLISHING_TCP_TLS:
    ret = "Establishing TCP (TLS)";
    break;

  case SECC_STATUS_SAP:
    ret = "SAP";
    break;

  case SECC_STATUS_SESSION_SETUP:
    ret = "SessionSetup";
    break;

  case SECC_STATUS_SESSION_STOP_TERMINATE:
    ret = "SessionStop (Terminate)";
    break;

  case SECC_STATUS_SESSION_STOP_PAUSE:
    ret = "SessionStop (Pause)";
    break;

  case SECC_STATUS_SERVICE_DISCOVERY:
    ret = "ServiceDiscovery";
    break;

  case SECC_STATUS_SERVICE_DETAILS:
    ret = "ServiceDetails";
    break;

  case SECC_STATUS_PAYMENT_SERVICE_SELECTION:
    ret = "PaymentServiceSelection";
    break;

  case SECC_STATUS_CERTIFICATE_INSTALLATION:
    ret = "CertificateInstallation";
    break;

  case SECC_STATUS_CERTIFICATE_UPDATE:
    ret = "CertificateUpdate";
    break;

  case SECC_STATUS_PAYMENT_DETAILS:
    ret = "PaymentDetails";
    break;

  case SECC_STATUS_AUTHORIZATION_EIM:
    ret = "Authorization (EIM)";
    break;

  case SECC_STATUS_AUTHORIZATION_PnC:
    ret = "Authorization (PnC)";
    break;

  case SECC_STATUS_CHARGE_PARAMETER_DISCOVERY:
    ret = "ChargeParameterDiscovery";
    break;

  case SECC_STATUS_CABLE_CHECK:
    ret = "CableCheck";
    break;

  case SECC_STATUS_PRE_CHARGE:
    ret = "PreCharge";
    break;

  case SECC_STATUS_WELDING_DETECTION:
    ret = "WeldingDetection";
    break;

  case SECC_STATUS_POWER_DELIVERY_START:
    ret = "PowerDelivery (Start)";
    break;

  case SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP:
    ret = "PowerDelivery (EV Init. Stop)";
    break;

  case SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP:
    ret = "PowerDelivery (EVSE Init. Stop)";
    break;

  case SECC_STATUS_POWER_DELIVERY_RENEGOTIATE:
    ret = "PowerDelivery (ReNegotiate)";
    break;

  case SECC_STATUS_CURRENT_DEMAND:
    ret = "CurrentDemand";
    break;

  case SECC_STATUS_METERING_RECEIPT:
    ret = "MeteringReceipt";
    break;

  case SECC_STATUS_TERMINATE:
    ret = "TERMINATE";
    break;

  case SECC_STATUS_PAUSE:
    ret = "PAUSE";
    break;

  case SECC_STATUS_ERROR:
    ret = "ERROR";
    break;

  default:
    ret = "RESERVED";
    break;
  }
  return ret;
}

static const char *SeccEstablishedInfoString[] =
    {
        "NONE",
        "Non-TLS established",
        "Public TLS established",
        "Private TLS established"};

static const char *SeccSaInitResultString[] =
    {
        "None",
        "Non-TLS Mode Fallback",
        "Public TLS Ready",
        "Private TLS Ready"};

static const char *SeccSaCommString(uint8_t code)
{
  char *ret;

  switch (code)
  {
  case SA_COMM_STATUS_NONE:
    ret = "None";
    break;

  case SA_COMM_STATUS_TIMEOUT_SA_AGENT_HELLO_RESPONSE:
    ret = "TIMEOUT_saAgentHelloResponse";
    break;

  case SA_COMM_STATUS_TIMEOUT_SA_AGENT_GET_CERTIFICATE_STATUS_RESPONSE:
    ret = "TIMEOUT_saAgentGetCertificateStatusReponse";
    break;

  case SA_COMM_STATUS_TIMEOUT_SA_AGENT_SIGN_SECC_CERTIFICATE_RESPONSE:
    ret = "TIMEOUT_saAgentSignSECCCertificateReponse";
    break;

  case SA_COMM_STATUS_TIMEOUT_CERT_INSTALL_PERFORMANCE_TIMER:
    ret = "TIMEOUT_certInstallPerformanceTimer";
    break;

  case SA_COMM_STATUS_TIMEOUT_CERT_UPDATE_PERFORMANCE_TIMER:
    ret = "TIMEOUT_certUpdatePerformanceTimer";
    break;

  case SA_COMM_STATUS_TIMEOUT_SA_AGENT_AUTHORIZE_RESPONSE:
    ret = "TIMEOUT_saAgentAuthorizeResponse";
    break;

  case SA_COMM_STATUS_FAULT_SA_AGENT_COMM:
    ret = "FAULT_saAgentComm";
    break;

  case SA_COMM_STATUS_FAULT_PARSE_JSON:
    ret = "FAULT_parseJSON";
    break;

  case SA_COMM_STATUS_FAULT_CREATE_CSR:
    ret = "FAULT_createCSR";
    break;

  case SA_COMM_STATUS_FAULT_RECEIVED_CERT_CHAIN:
    ret = "FAULT_receivedCertChain";
    break;

  case SA_COMM_STATUS_FAULT_DECODE_EXI:
    ret = "FAULT_decodeEXI";
    break;

  default:
    ret = "RESERVED";
    break;
  }
  return ret;
};

static const char *SeccPncReadyString[] =
    {
        "NONE",
        "Not Ready",
        "Ready"};

static const char *SeccEvServiceSelectionChargingProtocolString(uint8_t code)
{
  char *ret;

  switch (code)
  {
  case 0:
    ret = "DIN SPEC 70121:2014";
    break;

  case 1:
    ret = "ISO 15118-2:2013";
    break;

  case 2:
    ret = "ISO 15118-2:2016";
    break;

  case 0xff:
    ret = "NONE (Default)";
    break;

  default:
    ret = "RESERVED";
    break;
  }
  return ret;
};

static const char *SeccEvServiceSelectionPaymentOptionString(uint8_t code)
{
  char *ret;

  switch (code)
  {
  case 0:
    ret = "Contract";
    break;

  case 1:
    ret = "ExternalPayment";
    break;

  case 0xff:
    ret = "NONE (Default)";
    break;

  default:
    ret = "RESERVED";
    break;
  }
  return ret;
};

static const char *SeccEvServiceSelectionEnergyTransferModeString(uint8_t code)
{
  char *ret;

  switch (code)
  {
  case 0:
    ret = "AC_single_phase_core";
    break;

  case 1:
    ret = "AC_three_phase_core";
    break;

  case 2:
    ret = "DC_core";
    break;

  case 3:
    ret = "DC_extended";
    break;

  case 4:
    ret = "DC_combo_core";
    break;

  case 5:
    ret = "DC_unique";
    break;

  case 0xff:
    ret = "NONE (Default)";
    break;

  default:
    ret = "RESERVED";
    break;
  }
  return ret;
};

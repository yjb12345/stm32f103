/*
 * Diagnostic.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_UTIL_DIAGNOSTIC_H_
#define AP_UTIL_DIAGNOSTIC_H_


#include "EvseMain.h"

void ChargerPrintDiagInfo();

void ChargerPrintChargeParamDiscoveryInfo();
void ChargerPrintCableCheckInfo();
void ChargerPrintCableCheckInfoWithADC(uint32_t dcType, double voltage);
void ChargerPrintPreChargeInfo();
void ChargerPrintChargingInfo();
void ChargerPrintRenegoInfo();
void ChargerPrintTerminationInfo();
void ChargerPrintTerminationReason();
char * ChargerPrintEvseIsolationStatus(unsigned value);

const char *SeccStateString(uint8_t code);

#endif /* AP_UTIL_DIAGNOSTIC_H_ */

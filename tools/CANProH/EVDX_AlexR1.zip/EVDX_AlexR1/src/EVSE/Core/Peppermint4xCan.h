/*
 * Peppermint4xCan.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_PEPPERMINT4XCAN_H_
#define AP_PEPPERMINT4XCAN_H_


#include <stdint.h>

//#include "stm32f1xx_hal.h" // alex added

#define MAX_CANSEND_ERROR_CNT               500

#define MSG_V_SCALE_SECC_CANMAP             (-1)
#define MSG_I_SCALE_SECC_CANMAP             (-1)
#define MSG_W_SCALE_SECC_CANMAP             (1)
#define MSG_WH_SCALE_SECC_CANMAP            (1)

//EVSE
#define CAN_ID_H15ECC001                    0x15ECC001
#define CAN_ID_H15ECC002                    0x15ECC002
#define CAN_ID_H15ECC003                    0x15ECC003
#define CAN_ID_H15ECC004                    0x15ECC004
#define CAN_ID_H15ECC005                    0x15ECC005
#define CAN_ID_H15ECC006                    0x15ECC006
#define CAN_ID_H15ECC007                    0x15ECC007
#define CAN_ID_H15ECC008                    0x15ECC008
#define CAN_ID_H15ECC009                    0x15ECC009
#define CAN_ID_H15ECC00A                    0x15ECC00A
#define CAN_ID_H15ECC00B                    0x15ECC00B
#define CAN_ID_H15ECC00C                    0x15ECC00C
#define CAN_ID_H15ECC00D                    0x15ECC00D
#define CAN_ID_H15ECC00E                    0x15ECC00E
#define CAN_ID_H15ECC00F                    0x15ECC00F
#define CAN_ID_H15ECC0FF                    0x15ECC0FF

//EVSE PnC
#define CAN_ID_H15ECD001                    0x15ECD001
#define CAN_ID_H15ECD002                    0x15ECD002
#define CAN_ID_H15ECD003                    0x15ECD003

//SECC
#define CAN_ID_H15ECC101                    0x15ECC101
#define CAN_ID_H15ECC102                    0x15ECC102
#define CAN_ID_H15ECC103                    0x15ECC103
#define CAN_ID_H15ECC104                    0x15ECC104
#define CAN_ID_H15ECC105                    0x15ECC105
#define CAN_ID_H15ECC106                    0x15ECC106
#define CAN_ID_H15ECC107                    0x15ECC107
#define CAN_ID_H15ECC108                    0x15ECC108
#define CAN_ID_H15ECC109                    0x15ECC109

#define CAN_ID_H15ECC10A                    0x15ECC10A
#define CAN_ID_H15ECC10B                    0x15ECC10B
#define CAN_ID_H15ECC1FF                    0x15ECC1FF

//SECC PnC
#define CAN_ID_H15ECD101                    0x15ECD101
#define CAN_ID_H15ECD102                    0x15ECD102

#define BIT_SET                             0x01
#define BIT_RESET                           0x00

#define SECC_CP_VOLTAGE_A    (90) //9v
#define SECC_CP_VOLTAGE_B    (120) //12v
#define SECC_CP_VOLTAGE_C    (60) //6v
#define SECC_CP_VOLTAGE_F    (-120) //-12v
#define SECC_CP_VOLTAGE_OFFSET (5) //0.5v

typedef enum {
    CHARGING_CTRL_NONE = 0,
    CHARGING_CTRL_INITIALIZE_PPMT,
    CHARGING_CTRL_START_CHARGING,
    CHARGING_CTRL_EVSE_INITIATED_NORMAL_STOP,
    CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP,
} EVSE_CHARGING_CONTROL;

typedef enum {
    EVSE_PROC_ONGOING = 0,
    EVSE_PROC_FINISHED = 1
} EVSE_PROCESSING_TYPE;

typedef enum {
    EVSE_ISOLATION_STAT_INVALID = 0,
    EVSE_ISOLATION_STAT_VALID,
    EVSE_ISOLATION_STAT_WARNING,
    EVSE_ISOLATION_STAT_FAULT,
    EVSE_ISOLATION_NO_IMD
} EVSE_ISOL_STAT_TYPE;

typedef enum{
    EVSE_TRIGGER_F_DISABLED = 0,
    EVSE_TRIGGER_F_ENABLED = 1
}EVSE_TRIGGER_F_TYPE;

typedef enum{
    EVSE_TRIGGER_RENEGO_NONE = 0,
    EVSE_TRIGGER_RENEGO_REQUEST = 1
}EVSE_TRIGGER_RENEGOTIATION_TYPE;

typedef enum{
    SECC_CP_STATE_F = 0,
    SECC_CP_STATE_A = 1,
    SECC_CP_STATE_B = 2,
    SECC_CP_STATE_C = 3,
    SECC_CP_STATE_DEFAULT = 255
}SECC_CP_STATE_TYPE;

typedef enum {
    SECC_STATUS_LEGACY_IDLE_WAIT = 0,
    SECC_STATUS_LEGACY_IDLE = 1,
    SECC_STATUS_LEGACY_READY = 2,
    SECC_STATUS_LEGACY_LOW_LEVEL_COMM = 3,
    SECC_STATUS_LEGACY_HIGH_LEVEL_COMM = 4,
    SECC_STATUS_LEGACY_AUTHENTICATION = 5,
    SECC_STATUS_LEGACY_CHARGE_PARAMETER_DISCOVERY = 6,
    SECC_STATUS_LEGACY_CABLE_CHECK = 7,
    SECC_STATUS_LEGACY_PRE_CHARGE = 8,
    SECC_STATUS_LEGACY_CHARGING = 9,
    SECC_STATUS_LEGACY_RENEGOTIATION = 10,
    SECC_STATUS_LEGACY_EV_STOP_CHARGING = 11,
    SECC_STATUS_LEGACY_EVSE_STOP_CHARGING = 12,
    SECC_STATUS_LEGACY_PAUSE = 13,
    SECC_STATUS_LEGACY_TERMINATE = 14,
    SECC_STATUS_LEGACY_CERTIFICATION_INSTALLATION = 15,
    SECC_STATUS_LEGACY_CERTIFICATION_UPDATE = 16,
    SECC_STATUS_LEGACY_ERROR = 17,
    SECC_STATUS_LEGACY_AUTHORIZATION_PnC = 18,
    SECC_STATUS_LEGACY_METERING_RECEIPT = 19,
} SECC_STATUS_CODE_LEGACY;

typedef enum {
    SECC_STATUS_IDLE = 0,
    SECC_STATUS_INITIALIZED = 1,
    SECC_STATUS_WAITING_PLUG_IN = 2,
    SECC_STATUS_WAITING_SLAC = 10,
    SECC_STATUS_PROCESSING_SLAC = 11,
    SECC_STATUS_SDP = 20,
    SECC_STATUS_ESTABLISHING_TCP_TLS = 21,
    SECC_STATUS_SAP = 30,
    SECC_STATUS_SESSION_SETUP = 40,
    SECC_STATUS_SESSION_STOP_TERMINATE = 41,
    SECC_STATUS_SESSION_STOP_PAUSE = 42,
    SECC_STATUS_SERVICE_DISCOVERY = 50,
    SECC_STATUS_SERVICE_DETAILS = 51,
    SECC_STATUS_PAYMENT_SERVICE_SELECTION = 60,
    SECC_STATUS_CERTIFICATE_INSTALLATION = 70,
    SECC_STATUS_CERTIFICATE_UPDATE = 71,
    SECC_STATUS_PAYMENT_DETAILS = 80,
    SECC_STATUS_AUTHORIZATION_EIM = 81,
    SECC_STATUS_AUTHORIZATION_PnC = 82,
    SECC_STATUS_CHARGE_PARAMETER_DISCOVERY = 90,
    SECC_STATUS_CABLE_CHECK = 100,
    SECC_STATUS_PRE_CHARGE = 101,
    SECC_STATUS_WELDING_DETECTION = 102,
    SECC_STATUS_POWER_DELIVERY_START = 110,
    SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP = 111,
    SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP = 112,
    SECC_STATUS_POWER_DELIVERY_RENEGOTIATE = 113,
    SECC_STATUS_CURRENT_DEMAND = 120,
    SECC_STATUS_METERING_RECEIPT = 121,
    SECC_STATUS_TERMINATE = 250,
    SECC_STATUS_PAUSE = 251,
    SECC_STATUS_ERROR = 252
} SECC_STATUS_CODE;

typedef enum {
    AC_SINGLE_PHASE_CORE = 0,
    AC_THREE_PHASE_CORE,
    DC_CORE,
    DC_EXTENDED,
    DC_COMBO_CORE,
    DC_UNIQUE,
    NONE = 0xFF
} SECC_ENERGY_TRANSFER_TYPE;

typedef enum
{
    SECC_ERR_NO_ERROR = 0,
    SECC_ERR_FAILED = 1,
    SECC_ERR_SEQUENCE_ERROR = 2,
    SECC_ERR_SERVICE_ID_INVAILD = 3,
    SECC_ERR_UNKNOWN_SESSION = 4,
    SECC_ERR_SERVICE_SELECTION_INVAILD = 5,
    SECC_ERR_PAYMENT_SELECTION_INVAILD = 6,
    SECC_ERR_CERTIFICATION_EXPIRED = 7,
    SECC_ERR_SIGNATURE_ERROR = 8,
    SECC_ERR_NO_CERTIFICATE_AVAILABLE = 9,
    SECC_ERR_CERT_CHAIN_ERROR = 10,
    SECC_ERR_CHALLENGE_INVALID = 11,
    SECC_ERR_CONTRACT_CANCELED = 12,
    SECC_ERR_WRONG_CHARGE_PARAMETER = 13,
    SECC_ERR_POWER_DELIVERY_NOT_APPLIED = 14,
    SECC_ERR_TARIFF_SELECTION_INVAILD = 15,
    SECC_ERR_CHARGING_PROFILE_INVAILD = 16,
    SECC_ERR_METERING_SIGNATURE_NOT_VAILD = 17,
    SECC_ERR_NO_CHARGE_SERVICE_SELECTED = 18,
    SECC_ERR_WRONG_ENERGY_TRANSFER_MODE = 19,
    SECC_ERR_CERTIFICATE_REVOKED = 22,
    SECC_ERR_NO_NEGOTIATION = 23,
    SECC_ERR_TIMEOUT_COMMUNICATION_SETUP = 30,
    SECC_ERR_TIMEOUT_SEQUENCE = 31,
    SECC_ERR_TIMEOUT_NOTIFICATION_MAX_DELAY = 32,
    SECC_ERR_TIMEOUT_WELDING_DETECTION = 33,
    SECC_ERR_WRONG_CP_LEVEL = 40,
    SECC_ERR_PROXMITY_ERROR = 41,
    SECC_ERR_HLC_ERROR = 42,
    SECC_ERR_HEARTBEAT_ERROR = 43,
    SECC_ERR_EVSE_CAN_INIT = 44,
    SECC_ERR_HPGP_LINK_DOWN = 45,
    SECC_ERR_TLS_ERROR_ALERT = 46
} SECC_ERROR_TYPE;

typedef enum
{
    TLS_ERR_CLOSE_NOTIFY = 0,
    TLS_ERR_UNEXPECTED_MSG = 10,
    TLS_ERR_BAD_RECORD_MAC = 20,
    TLS_ERR_DECRYPTION_FAILED_RESERVED = 21,
    TLS_ERR_RECORD_OVERFLOW = 22,
    TLS_ERR_DECOMPRESSION_FAILURE = 30,
    TLS_ERR_HANDSHAKE_FAILURE = 40,
    TLS_ERR_NO_CERTIFICATE_RESERVED = 41,
    TLS_ERR_BAD_CERTIFICATE = 42,
    TLS_ERR_UNSUPPORTED_CERTIFICATE = 43,
    TLS_ERR_CERTIFICATE_REVOKED = 44,
    TLS_ERR_CERTIFICATE_EXPIRED = 45,
    TLS_ERR_CERTIFICATE_UNKNOWN = 46,
    TLS_ERR_ILLEGAL_PARAMETER = 47,
    TLS_ERR_UNKNOWN_CA = 48,
    TLS_ERR_ACCESS_DENIED = 49,
    TLS_ERR_DECODE_ERROR = 50,
    TLS_ERR_DECRYPT_ERROR = 51,
    TLS_ERR_EXPORT_RESTRICTION_RESERVED = 60,
    TLS_ERR_PROTOCOL_VERSION = 70,
    TLS_ERR_INSUFFICIENT_SECURITY = 71,
    TLS_ERR_INTERNAL_ERROR = 80,
    TLS_ERR_USER_CANCELED = 90,
    TLS_ERR_NO_RENEGOTIATION = 100,
    TLS_ERR_UNSUPPORTED_EXTENSION = 110
} TLS_ERROR_ALERT_TYPE;

typedef enum
{
    SA_COMM_STATUS_NONE = 0,
    SA_COMM_STATUS_TIMEOUT_SA_AGENT_HELLO_RESPONSE = 10,
    SA_COMM_STATUS_TIMEOUT_SA_AGENT_GET_CERTIFICATE_STATUS_RESPONSE = 11,
    SA_COMM_STATUS_TIMEOUT_SA_AGENT_SIGN_SECC_CERTIFICATE_RESPONSE = 12,
    SA_COMM_STATUS_TIMEOUT_CERT_INSTALL_PERFORMANCE_TIMER = 13,
    SA_COMM_STATUS_TIMEOUT_CERT_UPDATE_PERFORMANCE_TIMER = 14,
    SA_COMM_STATUS_TIMEOUT_SA_AGENT_AUTHORIZE_RESPONSE = 15,
    SA_COMM_STATUS_FAULT_SA_AGENT_COMM = 20,
    SA_COMM_STATUS_FAULT_PARSE_JSON = 21,
    SA_COMM_STATUS_FAULT_CREATE_CSR = 22,
    SA_COMM_STATUS_FAULT_RECEIVED_CERT_CHAIN = 23,
    SA_COMM_STATUS_FAULT_DECODE_EXI = 40
} SECC_SA_COMMUNICATION_STATUS;

typedef struct {
    uint32_t    CAN_ADDRESS;
    void        *P_DATA;
} CAN_DATA_MAP_UNIT;

#pragma pack(push,1)
/* "EVSE_Configurations */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_ID_CONFIG_DIN                  :1;
            uint8_t EVSE_ID_CONFIG_ISO                  :1;
            uint8_t RESERVED_2                          :1;
            uint8_t RESERVED_3                          :1;
            uint8_t ENVIRONMENT_CONFIGURATION       :4;
            uint8_t EVSE_ID_LENGTH_DIN                  :8;
            uint8_t EVSE_ID_LENGTH_ISO                  :8;
            uint8_t RESERVED_24                     :1;
            uint8_t RESERVED_25                     :1;
            uint8_t SUPPORTED_ENERGY_TRANSFER_DC_CORE   :1;
            uint8_t SUPPORTED_ENERGY_TRANSFER_DC_EXTD   :1;
            uint8_t SUPPORTED_ENERGY_TRANSFER_DC_CC :1;
            uint8_t SUPPORTED_ENERGY_TRANSFER_DC_UNIQUE :1;
            uint8_t RESERVED_30_31          :2;
            uint8_t SERVICE_LIST_INTERNET                   :1;
            uint8_t RESERVED_33_34                  :2;
            uint8_t SERVICE_LIST_HPC1               :1;
            uint8_t RESERVED_36_39          :4;
            uint8_t FREE_SERVICE_EV_CHARGING            :1;
            uint8_t FREE_SERVICE_INTERNET                   :1;
            uint8_t FREE_SERVICE_CONTRACT_CERT          :1;
            uint8_t FREE_SERVICE_OTHER_CUSTOM           :1;
            uint8_t RESERVED_44_47          :4;
            uint8_t SA_SCHEDULE_MANAGEMENT          :8;
            uint8_t CP_MONITORING_MODE              :1;
            uint8_t RESERVED_57_63                  :7;
        };
    };
} CANID_H15ECC001;

/* "EVSE_Status */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_HEARTBEAT                  :8;
            uint8_t CHARGING_CONTROL                    :8;
            uint16_t NOTIFICATION_MAX_DELAY         :16;
            uint8_t EVSE_ISOLATION_STATUS           :8;
            uint8_t RESERVED_40_47                  :8;
            uint8_t EVSE_PROCESSING_AUTH_EIM            :1;
            uint8_t EVSE_PROCESSING_CPD                 :1;
            uint8_t EVSE_PROCESSING_CABLE_CHECK         :1;
            uint8_t ISOLATION_MONITORING_ACTIVE         :1;
            uint8_t TRIGGER_RE_NEGOTIATION          :1;
            uint8_t RESERVED_53                     :1;
            uint8_t TRIGGER_STATE_E             :1;
            uint8_t RESERVED_55             :1;
            uint8_t EVSE_CURRENT_LIMIT_ACHIEVED         :1;
            uint8_t EVSE_VOLTAGE_LIMIT_ACHIEVED         :1;
            uint8_t EVSE_POWER_LIMIT_ACHIEVED           :1;
            uint8_t RESERVED_59_63                  :5;
        };
    };
} CANID_H15ECC002;

/* "EVSE_Charge_Parameters_1 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint16_t EVSE_MAXIMUM_CURRENT_LIMIT :16;
            uint16_t EVSE_MAXIMUM_POWER_LIMIT   :16;
            uint16_t EVSE_MAXIMUM_VOLTAGE_LIMIT :16;
            uint16_t EVSE_PEAK_CURRENT_RIPPLE   :16;
        };
    };
} CANID_H15ECC003;

/* "EVSE_Charge_Parameters_2 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint16_t EVSE_MINIMUM_CURRENT_LIMIT         :16;
            uint16_t EVSE_MINIMUM_VOLTAGE_LIMIT         :16;
            uint16_t EVSE_CURRENT_REGULATION_TOLERANCE  :16;
            uint16_t EVSE_ENERGY_TO_BE_DELIVERED        :16;
        };
    };
} CANID_H15ECC004;

/* "EVSE_Present_Voltage/Current */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint16_t EVSE_PRESENT_VOLTAGE   :16;
            uint16_t EVSE_PRESENT_CURRENT   :16;
            uint32_t RESERVED_32_63             :32;
        };
    };
} CANID_H15ECC005;

/* "EVSE_DIN_ID_1 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_DIN_ID1_0  :8;
            uint8_t EVSE_DIN_ID1_1  :8;
            uint8_t EVSE_DIN_ID1_2  :8;
            uint8_t EVSE_DIN_ID1_3  :8;
            uint8_t EVSE_DIN_ID1_4  :8;
            uint8_t EVSE_DIN_ID1_5  :8;
            uint8_t EVSE_DIN_ID1_6  :8;
            uint8_t EVSE_DIN_ID1_7  :8;
        };
    };
} CANID_H15ECC006;

/* "EVSE_DIN_ID_2 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_DIN_ID2_0  :8;
            uint8_t EVSE_DIN_ID2_1  :8;
            uint8_t EVSE_DIN_ID2_2  :8;
            uint8_t EVSE_DIN_ID2_3  :8;
            uint8_t EVSE_DIN_ID2_4  :8;
            uint8_t EVSE_DIN_ID2_5  :8;
            uint8_t EVSE_DIN_ID2_6  :8;
            uint8_t EVSE_DIN_ID2_7  :8;
        };
    };
} CANID_H15ECC007;

/* "EVSE_DIN_ID_3 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_DIN_ID3_0  :8;
            uint8_t EVSE_DIN_ID3_1  :8;
            uint8_t EVSE_DIN_ID3_2  :8;
            uint8_t EVSE_DIN_ID3_3  :8;
            uint8_t EVSE_DIN_ID3_4  :8;
            uint8_t EVSE_DIN_ID3_5  :8;
            uint8_t EVSE_DIN_ID3_6  :8;
            uint8_t EVSE_DIN_ID3_7  :8;
        };
    };
} CANID_H15ECC008;

/* "EVSE_DIN_ID_4 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_DIN_ID4_0  :8;
            uint8_t EVSE_DIN_ID4_1  :8;
            uint8_t EVSE_DIN_ID4_2  :8;
            uint8_t EVSE_DIN_ID4_3  :8;
            uint8_t EVSE_DIN_ID4_4  :8;
            uint8_t EVSE_DIN_ID4_5  :8;
            uint8_t EVSE_DIN_ID4_6  :8;
            uint8_t EVSE_DIN_ID4_7  :8;
        };
    };
} CANID_H15ECC009;

/* "EVSE_ISO_ID_1 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_ISO_ID1_0  :8;
            uint8_t EVSE_ISO_ID1_1  :8;
            uint8_t EVSE_ISO_ID1_2  :8;
            uint8_t EVSE_ISO_ID1_3  :8;
            uint8_t EVSE_ISO_ID1_4  :8;
            uint8_t EVSE_ISO_ID1_5  :8;
            uint8_t EVSE_ISO_ID1_6  :8;
            uint8_t EVSE_ISO_ID1_7  :8;
        };
    };
} CANID_H15ECC00A;

/* "EVSE_ISO_ID_2 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_ISO_ID2_0  :8;
            uint8_t EVSE_ISO_ID2_1  :8;
            uint8_t EVSE_ISO_ID2_2  :8;
            uint8_t EVSE_ISO_ID2_3  :8;
            uint8_t EVSE_ISO_ID2_4  :8;
            uint8_t EVSE_ISO_ID2_5  :8;
            uint8_t EVSE_ISO_ID2_6  :8;
            uint8_t EVSE_ISO_ID2_7  :8;
        };
    };
} CANID_H15ECC00B;

/* "EVSE_ISO_ID_3 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_ISO_ID3_0  :8;
            uint8_t EVSE_ISO_ID3_1  :8;
            uint8_t EVSE_ISO_ID3_2  :8;
            uint8_t EVSE_ISO_ID3_3  :8;
            uint8_t EVSE_ISO_ID3_4  :8;
            uint8_t EVSE_ISO_ID3_5  :8;
            uint8_t EVSE_ISO_ID3_6  :8;
            uint8_t EVSE_ISO_ID3_7  :8;
        };
    };
} CANID_H15ECC00C;

/* "EVSE_ISO_ID_4 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_ISO_ID4_0  :8;
            uint8_t EVSE_ISO_ID4_1  :8;
            uint8_t EVSE_ISO_ID4_2  :8;
            uint8_t EVSE_ISO_ID4_3  :8;
            uint8_t EVSE_ISO_ID4_4  :8;
            uint8_t EVSE_ISO_ID4_5  :8;
            uint8_t EVSE_ISO_ID4_6  :8;
            uint8_t EVSE_ISO_ID4_7  :8;
        };
    };
} CANID_H15ECC00D;

/* "EVSE_ISO_ID_5 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t EVSE_ISO_ID5_0  :8;
            uint8_t EVSE_ISO_ID5_1  :8;
            uint8_t EVSE_ISO_ID5_2  :8;
            uint8_t EVSE_ISO_ID5_3  :8;
            uint8_t EVSE_ISO_ID5_4  :8;
        };
    };
} CANID_H15ECC00E;

/* "EVSE_Timestamp */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint64_t EVSE_TIMESTAMP :64;
        };
    };
} CANID_H15ECC00F;

/* "EVSE_SECC Reboot cmd */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SECC_R          :8;
            uint8_t SECC_E          :8;
            uint8_t SECC_B          :8;
            uint8_t SECC_O1         :8;
            uint8_t SECC_O2         :8;
            uint8_t SECC_T          :8;
            uint16_t RESERVED_48        :16;
        };
    };
} CANID_H15ECC0FF;

/* "SECC_Status */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SECC_HEARBEAT           :8;
            uint8_t SECC_STATUS_CODE_LEGACY :8;
            uint8_t EV_ERROR_CODE           :8;
            uint8_t SECC_ERROR_CODE         :8;
            uint8_t SECC_VERSION_MAJOR          :8;
            uint8_t SECC_VERSION_MINOR          :8;
            uint8_t SECC_VERSION_PATCH          :8;
            uint8_t PNC_READY               :8;
        };
    };
} CANID_H15ECC101;

/* "SECC_CP/PP_Status */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t CP_OSCILLATOR           :1;
            uint8_t RESERVED_1_7            :7;
            uint16_t CP_VOLTAGE                 :16;
            uint8_t HPGP_LINK_STATUS            :1;
            uint8_t RESERVED_25_31          :7;
            uint8_t TLS_ERROR_ALERT             :8;
            uint32_t RESERVED_40_63             :24;
        };
    };
} CANID_H15ECC102;

/* "SECC_EV_Service_Selection */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SELECTED_CHARGING_PROTOCOL                  :8;
            uint8_t SELECTED_PAYMENT_OPTION                 :8;
            uint8_t SELECTED_SERVICE_EV_CHARGING            :1;
            uint8_t SELECTED_SERVICE_INTERNET                   :1;
            uint8_t SELECTED_SERVICE_CONTRACT_CERT          :1;
            uint8_t SELECTED_SERVICE_OTHER_CUSTOM           :1;
            uint8_t SELECTED_SERVICE_HPC1                   :1;
            uint8_t SELECTED_CONTRACT_SERVICE_INSTALLATION      :1;
            uint8_t SELECTED_CONTRACT_SERVICE_UPDATE            :1;
            uint8_t RESERVED_23                                 :1;
            uint8_t SELECTED_ENERGY_TRANSFER_MODE           :8;
            uint8_t SELECTED_SA_SCHEDULE_TUPLE_ID           :8;
            uint32_t RESERVED_40_63                             :24;
        };
    };
} CANID_H15ECC103;

/* "SECC_Session_ID */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint64_t SESSIONID  :64;
        };
    };
} CANID_H15ECC104;

/* "SECC_EVCC_ID */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint64_t EVCC_MAC           :48;
            uint8_t EVCC_ATTN           :8;
            uint8_t RESERVED_56_63      :8;
        };
    };
} CANID_H15ECC105;

/* "SECC_EV_Charge_Parameters_1 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint16_t MAX_ENTRIES_SA_SCHEDULE_TUPLE  :16;
            uint32_t DEPARTURE_TIME                 :32;
            uint16_t EV_MAXIMUM_POWER_LIMIT         :16;
        };
    };
} CANID_H15ECC106;

/* "SECC_EV_Charge_Parameters_2 */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint16_t EV_MAXIMUM_CURRENT_LIMIT   :16;
            uint16_t EV_MAXIMUM_VOLTAGE_LIMIT   :16;
            uint16_t EV_ENERGY_CAPACITY         :16;
            uint16_t EV_ENERGY_REQUEST          :16;
        };
    };
} CANID_H15ECC107;

/* "SECC_EV_SoC_Related */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t CHARGING_COMPLETE           :2;
            uint8_t BULK_CHARGING_COMPLETE  :2;
            uint8_t RESERVED_4_7        :4;
            uint8_t EVSOC                   :8;
            uint8_t FULLSOC                 :8;
            uint8_t BULKSOC                 :8;
            uint16_t REMAINING_TIME_TO_FULLSOC  :16;
            uint16_t REMAINING_TIME_TO_BULKSOC  :16;
        };
    };
} CANID_H15ECC108;

/* "SECC_EV_Target_Voltage/Current */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint16_t TARGET_VOLTAGE :16;
            uint16_t TARGET_CURRENT :16;
            uint32_t RESERVED_32_63     :32;
        };
    };
} CANID_H15ECC109;

/* "SECC_Timestamp */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint64_t SECC_TIMESTAMP :64;
        };
    };
} CANID_H15ECC10A;

/* "SECC_Status3 (PnC) */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SECC_STATUS_CODE            :8;
            uint64_t RESERVED_8_55              :48;
            uint8_t SECC_ESTABLISHED_INFO       :8;
        };
    };
} CANID_H15ECC10B;

/* "SECC_Emergency Notification */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t NOTIFICATION_COUNT          :8;
            uint64_t RESERVED_8_63              :56;
        };
    };
} CANID_H15ECC1FF;

/* EVSE SA Agent Connection Configuration */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SA_AGENT_IP_ADDR_1          :8;
            uint8_t SA_AGENT_IP_ADDR_2          :8;
            uint8_t SA_AGENT_IP_ADDR_3          :8;
            uint8_t SA_AGENT_IP_ADDR_4          :8;
            uint16_t SA_AGENT_PORT              :16;
            uint16_t RESERVED_48_63             :16;
        };
    };
} CANID_H15ECD001;

/* EVSE SECC PnC Configuration */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t PKI_ENVIRONMENT_SELECTION           :8;
            uint8_t CERT_CHAIN_VALIDATION_OPTION        :8;
            uint8_t RE_KEY_OPTION                   :8;
            uint64_t RESERVED_24_63                     :40;
        };
    };
} CANID_H15ECD002;

/* EVSE SA Agent Communication timeout */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SA_AGENT_HELLO_RESP_TIMEOUT                         :8;
            uint8_t SA_AGENT_GET_CERTIFICATE_STATUS_RESP_TIMEOUT        :8;
            uint8_t SA_AGENT_SIGN_SECC_CERTIFICATE_RESP_TIMEOUT         :8;
            uint8_t SA_AGENT_CERT_INSTALLATION_PERFORMANCE_TIMEOUT      :8;
            uint8_t SA_AGENT_CERT_UPDATE_PERFORMANCE_TIMEOUT            :8;
            uint8_t SA_AGENT_AUTHORIZE_RESP_TIMEOUT                     :8;
            uint16_t RESERVED_48_63                                     :16;
        };
    };
} CANID_H15ECD003;

/* SECC SA Communication Status */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SA_AGENT_INIT_RESULT                                :8;
            uint8_t SA_AGENT_INIT_DETAILS                               :8;
            uint8_t SA_AGENT_CERT_INSTALLATION_DETAILS                  :8;
            uint8_t SA_AGENT_CERT_UPDATE_DETAILS                        :8;
            uint8_t SA_AGENT_AUTHORIZE_RESP_DETAILS                     :8;
            uint32_t RESERVED_40_63                                     :24;
        };
    };
} CANID_H15ECD101;

/* SECC IP Status */
typedef struct {
    union {
        uint8_t BYTE_ARRAY_FIELD[8];
        struct {
            uint8_t SECC_IP_ADDR_1                                      :8;
            uint8_t SECC_IP_ADDR_2                                      :8;
            uint8_t SECC_IP_ADDR_3                                      :8;
            uint8_t SECC_IP_ADDR_4                                      :8;
            uint32_t RESERVED_32_63                                     :32;
        };
    };
} CANID_H15ECD102;

#pragma pack(pop)


#endif /* AP_PEPPERMINT4XCAN_H_ */

/*
 * Secc.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_SECC_H_
#define AP_SECC_H_

#include "EventControl.h"
#include "GW_Message.h"

typedef osTimerId       GW_CONTROLSeccMailBoxId;

osStatus GW_SeccInit(void);
void GW_SeccDeInit(void);
void GW_Secc_NVIC_Init(void);
void GW_Secc_NVIC_DeInit(void);
void GW_SeccStart(void);
void GW_SeccStop(void);
void GW_SeccTransmitActivation(void);
void GW_SeccTransmitDeActivation(void);
osTimerId GW_SeccAttachCanMessage(os_timer_type type, uint32_t ms, GW_Message aMsg[]);
void GW_SeccDeteachCanMessage(osTimerId timerId);

void GW_SeccRxFifo0MsgPendingCallback(void);


#ifdef _ALEX_CMSIS_V2_
void SeccTransmitTask(void *arguments);
#else
void SeccTransmitTask(void const *argument);
#endif

#endif /* AP_SECC_H_ */

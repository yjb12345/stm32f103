/*
 * EvseConfig.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EVSECONFIG_H_
#define AP_EVSECONFIG_H_

// #ifndef _CMSIS_OS_H
// #include <FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h>
// #endif
////#include "cmsis_os.h"
// #include "stm32f1xx.h"
// #include "stm32f1xx_hal.h"
#include "stm32h7xx.h"
#include "stm32h7xx_hal.h"
#include <cmsis_os.h>
#include "assert.h"

//************** ALEX DEFINITION ****************************
// Fixme alex....

#define APPLICATION_INFO "GW EVSE 1.0.1"
#define SOFTWARE_VERSION 0x004

#define GW_OK osOK
#define GW_ERROR osErrorOS
#define GW_Status osStatus
#define GW_CONTROLStatus osStatus

#if 0
alex added for checking
SeccCanHandle.Init.SyncJumpWidth  = GW_SECC_CAN_SWJ;		// #define GW_SECC_CAN_SWJ  (CAN_SJW_1TQ)
                                        //  #define CAN_SJW_1TQ       (0x00000000U)   // !< 1 time quantum
SeccCanHandle.Init.TimeSeg1     GW_SECC_CAN_BS1;
                              //#define GW_SECC_CAN_BS1	(CAN_BS1_10TQ)
                              // #define CAN_BS1_10TQ    ((uint32_t)(CAN_BTR_TS1_3 | CAN_BTR_TS1_0)) //!< 10 time quantum
                              // #define CAN_BTR_TS1_3   (0x8UL << CAN_BTR_TS1_Pos)         // !< 0x00080000
                              // #define CAN_BTR_TS1_0   (0x1UL << CAN_BTR_TS1_Pos)         // !< 0x00010000
                              // #define CAN_BTR_TS1_Pos (16U)

SeccCanHandle.Init.TimeSeg2             = GW_SECC_CAN_BS2;
                              //#define GW_SECC_CAN_BS2   (CAN_BS2_1TQ)
                              //  CAN_BS2_1TQ  : #define CAN_BS1_1TQ     0x00000000U  // !< 1 time quantum
#endif

typedef enum
{
  GW_STOP = -1,
  GW_INITIALIZE = 0,
  GW_READY,
  GW_RUNNING,
} GW_CONTROLStateEnum;

#define ANSI_COLOR_RED (0x031)
#define ANSI_COLOR_GREEN (0x032)
#define ANSI_COLOR_YELLOW (0x033)
#define ANSI_COLOR_BLUE (0x034)
#define ANSI_COLOR_MAGENTA (0x035)
#define ANSI_COLOT_CYAN (0x036)

/**
 * UART CONSOLE : Debug
 */
#define GW_CONSOLE_INSTANCE (USART1)
#define GW_CONSOLE_BAUDRATE (115200)
#define GW_CONSOLE_IRQn (USART1_IRQn)

/**
 * CAN 500Kbps : EVCC
 * CAN Calculator: http://www.bittiming.can-wiki.info/#bxCAN
 * We choice 87.5%'s sampling point. (CANOpen)
 */
#ifdef _GRIDWIZ_CAN_USED_
#define GW_SECC_CAN_INSTANCE (CAN1)
#define GW_SECC_CAN_PRESCALER (6)
#define GW_SECC_CAN_SWJ (CAN_SJW_1TQ)
#define GW_SECC_CAN_BS1 (CAN_BS1_10TQ)
#define GW_SECC_CAN_BS2 (CAN_BS2_1TQ)
#define GW_SECC_RX0_IRQn (CAN1_RX0_IRQn)
#define GW_SECC_CAN_FILTER_MASK (0x15EC0000)
#endif

#ifdef _ALEX_FDCAN_USED_
#define GW_SECC_CAN_FILTER_MASK (0x15EC0000)
#endif

/**
 * CAN 125Kbps : POWER MODULE (INFY POWER)
 * CAN Calculator: http://www.bittiming.can-wiki.info/#bxCAN
 * We choice 87.5%'s sampling point. (CANOpen)
 */
#define GW_POWER_MODULE_CAN_INSTANCE (CAN2)
#define GW_POWER_MODULE_CAN_PRESCALER (21)
#define GW_POWER_MODULE_CAN_SWJ (CAN_SJW_1TQ)
#define GW_POWER_MODULE_CAN_BS1 (CAN_BS1_13TQ)
#define GW_POWER_MODULE_CAN_BS2 (CAN_BS2_2TQ)
#define GW_POWER_MODULE_RX0_IRQn (CAN2_RX0_IRQn)

/* RX485_1 */
#define GW_RS485_1_INSTANCE (USART1)
#define GW_RS485_1_BAUDRATE (9600)
#define GW_RS485_1_WORDLENGTH (UART_WORDLENGTH_8B)
#define GW_RS485_1_STOP_BIT (UART_STOPBITS_1)
#define GW_RS485_1_PARITY_BIT (UART_PARITY_NONE)
#define GW_RS485_1_HWCONTROL (UART_HWCONTROL_RTS)
#define GW_RS485_1_EN_GPIO_Port (GPIOD)
#define GW_RS485_1_EN_pin (GPIO_PIN_4)
#define GW_RS485_1_IRQn (USART1_IRQn)

/* RX485_2 */
#define GW_RS485_2_INSTANCE (UART5)
#define GW_RS485_2_BAUDRATE (9600)
#define GW_RS485_2_WORDLENGTH (UART_WORDLENGTH_8B)
#define GW_RS485_2_STOP_BIT (UART_STOPBITS_1)
#define GW_RS485_2_PARITY_BIT (UART_PARITY_NONE)
#define GW_RS485_2_HWCONTROL (UART_HWCONTROL_NONE)
#define GW_RS485_2_EN_GPIO_Port (GPIOD)
#define GW_RS485_2_EN_pin (GPIO_PIN_9)
#define GW_RS485_2_IRQn (UART5_IRQn)

/* MT4x RS485 METER */
#define GW_METER_MT4x_INSTANCE GW_RS485_2_INSTANCE
#define GW_METER_MT4x_BAUDRATE GW_RS485_2_BAUDRATE
#define GW_METER_MT4x_WORDLENGTH GW_RS485_2_WORDLENGTH
#define GW_METER_MT4x_STOP_BIT GW_RS485_2_STOP_BIT
#define GW_METER_MT4x_PARITY_BIT GW_RS485_2_PARITY_BIT
#define GW_METER_MT4x_HWCONTROL GW_RS485_2_HWCONTROL
#define GW_METER_MT4x_DE_PORT GW_RS485_2_EN_GPIO_Port
#define GW_METER_MT4x_DE_PIN GW_RS485_2_EN_pin
#define GW_METER_MT4x_IRQn GW_RS485_2_IRQn

/* HIGH VOLTAGE RELAY */
#define GW_RELAY_PORT (EVRLY_ON_GPIO_Port)
#define GW_RELAY_PIN (EVRLY_ON_Pin)

#define GW_KEYCODE_A ('A')
#define GW_KEYCODE_D ('D')
#define GW_KEYCODE_E ('E')
#define GW_KEYCODE_I ('I')
#define GW_KEYCODE_O ('O')
#define GW_KEYCODE_Q ('Q')
#define GW_KEYCODE_S ('S')
#define GW_KEYCODE_T ('T')
#define GW_KEYCODE_U ('U')
#define GW_KEYCODE_R ('R')
#define GW_KEYCODE_PLUS ('+')
#define GW_KEYCODE_MINUS ('-')
#define GW_KEYCODE_O ('O')

/* LED */
#define EVSE_STATUS_LED_INSTANCE (STATUS_LED_GPIO_Port)
#define EVSE_STATUS_LED_PIN (STATUS_LED_Pin)
#define EVSE_LED1_INSTANCE (LED1_GPIO_Port)
#define EVSE_LED1_PIN (LED1_Pin)
#define EVSE_LED2_INSTANCE (LED2_GPIO_Port)
#define EVSE_LED2_PIN (LED2_Pin)

/* Optional ------------------------------------------------------------------*/

/* UART */
#define UART_INSTANCE (USART2)
#define UART_BAUDRATE (115200)
#define UART_WORDLENGTH (UART_WORDLENGTH_8B)
#define UART_STOP_BIT (UART_STOPBITS_1)
#define UART_PARITY_BIT (UART_PARITY_NONE)

#endif /* AP_EVSECONFIG_H_ */

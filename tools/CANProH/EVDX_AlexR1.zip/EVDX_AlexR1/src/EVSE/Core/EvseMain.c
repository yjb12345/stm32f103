/**
******************************************************************************
* @file           : EvseMain.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : EV CHARGER Program body
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

EvseMain.c is a module that implements the actual charging application of the charger.

Initialize each module,
Define Thread and Timer used by each module,
It defines the Callback functions of EventControl.

CAN messages sent to SECC are sent by 50ms, 200ms, and 500ms timers.

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "EvseMain.h"
#include "EvseContext.h"
#include "EvseProcess.h"
#include "Diagnostic.h"
#include "EventControl.h"
#include "GW_Message.h"
#include "Relay.h"
#include "Console.h"
#include "CableMonitor.h"
#include "Secc.h"
#include "PowerModule.h"
#include "IsolationMonitor.h"
#include "Tools.h"
#include <math.h>
#include <string.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define EVENT_SECC_STATUS_UPDATED 0x0001
#define EVENT_POWERPACK_UPDATED 0x0002

#define EVENT_ISOLATION_FAULT 0x0008
#define EVENT_KEY_A_PRESSED 0x0100          // Auth EIM Enable
#define EVENT_KEY_D_PRESSED 0x0200          // (Debug) Print Diagnostic
#define EVENT_KEY_E_PRESSED 0x0400          // Emergency Stop
#define EVENT_KEY_S_PRESSED 0x0800          // Start
#define EVENT_KEY_Q_PRESSED 0x1000          // Stop
#define EVENT_KEY_R_PRESSED 0x2000          // Renego
#define EVENT_KEY_PLUS_PRESSED 0x4000       // +
#define EVENT_KEY_MINUS_PRESSED 0x8000      // -
#define EVENT_KEY_RELAY_OFF_PRESSED 0x10000 // Relay On/Off Force

#define EVENT_MASK (EVENT_KEY_A_PRESSED |         \
                    EVENT_KEY_D_PRESSED |         \
                    EVENT_KEY_E_PRESSED |         \
                    EVENT_KEY_S_PRESSED |         \
                    EVENT_KEY_Q_PRESSED |         \
                    EVENT_KEY_R_PRESSED |         \
                    EVENT_KEY_PLUS_PRESSED |      \
                    EVENT_KEY_MINUS_PRESSED |     \
                    EVENT_KEY_RELAY_OFF_PRESSED | \
                    EVENT_SECC_STATUS_UPDATED |   \
                    EVENT_POWERPACK_UPDATED |     \
                    EVENT_ISOLATION_FAULT)
/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
static volatile uint32_t State = GW_INITIALIZE;
static uint32_t SeccTick = 0;

#ifdef _ALEX_CMSIS_V2_
osThreadId_t ChargeTaskId;
osThreadId_t CableMonitorTaskId;
osThreadId_t ConsoleTaskId;
osThreadId_t EventLoopTaskId;
osThreadId_t PowerModuleTransmitTaskId;
osThreadId_t SeccTransmitTaskId;

osTimerId PeriodicTimer50ms;
osTimerId PeriodicTimer200ms;
osTimerId PeriodicTimer500ms;
osTimerId PeriodicTimer1000ms;
#define osThreadId osThreadId_t
#else
osThreadId ChargeTaskId;
osThreadId CableMonitorTaskId;
osThreadId ConsoleTaskId;
osThreadId EventLoopTaskId;
osThreadId PowerModuleTransmitTaskId;
osThreadId SeccTransmitTaskId;

osTimerId PeriodicTimer50ms;
osTimerId PeriodicTimer200ms;
osTimerId PeriodicTimer500ms;
osTimerId PeriodicTimer1000ms;

#endif

/* Private function prototypes -----------------------------------------------*/
static void ChargeTask(void const *arguments);
static SECC_STATUS_CODE ChargerSystemChecker(uint32_t currentTick);

// osThreadId_t AlexCreateThread(osThreadFunc_t func, char *name, uint32_t stack_size, osPriority_t priority:osPriorityBelowNormal )
osThreadId_t AlexCreateThread(osThreadFunc_t func, char *name, uint32_t stack_size, osPriority_t priority)
{
  const osThreadAttr_t attr = {
      .name = name,
      .stack_size = stack_size,
      //.priority = (osPriority_t)osPriorityBelowNormal,
      .priority = priority,
  };
  osThreadId_t id = osThreadNew(func, NULL, &attr);
  if (id == NULL)
  {
    printf("Thread %s is NULL\n\r", attr.name);
    while (1)
      ;
  }
  return id;
}
/* Exported functions --------------------------------------------------------*/
void ChargerProgramInfo()
{
  TRACE_INFO("                                                           ");
  TRACE_INFO("===========================================================");
  TRACE_INFO("                                                           ");
  TRACE_INFO(" ######   ########  #### ########  ##      ## #### ########");
  TRACE_INFO("##    ##  ##     ##  ##  ##     ## ##  ##  ##  ##       ## ");
  TRACE_INFO("##        ##     ##  ##  ##     ## ##  ##  ##  ##      ##  ");
  TRACE_INFO("##   #### ########   ##  ##     ## ##  ##  ##  ##     ##   ");
  TRACE_INFO("##    ##  ##   ##    ##  ##     ## ##  ##  ##  ##    ##    ");
  TRACE_INFO("##    ##  ##    ##   ##  ##     ## ##  ##  ##  ##   ##     ");
  TRACE_INFO(" ######   ##     ## #### ########   ###  ###  #### ########");
  TRACE_INFO("                                                           ");
  TRACE_INFO("===========================================================");
  TRACE_INFO("Application : %s", APPLICATION_INFO);
  TRACE_INFO("Build Date  : %s %s", __DATE__, __TIME__);
  TRACE_INFO("===========================================================");
}

void EVSE_Init()
{
  GW_RelayInit(RELAY_OPEN); /** Oepn the HighVoltage Relay */
  ChargerContextInit();     /** EVSE Context Initialize */
  GW_ConsoleInit();         /** Debug Console Task Init */
  GW_Console_NVIC_Init();   /** Program Info Out **/

  // ChargerProgramInfo();

  GW_LoopInit(); /** EventControl Task Init */
  GW_SeccInit(); /** SECC Modem Module Init */
  GW_Secc_NVIC_Init();

  GW_CableMonitorInit(); /** Cable Measure(voltage, current) Module Init */
  GW_CableMonitorSetResponseSpeed(CABLE_MONITOR_RESPONSE_TIME);

  GW_PowerModuleInit(); /** Power Convertor Module Init */
  GW_PowerModule_NVIC_Init();
  GW_PowerModuleSetResponseSpeed(POWER_MODULE_RESPONSE_TIME);
  GW_PowerModuleSetMaximunOutput(EVSE_MAX_VOLTAGE_LIMIT,
                                 EVSE_MAX_CURRENT_LIMIT);

  GW_IsolationMonitorInit(); /** Isolation Monitor Init */

#ifdef _ALEX_CMSIS_V2_
  // ConsoleTaskId = AlexCreateThread(ConsoleTask, "ConsoleTask", 128 * 4);

  EventLoopTaskId = AlexCreateThread(EventLoopTask, "EventLoopTask", 128 * 12, osPriorityHigh7);
  ChargeTaskId = AlexCreateThread(ChargeTask, "ChargeTask", 128 * 12, osPriorityBelowNormal);
  SeccTransmitTaskId = AlexCreateThread(SeccTransmitTask, "SeccTransmitT", 128 * 8, osPriorityHigh7);
  CableMonitorTaskId = AlexCreateThread(CableMonitorTask, "CableMonitorT", 128 * 8, osPriorityBelowNormal);
  PowerModuleTransmitTaskId = AlexCreateThread(PowerModuleTransmitTask, "PowerModuleT", 128 * 4, osPriorityBelowNormal);
  ConsoleTaskId = AlexCreateThread(ConsoleTask, "ConsoleTask", 128 * 4, osPriorityBelowNormal);

#else
  /** Thread define **/
  osThreadDef(EventLoopThread, EventLoopTask, osPriorityAboveNormal, 0, 128 * 2);
  osThreadDef(ChargeThread, ChargeTask, osPriorityNormal, 0, 256);

  osThreadDef(SeccTransmitThread, SeccTransmitTask, osPriorityNormal, 0, 128);
  osThreadDef(CableMonitorThread, CableMonitorTask, osPriorityNormal, 0, 128);

  osThreadDef(PowerModuleTransmitThread, PowerModuleTransmitTask, osPriorityNormal, 0, 128);
  osThreadDef(ConsoleThread, ConsoleTask, osPriorityBelowNormal, 0, 128);

  // Thread Create
  /** Thread Create **/
  EventLoopTaskId = osThreadCreate(osThread(EventLoopThread), NULL);
  ChargeTaskId = osThreadCreate(osThread(ChargeThread), NULL);
  SeccTransmitTaskId = osThreadCreate(osThread(SeccTransmitThread), NULL);
  CableMonitorTaskId = osThreadCreate(osThread(CableMonitorThread), NULL);
  PowerModuleTransmitTaskId = osThreadCreate(osThread(PowerModuleTransmitThread), NULL);
  // ConsoleTaskId = osThreadCreate(osThread(ConsoleThread), NULL);
#endif

  /** EVSE Tx Periodic Can Message Timer */
  GW_Message *_50ms_msg;
  GW_Message *_200ms_msg;
  GW_Message *_500ms_msg;
  GW_Message *_1000ms_msg;

  _50ms_msg = _50ms_MessageGet();
  _200ms_msg = _200ms_MessageGet();
  _500ms_msg = _500ms_MessageGet();
  _1000ms_msg = _1000ms_MessageGet();

  PeriodicTimer50ms = GW_SeccAttachCanMessage(osTimerPeriodic, 50, _50ms_msg);
  PeriodicTimer200ms = GW_SeccAttachCanMessage(osTimerPeriodic, 200, _200ms_msg);
  PeriodicTimer500ms = GW_SeccAttachCanMessage(osTimerPeriodic, 500, _500ms_msg);
  PeriodicTimer1000ms = GW_SeccAttachCanMessage(osTimerPeriodic, 1000, _1000ms_msg);
}

void EVSE_Start()
{
  GW_CableMonitorStart();
  GW_SeccStart();
  GW_PowerModuleStart();
  GW_ConsoleRxNotifyActivation();
}

void EVSE_Stop()
{
  GW_PowerModuleStop();
  GW_SeccStop();
  GW_CableMonitorStop();
}

void EVSE_DeInit(void)
{
  ;
}

static void ChargeTask(void const *argument)
{
  printf("ChargeTask  start\n\r");
#ifdef _THREAD_TEST_ONLY_
  for (;;)
  {
    printf("ChargeTask running\n\r");
    osDelay(3000);
  }
#endif
  uint32_t tick = 0x0;
  SECC_STATUS_CODE state;
  osEvent evt;
  uint32_t alex_flags;
  uint32_t maxCurrent = ChargerGetMaximumCurrentLimit();

  ChargerContext *chargerCtx;
  chargerCtx = ChargerContextGet();

  /** Wait a initialize process */
  state = ChargeStateSet(chargerCtx, SECC_STATUS_IDLE);

  while (1)
  {
    /** Check CHARGER System: Cable VI, SECC, PowerModule **/
    state = ChargerSystemChecker(tick);
    // printf("ChargeTask  state=%d\n\r", state);
    // osDelay(1000);

    /** CHARGER Charging Process **/
    switch (state)
    {
    case SECC_STATUS_IDLE:
      state = ChargeStateIdle(chargerCtx);
      break;

    case SECC_STATUS_INITIALIZED:
      state = ChargeStateInitialized(chargerCtx);
      break;

    case SECC_STATUS_WAITING_PLUG_IN:
      state = ChargeStateWaitPlugIn(chargerCtx);
      break;

    case SECC_STATUS_WAITING_SLAC:
      state = ChargeStateWaitingSLAC(chargerCtx);
      break;

    case SECC_STATUS_PROCESSING_SLAC:
      state = ChargeStateProcessingSLAC(chargerCtx);
      break;

    case SECC_STATUS_SDP:
      state = ChargeStateSDP(chargerCtx);
      break;

    case SECC_STATUS_ESTABLISHING_TCP_TLS:
      state = ChargeStateEstablishingTCP(chargerCtx);
      break;

    case SECC_STATUS_SAP:
      state = ChargeStateSAP(chargerCtx);
      break;

    case SECC_STATUS_SESSION_SETUP:
      state = ChargeStateSessionSetup(chargerCtx);
      break;

    case SECC_STATUS_SESSION_STOP_TERMINATE:
      state = ChargeStateSessionStop(chargerCtx);
      break;

    case SECC_STATUS_SESSION_STOP_PAUSE:
      //
      break;

    case SECC_STATUS_SERVICE_DISCOVERY:
      state = ChargeStateServiceDiscovery(chargerCtx);
      break;

    case SECC_STATUS_SERVICE_DETAILS:
      state = ChargeStateServiceDetails(chargerCtx);
      break;

    case SECC_STATUS_PAYMENT_SERVICE_SELECTION:
      state = ChargeStatePaymentServiceSelection(chargerCtx);
      break;

    case SECC_STATUS_CERTIFICATE_INSTALLATION:
      state = ChargeStateCertificateInstallation(chargerCtx);
      break;

    case SECC_STATUS_CERTIFICATE_UPDATE:
      state = ChargeStateCertificateUpdate(chargerCtx);
      break;

    case SECC_STATUS_PAYMENT_DETAILS:
      state = ChargeStatePaymentDetails(chargerCtx);
      break;

    case SECC_STATUS_AUTHORIZATION_EIM:
      state = ChargeStateAuthorizationEIM(chargerCtx);
      break;

    case SECC_STATUS_AUTHORIZATION_PnC:
      state = ChargeStateAuthorizationPnC(chargerCtx);
      break;

    case SECC_STATUS_CHARGE_PARAMETER_DISCOVERY:
      state = ChargeStateChargeParameterDiscovery(chargerCtx);
      break;

    case SECC_STATUS_CABLE_CHECK:
      state = ChargeStateCableCheck(chargerCtx);
      break;

    case SECC_STATUS_PRE_CHARGE:
      state = ChargeStatePreCharge(chargerCtx);
      break;

    case SECC_STATUS_WELDING_DETECTION:
      state = ChargeStateWeldingDetection(chargerCtx);
      break;

    case SECC_STATUS_POWER_DELIVERY_START:
      state = ChargeStatePowerDeliveryStart(chargerCtx);
      break;

    case SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP:
      state = ChargeStatePowerDeliveryEvInitStop(chargerCtx);
      break;

    case SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP:
      state = ChargeStatePowerDeliveryEvseInitStop(chargerCtx);
      break;

    case SECC_STATUS_POWER_DELIVERY_RENEGOTIATE:
      state = ChargeStatePowerDeliveryRenego(chargerCtx);
      break;

    case SECC_STATUS_CURRENT_DEMAND:
      state = ChargeStateCurrentDemand(chargerCtx);
      break;

    case SECC_STATUS_METERING_RECEIPT:
      //
      break;

    case SECC_STATUS_TERMINATE:
      state = ChargeStateTerminate(chargerCtx);
      break;

    case SECC_STATUS_PAUSE:
      //
      break;

    case SECC_STATUS_ERROR:
      state = ChargeStateError(chargerCtx);
      break;
    }
    tick = xTaskAlexGetTickCount();

    /** Event Signal Process  **/

#ifdef _ALEX_CMSIS_V2_
    alex_flags = osThreadFlagsWait(EVENT_MASK, osFlagsWaitAny, 150);

    // ChargerPrintDiagInfo(); // TOBE REMOVED
    // osFlagsErrorTimeout
    if (alex_flags != osFlagsErrorTimeout)
    {
      printf("EvseMain ChargeTask Got alex_flags = %d\n\r", alex_flags);
      switch (alex_flags)
#else
    evt = osSignalWait(EVENT_MASK, 150);
    if (evt.status == osEventSignal)
    {
      switch (evt.value.signals)
#endif

      {
      case EVENT_KEY_A_PRESSED: /* EIM Pass */
        if (state == SECC_STATUS_AUTHORIZATION_EIM)
        {
          chargerCtx->EVSE_STATUS.EVSE_PROCESSING_AUTH_EIM = EVSE_PROC_FINISHED;
          TRACE_TRACE("EIM INSERTED");
        }
        break;

      case EVENT_KEY_D_PRESSED: /* Diganostic Message */
      {
        ChargerPrintDiagInfo();
      }
      break;

      case EVENT_KEY_E_PRESSED: /* Emergency Stop */
      {
        chargerCtx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;
        TRACE_TRACE("KEY EVENT: EMERGENCY STOP");
      }
      break;

      case EVENT_KEY_S_PRESSED: /* Charge Start */
        if (state == SECC_STATUS_INITIALIZED)
        {
          chargerCtx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_START_CHARGING;
          TRACE_TRACE("KEY EVENT: CHARGING START");
        }
#ifdef _ALEX_CMSIS_V2_
        // fixMe: alex added
        else
        {
          TRACE_TRACE("ChargeTsk KEY EVENT: CHARGING Not START-> state != SECC_STATUS_INITIALIZED");
          TRACE_TRACE("state  =%d", state);
        }
#endif
        break;

      case EVENT_KEY_Q_PRESSED: /* Normal Stop */
        if (state > SECC_STATUS_INITIALIZED && state != SECC_STATUS_TERMINATE)
        {
          chargerCtx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_NORMAL_STOP;
          TRACE_TRACE("KEY EVENT: CHARGING STOP");
        }
        break;

      case EVENT_KEY_R_PRESSED: /* Renogotiation */
        if (state == SECC_STATUS_CURRENT_DEMAND)
        {
          chargerCtx->EVSE_STATUS.TRIGGER_RE_NEGOTIATION = EVSE_TRIGGER_RENEGO_REQUEST;
          TRACE_TRACE("KEY EVENT: RENEGOCIATION");
        }
        break;

      case EVENT_KEY_PLUS_PRESSED: /* Power up */
        if (maxCurrent >= EVSE_MAX_CURRENT_LIMIT)
          maxCurrent = EVSE_MAX_CURRENT_LIMIT;
        else
          maxCurrent += 1000; // 1A resolution;

        ChargerSetMaximumCurrentLimit(maxCurrent);
        TRACE_TRACE("MAX CURRENT LIMIT: %3.1f A", ChargerGetMaximumCurrentLimit() / pow(10, 3));
        TRACE_TRACE("MAX POWER   LIMIT: %d W", ChargerGetMaximumPowerLimit());
        break;

      case EVENT_KEY_MINUS_PRESSED: /* Power Down */
        if (maxCurrent <= EVSE_MIN_CURRENT_LIMIT)
          maxCurrent = EVSE_MIN_CURRENT_LIMIT;
        else
          maxCurrent -= 1000; // 1A resolution;

        ChargerSetMaximumCurrentLimit(maxCurrent);
        TRACE_TRACE("MAX CURRENT LIMIT: %3.1f A", ChargerGetMaximumCurrentLimit() / pow(10, 3));
        TRACE_TRACE("MAX POWER   LIMIT: %d W", ChargerGetMaximumPowerLimit());
        break;

      case EVENT_ISOLATION_FAULT: /* Isolation Fault */
      {
        chargerCtx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;
        TRACE_TRACE("ISOLATION EVENT : CHARGING STOP");
      }

      break;

      case EVENT_SECC_STATUS_UPDATED: /* SECC Check */
        SeccTick = xTaskAlexGetTickCount();
        if (IsChargeErrorOrTeminate(chargerCtx))
        {
          state = ChargeStateSet(chargerCtx, SECC_STATUS_TERMINATE);
        }
        else if (IsChargeStateRenogo(chargerCtx))
        {
          state = ChargeStateSet(chargerCtx, SECC_STATUS_POWER_DELIVERY_RENEGOTIATE);
        }
        break;
      }
    }
  }
}

/********** Privated Functions ***********/

static SECC_STATUS_CODE ChargerSystemChecker(uint32_t currentTick)
{
  ChargerContext *chargerCtx;
  chargerCtx = ChargerContextGet();

  /* First Check */
  if (currentTick == 0)
    return chargerCtx->NextState;

    //  TRACE_DEBUG("alex STATE TRANSITION SeccTick =%d  currentTick) =%d", SeccTick, currentTick);

#if 0
  uint32_t xx = osKernelGetTickCount();
  TRACE_ERROR("osKernelGetTickCount =%d", osKernelGetTickCount());
#endif

  /* Secc Comm Check */
  if ((chargerCtx->NextState > SECC_STATUS_IDLE) && diffTick(SeccTick, currentTick) > 1000)
  {
    TRACE_ERROR("SECC FAULT: SECC [%u][%u][%u]",
                SeccTick, currentTick, diffTick(SeccTick, currentTick));
    return SECC_STATUS_ERROR;
  }

  /* Check State Transition */
  if (chargerCtx->CurrState != chargerCtx->NextState)
  {
    TRACE_DEBUG("STATE TRANSITION [%s]->*[%s]*->[%s]",
                SeccStateString(chargerCtx->PrevState), SeccStateString(chargerCtx->CurrState), SeccStateString(chargerCtx->NextState));
  }

  // TRACE_DEBUG("alex STATE TRANSITION curState =%d  nextState =%d", chargerCtx->CurrState, chargerCtx->NextState);

  return chargerCtx->NextState;
}

/********** Event Control Callback Functions ***********/

void GW_CheckIsolationCpltCallback(uint16_t IsolationStatus)
{
  ChargerContext *chargerCtx;
  chargerCtx = ChargerContextGet();

  chargerCtx->EVSE_STATUS.EVSE_ISOLATION_STATUS = IsolationStatus;
#ifdef _ALEX_CMSIS_V2_
  if (chargerCtx->EVSE_STATUS.EVSE_ISOLATION_STATUS == ISOLATION_FAULT)
    osThreadFlagsSet(ChargeTaskId, EVENT_ISOLATION_FAULT);
#else
  if (chargerCtx->EVSE_STATUS.EVSE_ISOLATION_STATUS == ISOLATION_FAULT)
    osSignalSet(ChargeTaskId, EVENT_ISOLATION_FAULT);
#endif
}

void GW_CableMonitorCpltCallback(uint32_t id, int32_t value, uint32_t scale)
{
  ChargerContext *chargerCtx;
  chargerCtx = ChargerContextGet();

  /** Update EV CHARGE PRESENT VI Context */
  if (id == 0x01)
  {
    chargerCtx->EVSE_PRESENT_VOLTAGE_CURRENT.EVSE_PRESENT_VOLTAGE = (int16_t)(value / pow(scale / 10, 1));
  }
  else if (id == 0x02)
  {
    chargerCtx->EVSE_PRESENT_VOLTAGE_CURRENT.EVSE_PRESENT_CURRENT = (int16_t)(value / pow(scale / 10, 1));
  }
}

void GW_SeccRxCpltCallback(uint32_t id, uint8_t *data, uint32_t size)
{
  GW_Message *Rx_msg;
  Rx_msg = _Rx_MessageGet();

  printf("GW_SeccRxCpltCallback #1\n\r");
  /** Update EV CHARGE SECC Context */
  uint32_t i = 0;

  /** Activate SECC CAN transmission when SECC CAN data is received. */
  GW_SeccTransmitActivation();

  while (Rx_msg[i].Data)
  {
    if (id == Rx_msg[i].Id)
    {
      memcpy(Rx_msg[i].Data, data, size);
      break;
    }
    i++;
  }

  /* SECC STATUS MESSAGE */
#ifdef _ALEX_CMSIS_V2_
  if (id == CAN_ID_H15ECC101)
    osThreadFlagsSet(ChargeTaskId, EVENT_SECC_STATUS_UPDATED);
#else
  if (id == CAN_ID_H15ECC101)
    osSignalSet(ChargeTaskId, EVENT_SECC_STATUS_UPDATED);
#endif
}

#pragma pack(push, 1)
typedef union
{
  uint8_t b[4];
  float f;
  uint32_t u;
} Float;
#pragma pack(pop)

void GW_PowerModuleRxCpltCallback(uint32_t id, uint8_t *data, uint32_t size)
{
  ChargerContext *chargerCtx;
  chargerCtx = ChargerContextGet();

  InfyPowerState *infyPowerState;

  if (id == 0x0281f03f)
  {
    Float voltage;
    Float current;

    memcpy(voltage.b, data, 4);
    memcpy(current.b, data + 4, 4);

    voltage.u = SWAP32(voltage.u);
    current.u = SWAP32(current.u);

    chargerCtx->PowerModuleOutputVoltage = (int32_t)(voltage.f * 1000);
    chargerCtx->PowerModuleOutputCurrent = (int32_t)(current.f * 1000);
  }
  else if (id == 0x0284F000)
  {
    infyPowerState = (InfyPowerState *)data;
    chargerCtx->PowerModuleModuleTemprature = infyPowerState->ModuleTemprature;
  }
  else if (id == 0x0284F001)
  {
    infyPowerState = (InfyPowerState *)data;
  }
  else if (id == 0x0284F002)
  {
    infyPowerState = (InfyPowerState *)data;
  }
  else if (id == 0x0284F003)
  {
    infyPowerState = (InfyPowerState *)data;
  }
}

void GW_KeyPressedCallback(uint8_t keyCode)
{
  if (keyCode == GW_KEYCODE_A)
  {
    TRACE_DEBUG("KEY A PRESSED");

#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_A_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_A_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_D)
  {
    TRACE_DEBUG("KEY D PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_D_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_D_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_E)
  {
    TRACE_DEBUG("KEY E PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_E_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_E_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_S)
  {
    TRACE_DEBUG("KEY S PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_S_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_S_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_Q)
  {
    TRACE_DEBUG("KEY Q PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_Q_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_Q_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_R)
  {
    TRACE_DEBUG("KEY R PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_R_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_R_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_PLUS)
  {
    TRACE_DEBUG("KEY PLUS PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_PLUS_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_PLUS_PRESSED);
#endif
  }
  else if (keyCode == GW_KEYCODE_MINUS)
  {
    TRACE_DEBUG("KEY MINUS PRESSED");
#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(ChargeTaskId, EVENT_KEY_MINUS_PRESSED);
#else
    osSignalSet(ChargeTaskId, EVENT_KEY_MINUS_PRESSED);
#endif
  }
}

/*
 * EventControl.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : EventControl.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Liv EV Infra Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

EventControl.c is a module that controls the reception of main events of the charger.
Receive events with the message queue structure of CMSIS V1.

**** CONSOLE KEY input reception processing
**** SECC CAN message reception processing
**** POWER MODULE CAN message reception processing
**** METER message reception processing
**** ISOLATION check message reception processing

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "EventControl.h"
#include "GW_Message.h"
#include "Console.h"
#include "CableMonitor.h"
#include "Tools.h"
#include "main.h"

typedef struct
{
    uint32_t Timestamp;
    GW_CONTROLEventType Type;
    osPoolId UserMP;
    void *UserData;
} GW_CONTROLEventMessage;

/* Private variables ---------------------------------------------------------*/

#ifdef _ALEX_CMSIS_V2_
// static osMemoryPoolId_t EventMessagePool;
// static osMessageQueueId_t EventQ;
osMemoryPoolId_t EventMessagePool;
osMessageQueueId_t EventQ;

#else
static osPoolId EventMessagePool;
static osMessageQId EventQ;

osPoolDef(GW_CONTROLMP, 50, GW_CONTROLEventMessage);
osMessageQDef(GW_CONTROLMQ, 50, GW_CONTROLEventMessage);
#endif
/* Exported functions --------------------------------------------------------*/
void GW_LoopInit()
{
#ifdef _ALEX_CMSIS_V2_
    EventMessagePool = osMemoryPoolNew(60, sizeof(GW_CONTROLEventMessage), NULL);
    if (EventMessagePool == NULL)
    {
        printf("GW_CONTROLEventMessage Memory pool creation failure\n\r");
    }
    EventQ = osMessageQueueNew(sizeof(GW_CONTROLEventMessage), 50, NULL);
    if (EventQ == NULL)
    {
        printf("osMessageQueueNew creation failure\n\r");
    }

#else
    /* MessageQ and MemoryPool */
    EventMessagePool = osPoolCreate(osPool(GW_CONTROLMP));
    EventQ = osMessageCreate(osMessageQ(GW_CONTROLMQ), NULL);
#endif
}
int myCount = 0;
void GW_LoopDeInit()
{
    ;
}
#ifdef _ALEX_CMSIS_V2_
osStatus_t GW_EventNotifySendWait(GW_CONTROLEventType type, osPoolId mpId, void *data, uint32_t ms)
#else
osStatus GW_EventNotifySendWait(GW_CONTROLEventType type, osPoolId mpId, void *data, uint32_t ms)
#endif
{

#ifdef _ALEX_CMSIS_V2_
    // printf("GW_EventNotifySendWait type=%d  myCount=%d\n\r", type, ++myCount);
    GW_CONTROLEventMessage *eventMsg = (GW_CONTROLEventMessage *)osMemoryPoolAlloc(EventMessagePool, osWaitForever);
    if (eventMsg != NULL)
    {
        eventMsg->Type = type;
        eventMsg->UserMP = mpId;
        eventMsg->UserData = data;
        // printf("GES 2\n\r");
        /* ISR HandlerMode */
        if (__get_IPSR() != 0)
            eventMsg->Timestamp = xTaskGetTickCountFromISR();
        else
            eventMsg->Timestamp = xTaskAlexGetTickCount();

        // printf("G 3\n\r");
        osStatus_t status = osMessageQueuePut(EventQ, &eventMsg, 0, ms);
        // printf("G ack status=%x\n\r", status);
        if (status != osOK)
        {
            // If the message queue is full or other error, free the memory block
            printf("osMessageQueuePut error=%x\n\r", status);
            osMemoryPoolFree(EventQ, eventMsg);
            return osErrorResource;
        }
        else
        {
            // printf(" \t\t==>Put OK\n\r");
            return osOK;
        }
    }
    else
    {
        printf("osErrorResource error\n\r");
        return osErrorResource;
    }

#else
    GW_CONTROLEventMessage *eventMsg;
    eventMsg = osPoolCAlloc(EventMessagePool);
    eventMsg->Type = type;
    eventMsg->UserMP = mpId;
    eventMsg->UserData = data;
    /* ISR HandlerMode */
    if (__get_IPSR() != 0)
    {
        eventMsg->Timestamp = xTaskGetTickCountFromISR();
    }
    else
    {
        eventMsg->Timestamp = xTaskAlexGetTickCount();
    }

    return osMessagePut(EventQ, (uint32_t)eventMsg, ms);
#endif
}

osStatus GW_EventNotify(GW_CONTROLEventType event)
{
#ifdef _OLD_BD
    return GW_EventNotifySendWait(event, NULL, NULL, 1);
#else
    return GW_EventNotifySendWait(event, NULL, NULL, 0);
#endif
}

osStatus GW_EventNotifySend(GW_CONTROLEventType event, osPoolId mpId, void *data)
{
    return GW_EventNotifySendWait(event, mpId, data, 1);
}

#ifdef _ALEX_CMSIS_V2_
void EventLoopTask(void *arguments)
#else
void EventLoopTask(void const *argument)
#endif
/* Private function ----------------------------------------------------------*/
// void EventLoopTask(void const *argument)
{
    printf("EventLoopTask  start\n\r");
#ifdef _THREAD_TEST_ONLY_
    for (;;)
    {
        printf("EventLoopTask running\n\r");
        osDelay(3000);
    }
#endif
    printf("EventLoopTask start\n\r");
    TickType_t seccTick = xTaskAlexGetTickCount();
    ;
    TickType_t powerModuleTick = xTaskAlexGetTickCount();
    ;
    TickType_t cableMonitorTick = xTaskAlexGetTickCount();
    ;
#if 1
    GW_CONTROLEventMessage *eventMsg;
#else
    GW_CONTROLEventMessage *eventMsg;
    osEvent evt;
#endif

#if 1
    printf("EventLoopTask Ready\n\r");
    for (;;)
    {
#ifdef _ALEX_CMSIS_V2_
        osStatus_t ret = osMessageQueueGet(EventQ, &eventMsg, NULL, osWaitForever);
        if (eventMsg->Type != 3)
        {
            printf(">>>>>>> EventLoopTask Got Type= %d\n\r", eventMsg->Type);
        }

        if (ret == osOK)
        {
#else
        evt = osMessageGet(EventQ, osWaitForever);
        if (evt.status == osEventMessage)
        {
            eventMsg = evt.value.p;
#endif
            switch (eventMsg->Type)
            {
            case GW_EVENT_KEY_PRESSED:
#ifdef _GRIDWIZ_CONSOLE_USED_
            {
                uint8_t ch = GW_ConsoleGetch();
                printf(">>>>>>> ch= %c\n\r", ch);
                GW_KeyPressedCallback(ch);
            }
#endif
            break;

            case GW_EVENT_SECC_CAN_RX_CPLT:
            {
                if (diffTick(seccTick, xTaskAlexGetTickCount()) > 200)
                {
                    seccTick = xTaskAlexGetTickCount();
                }
                GW_CanMessage *msg = (GW_CanMessage *)eventMsg->UserData;
                GW_SeccRxCpltCallback(msg->CanId, msg->CanData, sizeof(msg->CanData));
            }
            break;

            case GW_EVENT_POWER_MODULE_CAN_RX_CPLT:
            {
                if (diffTick(powerModuleTick, xTaskAlexGetTickCount()) > 200)
                {
                    // fixMe : alex marked
                    // HAL_GPIO_TogglePin(EVSE_LED1_INSTANCE, EVSE_LED1_PIN);
                    powerModuleTick = xTaskAlexGetTickCount();
                }
                HAL_GPIO_TogglePin(EVSE_LED1_INSTANCE, EVSE_LED1_PIN);
                GW_CanMessage *msg = (GW_CanMessage *)eventMsg->UserData;
                GW_PowerModuleRxCpltCallback(msg->CanId, msg->CanData, sizeof(msg->CanData));
            }
            break;

            case GW_EVENT_CABLE_MONITOR_CPLT:
            {
                if (diffTick(cableMonitorTick, xTaskAlexGetTickCount()) > 200)
                {
                    // HAL_GPIO_TogglePin(EVSE_LED2_INSTANCE, EVSE_LED2_PIN);
                    cableMonitorTick = xTaskAlexGetTickCount();
                }
                CableMonitorItem *item = (CableMonitorItem *)eventMsg->UserData;
                GW_CableMonitorCpltCallback(item->Id, item->Value, item->Scale);
            }
            break;

            case GW_EVENT_ISOLATION_CPLT:
            {
                ISOLATION_MSG *msg = (ISOLATION_MSG *)eventMsg->UserData;
                GW_CheckIsolationCpltCallback(msg->status);
            }

            break;

            default:
                break;
            }
#ifdef _ALEX_CMSIS_V2_
#if 1
            // printf("eventMsg  addr= %p= %d\n\r", eventMsg);
            // printf("eventMsg  UserMP= %d\n\r", eventMsg->UserMP);
            // printf("eventMsg  Timestamp= %d\n\r", eventMsg->Timestamp);
#endif
            /* Release User Message */
            if (eventMsg->UserMP)
                osMemoryPoolFree(eventMsg->UserMP, eventMsg->UserData);

            // alex : fieed for Bug #1, 2024.07.07
            osMemoryPoolFree(EventMessagePool, eventMsg);
#else
            /* Release User Message */
            if (eventMsg->UserMP)
                osPoolFree(eventMsg->UserMP, eventMsg->UserData);

            /* Release GW_CONTROL Message */
            osPoolFree(EventMessagePool, eventMsg);
#endif
        }
    }
#endif
}

/* (__weak) User function ----------------------------------------------------*/
__weak void GW_CableMonitorCpltCallback(uint32_t id, int32_t value, uint32_t scale)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(id);
    UNUSED(value);
    UNUSED(scale);

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_CableMonitorCpltCallback could be implemented in the user file
    */
}

__weak void GW_SeccRxCpltCallback(uint32_t id, uint8_t *data, uint32_t size)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(id);
    UNUSED(data);
    UNUSED(size);

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_SeccRxCpltCallback could be implemented in the user file
    */
}

__weak void GW_PowerModuleRxCpltCallback(uint32_t id, uint8_t *data, uint32_t size)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(id);
    UNUSED(data);
    UNUSED(size);

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_PowerModuleRxCpltCallback could be implemented in the user file
    */
}

__weak void GW_KeyPressedCallback(uint8_t keyCode)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(keyCode);

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_KeyPressedCallback could be implemented in the user file
    */
}

/*
 * GW_Message.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_GW_MESSAGE_H_
#define AP_GW_MESSAGE_H_

#include <stdint.h>
typedef struct {
  uint32_t      Id;
  void          *Data;
  char          *Nick;
} GW_Message;

typedef struct {
  uint32_t      CanId;
  uint8_t       CanData[8];
} GW_CanMessage;


#endif /* AP_GW_MESSAGE_H_ */

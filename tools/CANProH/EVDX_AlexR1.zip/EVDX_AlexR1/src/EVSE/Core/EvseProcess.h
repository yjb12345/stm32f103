/*
 * EvseProcess.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EVSEPROCESS_H_
#define AP_EVSEPROCESS_H_


#include "EvseContext.h"
#include "Diagnostic.h"

/* EvseProcess */
SECC_STATUS_CODE ChargeStateIdle(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateInitialized(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateWaitPlugIn(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateWaitingSLAC(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateProcessingSLAC(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateSDP(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateEstablishingTCP(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateSAP(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateSessionSetup(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateServiceDiscovery(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateServiceDetails(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePaymentServiceSelection(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateCertificateInstallation(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateCertificateUpdate(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePaymentDetails(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateAuthorizationEIM(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateAuthorizationPnC(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateChargeParameterDiscovery(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateCableCheck(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePreCharge(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePowerDeliveryStart(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateCurrentDemand(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePowerDeliveryRenego(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePowerDeliveryEvInitStop(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStatePowerDeliveryEvseInitStop(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateWeldingDetection(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateSessionStop(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateTerminate(ChargerContext *ctx);
SECC_STATUS_CODE ChargeStateError(ChargerContext *ctx);

uint32_t IsChargeErrorOrTeminate(ChargerContext *ctx);
uint32_t IsChargeStateRenogo(ChargerContext *ctx);
uint32_t IsChargeStateTrasition(ChargerContext *ctx);

SECC_STATUS_CODE ChargeStateSet(ChargerContext *ctx, SECC_STATUS_CODE state);
SECC_STATUS_CODE ChargeStateGet(ChargerContext *ctx);

#endif /* AP_EVSEPROCESS_H_ */

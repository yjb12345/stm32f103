/*
 * EvseProcess.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : EvseProcess.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : CHARGE State Process
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

EvseProcess.c is a module that organizes the process functions of the charger.
The actual processing part of each process is implemented.

******************************************************************************

Charging Flow
loop() {
+ Wait for user event or secc can packet (SECC STATUS)
+ Check SECC ERROR or TERMINATION
switch (ChargeState)
+ ChargeStateIdle                      -------> Need to CHARGING_CTRL_INITIALIZE_PARAMATERS
+ ChargeStateInitialized               -------> Need to CHARGING_CTRL_START_CHARGING (User Key Event 'S')
+ ChargeStateWaitPlugIn                -------> Need to User Timeout
+ ChargeStateWaitingSLAC               -------> Need to User Timeout
+ ChargeStateProcessingSLAC            -------> Need to User Timeout
+ ChargeStateSDP                       -------> Need to User Timeout
+ ChargeStateEstablishingTCP           -------> Need to User Timeout
+ ChargeStateSAP                       -------> Need to User Timeout
+ ChargeStateSessionSetup              -------> Need to User Timeout
+ ChargeStateServiceDiscovery          -------> Need to User Timeout
+ ChargeStateServiceDetails            -------> Need to User Timeout
+ ChargeStatePaymentServiceSelection   -------> Need to User Timeout
+ ChargeStateCertificateInstallation   -------> Need to User Timeout
+ ChargeStateCertificateUpdate         -------> Need to User Timeout
+ ChargeStatePaymentDetails            -------> Need to User Timeout
+ ChargeStateAuthorizationEIM          -------> Need to EVSE_STATUS.EVSE_PROCESSING_AUTH_EIM = EVSE_PROC_FINISHED (User Key Event 'A')
+ ChargeStateAuthorizationPnC          -------> Authentication User Timeout
+ ChargeStateChargeParameterDiscovery  -------> Pass (No Action)
+ ChargeStateCableCheck                -------> CableCheck User Timeout
+ ChargeStatePreCharge                 -------> PreCharge User Timeout
+ ChargeStatePowerDeliveryStart        -------> Need to User Timeout
+ ChargeStateCurrentDemand             -------> Need to CHARGING_CTRL_EVSE_INITIATED_NORMAL_STOP (User Key Event 'Q')
                                       -------> Need to CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP (User Key Event 'E')
+ ChargeStatePowerDeliveryRenego       -------> Need to EVSE_STATUS.TRIGGER_RE_NEGOTIATION = EVSE_TRIGGER_RENEGO_REQUEST (User Key Event 'R')
+ ChargeStatePowerDeliveryEvInitStop   -------> Need to User Timeout
+ ChargeStatePowerDeliveryEvseInitStop -------> Need to User Timeout
+ ChargeStateWeldingDetection          -------> Need to User Timeout
+ ChargeStateSessionStop               -------> Need to User Timeout
+ ChargeStateTerminate                 -------> Need to User Timeout
+ ChargeStateError                     ------->
   }

******************************************************************************
*/

#include "EvseProcess.h"
#include "Diagnostic.h"
#include "Relay.h"
#include "PowerModule.h"
#include "IsolationMonitor.h"
#include "Peppermint4xCan.h"
#include "Tools.h"
#include "Console.h"
#include <math.h>

SECC_STATUS_CODE ChargeStateIdle(ChargerContext *ctx)
{
    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_IDLE;

        if (ctx->CurrState == SECC_STATUS_TERMINATE)
        {
            ChargerPrintTerminationReason();
        }
        else
        {
            ChargerPrintDiagInfo();
            TRACE_TRACE("SECC_STATUS_IDLE");
        }

        /** HIGH VOLTAGE RELAY OPEN */
        GW_RelaySet(RELAY_OPEN);

        TRACE_INFO("PLEASE PUSH THE 'D' KEY TO CAPTURE DIAGNOSTIC INFO");
        /** CHANGE CHARGING CONTROL */
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_INITIALIZE_PPMT;
    }

    ctx->EVSE_STATUS.EVSE_PROCESSING_CPD = EVSE_PROC_ONGOING;
    ctx->EVSE_STATUS.EVSE_PROCESSING_AUTH_EIM = EVSE_PROC_ONGOING;
    ctx->EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = EVSE_PROC_ONGOING;
    ctx->EVSE_STATUS.EVSE_ISOLATION_STATUS = EVSE_ISOLATION_STAT_INVALID;
    ctx->EVSE_STATUS.TRIGGER_RE_NEGOTIATION = EVSE_TRIGGER_RENEGO_NONE;
    ctx->EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = 0;

    if (ctx->SECC_STATUS.SECC_STATUS_CODE <= SECC_STATUS_IDLE)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_INITIALIZED;
    }
    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateInitialized(ChargerContext *ctx)
{
    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_INITIALIZED;

        TRACE_TRACE("SECC_STATUS_INITIALIZED");
        TRACE_INFO("PLEASE PUSH THE 'S' KEY TO START CHARGING");
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_WAITING_PLUG_IN)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_WAITING_PLUG_IN;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateWaitPlugIn(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_WAITING_PLUG_IN;

        ctx->startTick = ctx->StartChargingTime = xTaskAlexGetTickCount();

        TRACE_TRACE("SECC_STATUS_WAITING_PLUG_IN");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;
        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING-READY: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_WAITING_SLAC)
    {
        ctx->NextState = ctx->CurrState;
        return ctx->NextState;
    }

    ctx->NextState = SECC_STATUS_PROCESSING_SLAC;
    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateWaitingSLAC(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_WAITING_SLAC;

        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_START_CHARGING;
        TRACE_TRACE("SECC_STATUS_WAITING_SLAC");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING LLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_PROCESSING_SLAC)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_PROCESSING_SLAC;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateProcessingSLAC(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_PROCESSING_SLAC;

        ctx->EndChargingTime = 0;
        TRACE_TRACE("SECC_STATUS_PROCESSING_SLAC");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING LLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_SDP)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_SDP;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateSDP(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_SDP;

        TRACE_TRACE("SECC_STATUS_SDP");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING LLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_ESTABLISHING_TCP_TLS)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_ESTABLISHING_TCP_TLS;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateEstablishingTCP(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_ESTABLISHING_TCP_TLS;

        TRACE_TRACE("SECC_STATUS_ESTABLISHING_TCP_TLS");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING LLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_SAP)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_SAP;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateSAP(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_SAP;

        ctx->startTick = xTaskAlexGetTickCount();

        TRACE_TRACE("SECC_STATUS_SAP");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_SESSION_SETUP)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_SESSION_SETUP;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateSessionSetup(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_SESSION_SETUP;

        TRACE_TRACE("SECC_STATUS_SESSION_SETUP");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_SERVICE_DISCOVERY)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_SERVICE_DISCOVERY;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateServiceDiscovery(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_SERVICE_DISCOVERY;

        TRACE_TRACE("SECC_STATUS_SERVICE_DISCOVERY");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_SERVICE_DETAILS)
    {
        ctx->NextState = ctx->CurrState;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_SERVICE_DETAILS)
    {
        ctx->NextState = SECC_STATUS_SERVICE_DETAILS;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_PAYMENT_SERVICE_SELECTION)
    {
        ctx->NextState = SECC_STATUS_PAYMENT_SERVICE_SELECTION;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateServiceDetails(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_SERVICE_DETAILS;

        TRACE_TRACE("SECC_STATUS_SERVICE_DETAILS");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_PAYMENT_SERVICE_SELECTION)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_PAYMENT_SERVICE_SELECTION;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePaymentServiceSelection(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_PAYMENT_SERVICE_SELECTION;

        TRACE_TRACE("SECC_STATUS_PAYMENT_SERVICE_SELECTION");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_CERTIFICATE_INSTALLATION)
    {
        ctx->NextState = ctx->CurrState;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_CERTIFICATE_INSTALLATION)
    {
        ctx->NextState = SECC_STATUS_CERTIFICATE_INSTALLATION;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_CERTIFICATE_UPDATE)
    {
        ctx->NextState = SECC_STATUS_CERTIFICATE_UPDATE;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_PAYMENT_DETAILS)
    {
        ctx->NextState = SECC_STATUS_PAYMENT_DETAILS;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_AUTHORIZATION_EIM)
    {
        ctx->NextState = SECC_STATUS_AUTHORIZATION_EIM;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateCertificateInstallation(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_CERTIFICATE_INSTALLATION;

        TRACE_TRACE("SECC_STATUS_CERTIFICATE_INSTALLATION");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_PAYMENT_DETAILS)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_PAYMENT_DETAILS;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateCertificateUpdate(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_CERTIFICATE_UPDATE;

        TRACE_TRACE("SECC_STATUS_CERTIFICATE_UPDATE");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_PAYMENT_DETAILS)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_PAYMENT_DETAILS;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePaymentDetails(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_PAYMENT_DETAILS;

        TRACE_TRACE("SECC_STATUS_PAYMENT_DETAILS");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_AUTHORIZATION_PnC)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_AUTHORIZATION_PnC;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateAuthorizationEIM(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_AUTHORIZATION_EIM;

        TRACE_INFO("PLEASE PUSH THE 'A' KEY for EIM PASS");
        TRACE_TRACE("SECC_STATUS_AUTHORIZATION_EIM");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_CHARGE_PARAMETER_DISCOVERY)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_CHARGE_PARAMETER_DISCOVERY;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateAuthorizationPnC(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_AUTHORIZATION_PnC;

        TRACE_TRACE("SECC_STATUS_AUTHORIZATION_PnC");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_CHARGE_PARAMETER_DISCOVERY)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_CHARGE_PARAMETER_DISCOVERY;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateChargeParameterDiscovery(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_CHARGE_PARAMETER_DISCOVERY;

        /* Clear ChargeState Param */
        ctx->EVSE_STATUS.EVSE_PROCESSING_CPD = EVSE_PROC_ONGOING;

        TRACE_TRACE("SECC_STATUS_CHARGE_PARAMETER_DISCOVERY");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    ctx->EVSE_STATUS.EVSE_PROCESSING_CPD = EVSE_PROC_FINISHED;

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_CABLE_CHECK)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_CABLE_CHECK;
        ChargerPrintChargeParamDiscoveryInfo();
        TRACE_TRACE("CHARGE PARAM DISCOVERY SEQUENCE FINISHED");
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateCableCheck(ChargerContext *ctx)
{
    static UBaseType_t complete; // CableCheck Pass Flag
    TickType_t timeout;
    unsigned IsolationStatusBuff = EVSE_ISOLATION_STAT_INVALID;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_CABLE_CHECK;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_CABLE_CHECK");

        /* Clear CableCheck Param */
        complete = pdFALSE;

        /* Set the CableCheck Volaget to MIN Value (EV_MAXIMUM_VOLTAGE_LIMIT and CHARGER MAXIMUM VOLTAGE) */
        int32_t minVoltage = MIN(ChargerGetMaximumVoltageLimit(), ChargerGetEvMaximumVoltageLimit());
        ChargerSetCableCheckVoltage(minVoltage ? minVoltage : EVSE_CABLE_CHECK_VOLTAGE);
        ChargerSetCableCheckCurrent(EVSE_CABLE_CHECK_CURRENT);

        ctx->EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = EVSE_PROC_ONGOING;
        ctx->EVSE_STATUS.EVSE_ISOLATION_STATUS = EVSE_ISOLATION_STAT_INVALID;
        ctx->EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = 1;

        TRACE_TRACE("CABLE CHECK SEQUENCE ONGOING: TIMEOUT[%d]", ChargerGetCableCheckTimeout());
    }

    /* Timeout Check: Emergency Stop */
    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->CableCheckTimeout)
    {
        /* Emergency Stop */
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        /* Set CableCheck Param: Terminction Reason */
        ctx->EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = EVSE_PROC_ONGOING;
        ctx->EVSE_STATUS.EVSE_ISOLATION_STATUS = EVSE_ISOLATION_STAT_FAULT;
        ctx->EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = 0;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING CABLE CHECK: TIMEOUT[%d]", timeout);
        return SECC_STATUS_TERMINATE;
    }

    /***************************** CABLE CHECK ***********************************
    + Relay Close
    + Power Module Turn On
    + Power Module Set Output (Voltage, Current)
    + Check (Cable Voltage >=
    Target Cable Check Voltage - Cable Check Voltage Tolerance) : Success
    + Success : Power Module Set Output (0,0) *optional
    + Power Module Turn Off
    ****************************** CABLE CHECK **********************************/

    /** Below is isolation check logic, so insert your code **/
    if (complete == pdFALSE)
    {
        /** PowerModule set output voltage/current and turn on */
        GW_RelaySet(RELAY_CLOSE);
        GW_PowerModuleAllOn();
        GW_PowerModuleSetTotalOutput(MIN(ChargerGetCableCheckVoltage(), ChargerGetEvMaximumVoltageLimit()),
                                     ChargerGetCableCheckCurrent());

        /* Console Message */
        ChargerPrintCableCheckInfo();

        /* CableCheck Logic */
        if (ChargerGetPresentVoltage() <=
            (ChargerGetCableCheckVoltage() - ChargerGetCableCheckVoltageTolerance()))
        {
            ctx->EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = EVSE_PROC_ONGOING;
            ctx->EVSE_STATUS.EVSE_ISOLATION_STATUS = EVSE_ISOLATION_STAT_INVALID;
            ctx->EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = 1;

            ctx->NextState = ctx->CurrState;
            return ctx->NextState;
        }

        /* Monitering Isolation Start */
        GW_IsolationStatusMoniteringStart();
    }

    complete = pdTRUE;

    /* Check current Isolation status */
    if (ChargerGetEvseIsolationStatus() == ISOLATION_INVALID)
    {
        ctx->NextState = ctx->CurrState;
        return ctx->NextState;
    }

    /** Power Module set output 0 and turn off, but Relay keep */
    GW_PowerModuleSetTotalOutput(0, 0);
    GW_PowerModuleAllOff();

    /** Check Power Pack Turn Off */
    if (ctx->PowerModuleOutputVoltage > 10.0 && ctx->PowerModuleOutputCurrent > 0.5)
    {
        ctx->NextState = ctx->CurrState;
        return ctx->NextState;
    }

    /* Pass CableCheck Process */
    ctx->EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = EVSE_PROC_FINISHED;
    ctx->EVSE_STATUS.EVSE_ISOLATION_STATUS = IsolationStatusBuff;
    ctx->EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = 0;

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_PRE_CHARGE)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_PRE_CHARGE;
        TRACE_TRACE("CABLE CHECK SEQUENCE FINISHED: SPEND-TIME[%d]", diffTick(ctx->startTick, xTaskAlexGetTickCount()));
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePreCharge(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_PRE_CHARGE;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_PRE_CHARGE");
        TRACE_TRACE("PRECHARGE SEQUENCE: TIMEOUT[%d]", ChargerGetPreChargeTimeout());
    }

    ctx->NextState = SECC_STATUS_PRE_CHARGE;

    /* Timeout Check: Emergency Stop */
    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->PreChargeTimeout)
    {
        /* Emergency Stop */
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING PRE CHAGRE: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    /* Non-Blocking Waiting until pass the SECC_STATUS_PRE_CHARGE */
    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_PRE_CHARGE)
    {
        return ctx->NextState;
    }

    /** Power Pack set output voltage/current and turn on */
    GW_PowerModuleAllOn();
    GW_PowerModuleSetTotalOutput(ctx->SECC_TARGET_VOLTATE_CURRENT.TARGET_VOLTAGE * 100,
                                 ChargerGetCableCheckCurrent());

    /* Console Message */
    ChargerPrintPreChargeInfo();

    /* Pass PreCharge Process */
    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_POWER_DELIVERY_START)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_POWER_DELIVERY_START;
        TRACE_TRACE("PRECHARGE SEQUENCE SPEND-TIME[%d]", diffTick(ctx->startTick, xTaskAlexGetTickCount()));
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePowerDeliveryStart(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_POWER_DELIVERY_START;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_POWER_DELIVERY_START");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("CHARGING HLC: TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_CURRENT_DEMAND)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_CURRENT_DEMAND;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateCurrentDemand(ChargerContext *ctx)
{
    uint32_t outputVoltage = 0;
    uint32_t outputCurrent = 0;
    /* Re-entry Check */
    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_CURRENT_DEMAND;

        TRACE_TRACE("SECC_STATUS_CURRENT_DEMAND");

        ctx->EVSE_STATUS.EVSE_PROCESSING_CPD = EVSE_PROC_ONGOING;
        ctx->EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = EVSE_PROC_ONGOING;
        ctx->EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = 0;
    }
    ctx->NextState = SECC_STATUS_CURRENT_DEMAND;

    /** Power Pack set output voltage/current and turn on */
    outputVoltage =
        ChargerGetEvTargetVoltage() > ChargerGetMaximumVoltageLimit() ? ChargerGetMaximumVoltageLimit() : ChargerGetEvTargetVoltage();
    outputCurrent =
        ChargerGetEvTargetCurrent() > ChargerGetMaximumCurrentLimit() ? ChargerGetMaximumCurrentLimit() : ChargerGetEvTargetCurrent();

    GW_PowerModuleSetTotalOutput(outputVoltage, outputCurrent);
    GW_PowerModuleAllOn();

    /* Console Message */
    ChargerPrintChargingInfo();

    /* Stop Charging from EV Side */
    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP)
    {
        ctx->NextState = SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP;
    }
    /* Stop Charging from EVSE Side */
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP)
    {
        ctx->NextState = SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP;
    }
    /* ReNegotiation */
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_POWER_DELIVERY_RENEGOTIATE)
    {
        ctx->NextState = SECC_STATUS_POWER_DELIVERY_RENEGOTIATE;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePowerDeliveryRenego(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_POWER_DELIVERY_RENEGOTIATE;

        ctx->startTick = xTaskAlexGetTickCount();

        /** Power Pack set output 0 and turn off */
        GW_PowerModuleSetTotalOutput(0, 0);
        GW_PowerModuleAllOff();

        GW_RelaySet(RELAY_OPEN);

        TRACE_TRACE("SECC_STATUS_POWER_DELIVERY_RENEGOTIATE");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("POWER DELIVERY RENEGO : TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    /* Console Message */
    ChargerPrintRenegoInfo();

    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_CHARGE_PARAMETER_DISCOVERY)
    {
        ctx->NextState = SECC_STATUS_CHARGE_PARAMETER_DISCOVERY;
        ctx->EVSE_STATUS.TRIGGER_RE_NEGOTIATION = EVSE_TRIGGER_RENEGO_NONE;
    }
    else
    {
        ctx->NextState = ctx->CurrState;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePowerDeliveryEvInitStop(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_POWER_DELIVERY_EV_INIT_STOP");
    }

    GW_PowerModuleSetTotalOutput(0, 0);
    GW_PowerModuleAllOff();

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("POWER DELIVERY EV INIT STOP : TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_WELDING_DETECTION)
    {
        ctx->NextState = SECC_STATUS_WELDING_DETECTION;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_SESSION_STOP_TERMINATE)
    {
        ctx->NextState = SECC_STATUS_SESSION_STOP_TERMINATE;
    }
    else
    {
        ctx->NextState = ctx->CurrState;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStatePowerDeliveryEvseInitStop(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_POWER_DELIVERY_EVSE_INIT_STOP");
    }

    GW_PowerModuleSetTotalOutput(0, 0);
    GW_PowerModuleAllOff();

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("POWER DELIVERY EVSE INIT STOP : TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_WELDING_DETECTION)
    {
        ctx->NextState = SECC_STATUS_WELDING_DETECTION;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_SESSION_STOP_TERMINATE)
    {
        ctx->NextState = SECC_STATUS_SESSION_STOP_TERMINATE;
    }
    else
    {
        ctx->NextState = ctx->CurrState;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateWeldingDetection(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_WELDING_DETECTION;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_WELDING_DETECTION");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("WELDING DETECTION : TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_SESSION_STOP_TERMINATE)
    {
        ctx->NextState = SECC_STATUS_SESSION_STOP_TERMINATE;
    }
    else
    {
        ctx->NextState = ctx->CurrState;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateSessionStop(ChargerContext *ctx)
{
    TickType_t timeout;

    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_SESSION_STOP_TERMINATE;

        ctx->startTick = xTaskAlexGetTickCount();
        TRACE_TRACE("SECC_STATUS_SESSION_STOP_TERMINATE");
    }

    timeout = diffTick(ctx->startTick, xTaskAlexGetTickCount());
    if (timeout > ctx->ChargingStartTimeout)
    {
        ctx->EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_EVSE_INITIATED_EMERGENCY_STOP;

        ctx->NextState = SECC_STATUS_TERMINATE;
        TRACE_ERROR("SESSION STOP, TERMINATE : TIMEOUT[%d]", timeout);
        return ctx->NextState;
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE < SECC_STATUS_TERMINATE)
    {
        ctx->NextState = ctx->CurrState;
    }
    else
    {
        ctx->NextState = SECC_STATUS_TERMINATE;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateTerminate(ChargerContext *ctx)
{
    /* Re-entry Check */
    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_TERMINATE;

        TRACE_TRACE("SECC_STATUS_TERMINATE");

        ctx->BeforeTerminationState = ctx->PrevState;

        GW_IsolationStatusMoniteringEnd();
    }
    ctx->NextState = SECC_STATUS_TERMINATE;

    /** Power Pack set output 0 and turn off */

    GW_PowerModuleSetTotalOutput(0, 0);
    GW_PowerModuleAllOff();

    /* Console Message */
    ChargerPrintTerminationInfo();

    /** Relay OPEN after Power Pack output is 0 */

    // GW_RelaySet(RELAY_OPEN);

    /* Pass Termination Process */
    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_IDLE)
    {
        ctx->EndChargingTime = xTaskAlexGetTickCount();
        ctx->NextState = SECC_STATUS_IDLE;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateError(ChargerContext *ctx)
{
    /* Re-entry Check */
    if (IsChargeStateTrasition(ctx))
    {
        ctx->PrevState = ctx->CurrState;
        ctx->CurrState = SECC_STATUS_ERROR;

        TRACE_TRACE("SECC_STATUS_ERROR");
    }

    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_IDLE)
    {
        ctx->NextState = SECC_STATUS_IDLE;
    }
    else if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_TERMINATE)
    {
        ctx->NextState = SECC_STATUS_TERMINATE;
    }
    else
    {
        ctx->NextState = ctx->CurrState;
    }

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateSet(ChargerContext *ctx, SECC_STATUS_CODE state)
{
    ctx->NextState = state;

    return ctx->NextState;
}

SECC_STATUS_CODE ChargeStateGet(ChargerContext *ctx)
{
    return ctx->NextState;
}

uint32_t IsChargeStateTrasition(ChargerContext *ctx)
{
    if (ctx->CurrState != ctx->NextState)
    {
        return 1;
    }
    return 0;
}

uint32_t IsChargeErrorOrTeminate(ChargerContext *ctx)
{
    if ((ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_ERROR) ||
        (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_TERMINATE))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

uint32_t IsChargeStateRenogo(ChargerContext *ctx)
{
    if (ctx->SECC_STATUS.SECC_STATUS_CODE == SECC_STATUS_POWER_DELIVERY_RENEGOTIATE)
        return 1;
    else
        return 0;
}

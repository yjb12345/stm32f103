/*
 * EventControl.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EVENTCONTROL_H_
#define AP_EVENTCONTROL_H_

#include "EvseConfig.h"
#include "Console.h"
#include "IsolationMonitor.h"

typedef enum
{
    GW_EVENT_BTN_1_PRESSED,
    GW_EVENT_BTN_2_PRESSED,
    GW_EVENT_KEY_PRESSED,

    GW_EVENT_CABLE_MONITOR_CPLT,
    GW_EVENT_POWER_MODULE_CAN_RX_CPLT,
    GW_EVENT_SECC_CAN_RX_CPLT,
    GW_EVENT_ISOLATION_CPLT,

    /* Testing */
    GW_EVENT_USER1,
    GW_EVENT_USER2,
} GW_CONTROLEventType;

//-- fixMe: alex copied  from GridWiz
#define LED1_Pin GPIO_PIN_6
#define LED1_GPIO_Port GPIOF
#define LED2_Pin GPIO_PIN_7
#define LED2_GPIO_Port GPIOF
#define LED3_Pin GPIO_PIN_8
#define LED3_GPIO_Port GPIOF
#define LED4_Pin GPIO_PIN_9
#define LED4_GPIO_Port GPIOF

//--

void GW_LoopInit();
void GW_LoopDeInit();
#ifdef _ALEX_CMSIS_V2_
osStatus_t GW_EventNotifySendWait(GW_CONTROLEventType type, osPoolId mpId, void *data, uint32_t ms);
#else
osStatus GW_EventNotifySendWait(GW_CONTROLEventType type, osPoolId mpId, void *data, uint32_t ms);
#endif
osStatus GW_EventNotify(GW_CONTROLEventType event);
osStatus GW_EventNotifySend(GW_CONTROLEventType event, osPoolId mpId, void *data);

/* (__weak) Callback functions ************************************************/
void GW_KeyPressedCallback(uint8_t keyCode);
void GW_CableMonitorCpltCallback(uint32_t id, int32_t value, uint32_t scale);
void GW_CheckIsolationCpltCallback(uint16_t IsolationStatus);
void GW_SeccRxCpltCallback(uint32_t id, uint8_t *data, uint32_t size);
void GW_PowerModuleRxCpltCallback(uint32_t id, uint8_t *data, uint32_t size);

#ifdef _ALEX_CMSIS_V2_
/* Task */
void EventLoopTask(void *arguments);
#else

void EventLoopTask(void const *arguments);
#endif

#endif /* AP_EVENTCONTROL_H_ */

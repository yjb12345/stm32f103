/*
 * EvseContext.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EVSECONTEXT_H_
#define AP_EVSECONTEXT_H_
#include "EventControl.h"
#include "EvseMain.h"
#include "Peppermint4xCan.h"
#include "GW_Message.h"

typedef struct ChargerContext {
    /* Charger State */
    SECC_STATUS_CODE      PrevState;
    SECC_STATUS_CODE      CurrState;
    SECC_STATUS_CODE      NextState;

    SECC_STATUS_CODE      BeforeTerminationState;

    /* Charger Status */
    TickType_t            StartChargingTime;
    TickType_t            EndChargingTime;

    /* PowerModule Infomation */
    uint32_t              PowerModuleOutput;        // 0: On 1: Off
    int32_t               PowerModuleOutputVoltage;
    int32_t               PowerModuleOutputCurrent;
    int8_t                PowerModuleModuleTemprature;

    /* ChartStart Param */
    TickType_t            ChargingStartTimeout;

    /* CableCheck Param */
    TickType_t            CableCheckTimeout;
    int32_t              CableCheckVoltage;              // mV Unit
    int32_t              CableCheckVoltageTolerance;     // mV unit
    int32_t              CableCheckCurrent;              // mA Unit

    /* PreCharge Param */
    TickType_t            PreChargeTimeout;

    /* Timeout Param */
    TickType_t            startTick;

    /* EVSE Infomation */
    CANID_H15ECC001 EVSE_CONFIGURATION;
    CANID_H15ECC002 EVSE_STATUS;
    CANID_H15ECC003 EVSE_CHARGE_PARAMETERS1;
    CANID_H15ECC004 EVSE_CHARGE_PARAMETERS2;
    CANID_H15ECC005 EVSE_PRESENT_VOLTAGE_CURRENT;
    CANID_H15ECC006 EVSE_DIN_ID1;
    CANID_H15ECC007 EVSE_DIN_ID2;
    CANID_H15ECC008 EVSE_DIN_ID3;
    CANID_H15ECC009 EVSE_DIN_ID4;

    CANID_H15ECC00A EVSE_ISO_ID1;
    CANID_H15ECC00B EVSE_ISO_ID2;
    CANID_H15ECC00C EVSE_ISO_ID3;
    CANID_H15ECC00D EVSE_ISO_ID4;
    CANID_H15ECC00E EVSE_ISO_ID5;

    CANID_H15ECC00F EVSE_TIMESTAMP;     //Event, set timestamp
    CANID_H15ECC0FF EVSE_SECC_REBOOT;   //Event

    /* EVSE SA AGENT */
    CANID_H15ECD001 EVSE_SA_AGENT_CONNECTION_CONFIG;
    CANID_H15ECD002 EVSE_SECC_PNC_CONFIG;
    CANID_H15ECD003 EVSE_SA_AGENT_COMM_TIMEOUT;

    /* SECC Infomation */
    CANID_H15ECC101 SECC_STATUS_LEGACY;
    CANID_H15ECC102 SECC_CP_PP_STATUS;
    CANID_H15ECC103 SECC_EV_SERVICE_SELECTION;
    CANID_H15ECC104 SECC_SESSION_ID;
    CANID_H15ECC105 SECC_EVCC_ID;
    CANID_H15ECC106 SECC_EV_CHARGE_PARAMETERS1;
    CANID_H15ECC107 SECC_EV_CHARGE_PARAMETERS2;
    CANID_H15ECC108 SECC_EV_SOC_RELATED;
    CANID_H15ECC109 SECC_TARGET_VOLTATE_CURRENT;
    CANID_H15ECC10A SECC_TIMESTAMP;
    CANID_H15ECC10B SECC_STATUS;
    CANID_H15ECC1FF SECC_EMERGENCY_NOTIFICATION;        //Event

    /* SECC SA AGENT */
    CANID_H15ECD101 SECC_SA_COMM_STATUS;
    CANID_H15ECD102 SECC_IP_STATUS;

} ChargerContext;

GW_Message* _50ms_MessageGet(void);
GW_Message* _200ms_MessageGet(void);
GW_Message* _500ms_MessageGet(void);
GW_Message* _1000ms_MessageGet(void);
GW_Message* _Rx_MessageGet(void);

ChargerContext* ChargerContextGet(void);

void ChargerContextInit();

/* EVSE Parameters */
// Unit is mills
void ChargerSetMaximumVoltageLimit(int32_t mV);
void ChargerSetMaximumCurrentLimit(int32_t mA);
int32_t ChargerGetMaximumVoltageLimit();
int32_t ChargerGetMaximumCurrentLimit();
int32_t ChargerGetMaximumPowerLimit(); // Unit ( W )

void ChargerSetMinimumVoltageLimit(int32_t mV);
void ChargerSetMinimumCurrentLimit(int32_t mA);

void ChargerSetCableCheckVoltage(int32_t mv);
void ChargerSetCableCheckVoltageTolerance(int32_t mv);
void ChargerSetCableCheckCurrent(int32_t mv);
int32_t ChargerGetCableCheckVoltage();
int32_t ChargerGetCableCheckVoltageTolerance();
int32_t ChargerGetCableCheckCurrent();

void ChargerSetPresentVoltage(int32_t mV);
void ChargerSetPresentCurrent(int32_t mA);
int32_t ChargerGetPresentVoltage();
int32_t ChargerGetPresentCurrent();

/* EV Parameters */
int32_t ChargerGetEvMaximumVoltageLimit();
int32_t ChargerGetEvMaximumCurrentLimit();

int32_t ChargerGetEvTargetVoltage();
int32_t ChargerGetEvTargetCurrent();

/* Control Pilot */
int32_t ChargerGetCpVoltage();

/* Timeout */
void ChargerSetChargingStartTimeout(TickType_t ms);
void ChargerSetCableCheckTimeout(TickType_t ms);
void ChargerSetPreChargeTimeout(TickType_t ms);
TickType_t ChargerGetChargingStartTimeout();
TickType_t ChargerGetCableCheckTimeout();
TickType_t ChargerGetPreChargeTimeout();
void ChargerSetTriggerStateF(EVSE_TRIGGER_F_TYPE Type);
SECC_CP_STATE_TYPE ChargerGetSeccStatus();

unsigned ChargerGetEvseIsolationStatus(void);




#endif /* AP_EVSECONTEXT_H_ */

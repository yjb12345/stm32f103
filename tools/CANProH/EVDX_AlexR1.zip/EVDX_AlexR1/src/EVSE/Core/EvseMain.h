#ifndef __EVSE_CHARGE_H__
#define __EVSE_CHARGE_H__

#include "EventControl.h"
#include "Secc.h"
#define EVSE_SUPPORTED_PAYMENT_OPTION_EIM       (1)
#define EVSE_SUPPORTED_PLUGIN_CHARGE            (0)

/* EVSE PROTOCOL BASE SCALE IS 10 ex) 10V=>100 2.3A=>23
* APPLICATION BASE SCALE IS mills (mV, mA, msec..)
*/

#define EVSE_MAX_CURRENT_LIMIT                  (120 * 1000)    // 120A

#define EVSE_MAX_VOLTAGE_LIMIT	                (500 * 1000)	// 500V
#define EVSE_MIN_CURRENT_LIMIT	                (1 * 1000)      // 1A
#define EVSE_MIN_VOLTAGE_LIMIT	                (10 * 1000)     // 10V
#define EVSE_CURRENT_TOLERANCE	                (20 * 1000)     // 2A
#define EVSE_CURRENT_RIPPLE	                    (20 * 1000)     // 2A

#define EVSE_CABLE_CHECK_VOLTAGE                EVSE_MAX_VOLTAGE_LIMIT
#define EVSE_CABLE_CHECK_VOLTAGE_TOLERANCE      (5 * 1000)      // 5V
#define EVSE_CABLE_CHECK_CURRENT 	        EVSE_MIN_CURRENT_LIMIT

/* Response Time is response timeout for device */
#define CABLE_MONITOR_RESPONSE_TIME             (80)            // ms
#define POWER_MODULE_RESPONSE_TIME              (50)            // ms

/** TIMEOUT */
/* Charge Start timeout is from READY to CPD */
#define EVSE_CHARGE_START_TIMEOUT               (60 * 1000)     // 60s
#define EVSE_CHARGE_CABLE_CHECK_TIMEOUT         (40 * 1000)     // 40s
#define EVSE_CHARGE_PRECHARGE_TIMEOUT           (30 * 1000)     // 30s

/** Below is only Testing */
#define EVSE_AUTHUNTICATION_EXTENDED_TIME        (5 * 1000)    // 10s
#define EVSE_CABLECEHCK_PRE_HOLDING_TIME         (0)
#define EVSE_PRECHARGE_PRE_HOLDING_TIME          (0)

void EVSE_ProgramInfo();
void EVSE_PrintStatus();
void EVSE_Init();
void EVSE_CheckModule();
void EVSE_Start();
void EVSE_Stop();

#endif /* EVSE_CHARGE_H__ */

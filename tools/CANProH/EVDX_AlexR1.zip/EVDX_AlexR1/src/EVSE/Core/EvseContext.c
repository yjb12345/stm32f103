/*
 * EvseContext.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */


/**
******************************************************************************
* @file           : EvseContext.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Charger Context Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

EvseContext.c is a collection of data variables for the charger.
All data related to charger control are managed in a GET / SET structure.

******************************************************************************
*/

#include "EvseContext.h"
#include <string.h>

ChargerContext ChargerCtx;

static void ChargerContextMappingInit();

GW_Message EvseTxSeccMessage50ms[] = {
    { .Id = CAN_ID_H15ECC002, .Data = NULL, .Nick = "EVSE Status" },
    { .Id = CAN_ID_H15ECC005, .Data = NULL, .Nick = "Present VI" },
    { .Id = 0x0,              .Data = NULL, .Nick = NULL }
};

GW_Message EvseTxSeccMessage200ms[] = {
    { .Id = CAN_ID_H15ECC001, .Data = NULL, .Nick = "EVSE Configurations" },
    { .Id = CAN_ID_H15ECC003, .Data = NULL, .Nick = NULL },
    { .Id = CAN_ID_H15ECC004, .Data = NULL },
    { .Id = 0x0,              .Data = NULL }
};

GW_Message EvseTxSeccMessage500ms[] = {
    { .Id = CAN_ID_H15ECC006, .Data = NULL, .Nick = "DIN EVSE ID 1" },
    { .Id = CAN_ID_H15ECC007, .Data = NULL },
    { .Id = CAN_ID_H15ECC008, .Data = NULL },
    { .Id = CAN_ID_H15ECC009, .Data = NULL },
    { .Id = CAN_ID_H15ECC00A, .Data = NULL },
    { .Id = CAN_ID_H15ECC00B, .Data = NULL },
    { .Id = CAN_ID_H15ECC00C, .Data = NULL },
    { .Id = CAN_ID_H15ECC00D, .Data = NULL },
    { .Id = CAN_ID_H15ECC00E, .Data = NULL },
    { .Id = 0x0,              .Data = NULL }      //END
};

GW_Message EvseTxSeccMessage1000ms[] = {
    { .Id = CAN_ID_H15ECD001, .Data = NULL, .Nick = "EVSE SA Agent Connection Configuration" },
    { .Id = CAN_ID_H15ECD002, .Data = NULL, .Nick = "EVSE SECC PnC Configuration" },
    { .Id = CAN_ID_H15ECD003, .Data = NULL, .Nick = "EVSE SA Agent Communication timeout" },
    { .Id = 0x0,              .Data = NULL }      //END
};

GW_Message EvseRxSeccMessage[] = {
    /* from secc */
    { .Id = CAN_ID_H15ECC101, .Data = NULL },
    { .Id = CAN_ID_H15ECC102, .Data = NULL },
    { .Id = CAN_ID_H15ECC103, .Data = NULL },
    { .Id = CAN_ID_H15ECC104, .Data = NULL },
    { .Id = CAN_ID_H15ECC105, .Data = NULL },
    { .Id = CAN_ID_H15ECC106, .Data = NULL },
    { .Id = CAN_ID_H15ECC107, .Data = NULL },
    { .Id = CAN_ID_H15ECC108, .Data = NULL },
    { .Id = CAN_ID_H15ECC109, .Data = NULL },
    { .Id = CAN_ID_H15ECC10A, .Data = NULL },
    { .Id = CAN_ID_H15ECC10B, .Data = NULL }, //Nick = "SECC Status"
    { .Id = CAN_ID_H15ECC1FF, .Data = NULL }, //Nick = "SECC Emergency Notification"    //event msg
    { .Id = CAN_ID_H15ECD101, .Data = NULL }, //Nick = "SECC SA COMM Status"
    { .Id = CAN_ID_H15ECD102, .Data = NULL }, //Nick = "SECC IP Status"
    { .Id = 0x0,              .Data = NULL }    // END
};

GW_Message* _50ms_MessageGet(void)
{
    return EvseTxSeccMessage50ms;
}

GW_Message* _200ms_MessageGet(void)
{
    return EvseTxSeccMessage200ms;
}

GW_Message* _500ms_MessageGet(void)
{
    return EvseTxSeccMessage500ms;
}

GW_Message* _1000ms_MessageGet(void)
{
    return EvseTxSeccMessage1000ms;
}

GW_Message* _Rx_MessageGet(void)
{
    return EvseRxSeccMessage;
}

ChargerContext* ChargerContextGet(void)
{
    return &ChargerCtx;
}
#ifdef ALEX_ADD_NEW
uint8_t ChargerContextGetMemroyMap(uint8_t *ptr, uint16_t *len)
{
    //ptr= (uint8_t *) (void *) &ChargerCtx;
     memcpy(ptr,(uint8_t *) &ChargerCtx, sizeof(ChargerCtx));
    *len=sizeof(ChargerCtx);
    return 1;
}
#endif

void ChargerContextInit()
{
    memset(&ChargerCtx, 0x0, sizeof(struct ChargerContext));

    /** EVSE STATUS INIT (CANID_H15ECC002) **/
    ChargerCtx.EVSE_STATUS.CHARGING_CONTROL = CHARGING_CTRL_INITIALIZE_PPMT;

    /** EVSE CONFIGURATION (CANID_H15ECC001) **/
    ChargerCtx.EVSE_CONFIGURATION.EVSE_ID_CONFIG_DIN = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.EVSE_ID_CONFIG_ISO = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.ENVIRONMENT_CONFIGURATION = BIT_RESET; // Default, ISO/DIN selection based on EVCC's priority
    ChargerCtx.EVSE_CONFIGURATION.EVSE_ID_LENGTH_DIN = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.EVSE_ID_LENGTH_ISO = BIT_RESET;

    ChargerCtx.EVSE_CONFIGURATION.SUPPORTED_ENERGY_TRANSFER_DC_CORE = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.SUPPORTED_ENERGY_TRANSFER_DC_EXTD = BIT_SET;
    ChargerCtx.EVSE_CONFIGURATION.SUPPORTED_ENERGY_TRANSFER_DC_CC = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.SUPPORTED_ENERGY_TRANSFER_DC_UNIQUE = BIT_RESET;

    ChargerCtx.EVSE_CONFIGURATION.SERVICE_LIST_INTERNET = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.SERVICE_LIST_HPC1 = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.FREE_SERVICE_EV_CHARGING = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.FREE_SERVICE_INTERNET = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.FREE_SERVICE_CONTRACT_CERT = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.FREE_SERVICE_OTHER_CUSTOM = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.SA_SCHEDULE_MANAGEMENT = BIT_RESET;
    ChargerCtx.EVSE_CONFIGURATION.CP_MONITORING_MODE = BIT_RESET;

    /** EVSE STATUS INIT (CANID_H15ECC002) **/
    ChargerCtx.EVSE_STATUS.NOTIFICATION_MAX_DELAY = BIT_RESET;  // Default 0 is 60s.
    ChargerCtx.EVSE_STATUS.EVSE_ISOLATION_STATUS = BIT_RESET;
    ChargerCtx.EVSE_STATUS.EVSE_PROCESSING_AUTH_EIM = BIT_RESET;
    ChargerCtx.EVSE_STATUS.EVSE_PROCESSING_CPD = BIT_RESET;
    ChargerCtx.EVSE_STATUS.EVSE_PROCESSING_CABLE_CHECK = BIT_RESET;
    ChargerCtx.EVSE_STATUS.ISOLATION_MONITORING_ACTIVE = BIT_RESET;
    ChargerCtx.EVSE_STATUS.TRIGGER_RE_NEGOTIATION = BIT_RESET;
    ChargerCtx.EVSE_STATUS.TRIGGER_STATE_E = BIT_RESET;
    ChargerCtx.EVSE_STATUS.EVSE_CURRENT_LIMIT_ACHIEVED = BIT_RESET;
    ChargerCtx.EVSE_STATUS.EVSE_VOLTAGE_LIMIT_ACHIEVED = BIT_RESET;
    ChargerCtx.EVSE_STATUS.EVSE_POWER_LIMIT_ACHIEVED = BIT_RESET;

    /** EVSE SPEC PARAMETER (CANID_H15ECC003, CANID_H15ECC004)  **/
    ChargerSetMaximumVoltageLimit(EVSE_MAX_VOLTAGE_LIMIT);
    ChargerSetMaximumCurrentLimit(EVSE_MAX_CURRENT_LIMIT);
    ChargerSetMinimumVoltageLimit(EVSE_MIN_VOLTAGE_LIMIT);
    ChargerSetMinimumCurrentLimit(EVSE_MIN_CURRENT_LIMIT);

    ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_PEAK_CURRENT_RIPPLE          = EVSE_CURRENT_RIPPLE / 100;
    ChargerCtx.EVSE_CHARGE_PARAMETERS2.EVSE_CURRENT_REGULATION_TOLERANCE = EVSE_CURRENT_TOLERANCE / 100;
    ChargerCtx.EVSE_CHARGE_PARAMETERS2.EVSE_ENERGY_TO_BE_DELIVERED = BIT_RESET;

    /** EVSE SA AGENT CONNECTION CONFIGURATION (CANID_H15ECD001)**/
    ChargerCtx.EVSE_SA_AGENT_CONNECTION_CONFIG.SA_AGENT_IP_ADDR_1 = 127;
    ChargerCtx.EVSE_SA_AGENT_CONNECTION_CONFIG.SA_AGENT_IP_ADDR_2 = 0;
    ChargerCtx.EVSE_SA_AGENT_CONNECTION_CONFIG.SA_AGENT_IP_ADDR_3 = 0;
    ChargerCtx.EVSE_SA_AGENT_CONNECTION_CONFIG.SA_AGENT_IP_ADDR_4 = 1;
    ChargerCtx.EVSE_SA_AGENT_CONNECTION_CONFIG.SA_AGENT_PORT = 19119;

    /** PnC CONFIGURATION (CANID_H15ECD002)**/
    ChargerCtx.EVSE_SECC_PNC_CONFIG.CERT_CHAIN_VALIDATION_OPTION = 0;
    ChargerCtx.EVSE_SECC_PNC_CONFIG.PKI_ENVIRONMENT_SELECTION = BIT_SET;        // public
    ChargerCtx.EVSE_SECC_PNC_CONFIG.RE_KEY_OPTION = 0;

    /** SA AGENT TIMEOUT (CANID_H15ECD003)**/
    ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT.SA_AGENT_AUTHORIZE_RESP_TIMEOUT = 0;  // 0 is default
    ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT.SA_AGENT_CERT_INSTALLATION_PERFORMANCE_TIMEOUT = 0;
    ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT.SA_AGENT_CERT_UPDATE_PERFORMANCE_TIMEOUT = 0;
    ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT.SA_AGENT_GET_CERTIFICATE_STATUS_RESP_TIMEOUT = 0;
    ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT.SA_AGENT_HELLO_RESP_TIMEOUT = 0;
    ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT.SA_AGENT_SIGN_SECC_CERTIFICATE_RESP_TIMEOUT = 0;

    /* CableCheck Parameter */
    ChargerSetCableCheckVoltage(EVSE_CABLE_CHECK_VOLTAGE);
    ChargerSetCableCheckVoltageTolerance(EVSE_CABLE_CHECK_VOLTAGE_TOLERANCE);
    ChargerSetCableCheckCurrent(EVSE_CABLE_CHECK_CURRENT);

    /* Timeout Set */
    ChargerSetChargingStartTimeout(EVSE_CHARGE_START_TIMEOUT);
    ChargerSetCableCheckTimeout(EVSE_CHARGE_START_TIMEOUT);
    ChargerSetPreChargeTimeout(EVSE_CHARGE_START_TIMEOUT);

    /* Can Message Mapping */
    ChargerContextMappingInit();

    ChargerCtx.PrevState = ChargerCtx.CurrState = ChargerCtx.NextState = SECC_STATUS_PAUSE;

}

void ChargerSetMaximumVoltageLimit(int32_t mV)
{
    // Unit 0.1V
    ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_VOLTAGE_LIMIT = (int16_t) (mV / 100);
    // Unit 10W
    ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_POWER_LIMIT =
        (int16_t)((ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_VOLTAGE_LIMIT * ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_CURRENT_LIMIT) / 1000);
}

void ChargerSetMaximumCurrentLimit(int32_t mA)
{
    // Unit 0.1A
    ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_CURRENT_LIMIT = (int16_t) (mA / 100);
    // Unit 10W
    ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_POWER_LIMIT =
        (int16_t)((ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_VOLTAGE_LIMIT * ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_CURRENT_LIMIT) / 1000);
}

int32_t ChargerGetMaximumVoltageLimit()
{
    return (int32_t) ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_VOLTAGE_LIMIT * 100;
}

int32_t ChargerGetMaximumCurrentLimit()
{
    return (int32_t) ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_CURRENT_LIMIT * 100;
}

int32_t ChargerGetMaximumPowerLimit()
{
    // EVSE_MAXIMUM_POER_LIMIT base unit is 10W, so scale down. 10W -> W
    return (int32_t) ChargerCtx.EVSE_CHARGE_PARAMETERS1.EVSE_MAXIMUM_POWER_LIMIT * 10;
}

void ChargerSetMinimumVoltageLimit(int32_t mV)
{
    // Unit 0.1V
    ChargerCtx.EVSE_CHARGE_PARAMETERS2.EVSE_MINIMUM_VOLTAGE_LIMIT = (int16_t) (mV / 100);
}

void ChargerSetMinimumCurrentLimit(int32_t mA)
{
    // Unit 0.1A
    ChargerCtx.EVSE_CHARGE_PARAMETERS2.EVSE_MINIMUM_CURRENT_LIMIT = (int16_t) (mA / 100);
}

/* CableCheck Parameter */
void ChargerSetCableCheckVoltage(int32_t mV)
{
    ChargerCtx.CableCheckVoltage = mV;
}

void ChargerSetCableCheckCurrent(int32_t mA)
{
    ChargerCtx.CableCheckCurrent = mA;
}

void ChargerSetCableCheckVoltageTolerance(int32_t mV)
{
    ChargerCtx.CableCheckVoltageTolerance = mV;
}

int32_t ChargerGetCableCheckVoltage()
{
    return (int32_t) ChargerCtx.CableCheckVoltage;
}

int32_t ChargerGetCableCheckCurrent()
{
    return (int32_t) ChargerCtx.CableCheckCurrent;
}

int32_t ChargerGetCableCheckVoltageTolerance()
{
    return (int32_t) ChargerCtx.CableCheckVoltageTolerance;
}

/* Present Voltage/Current Value */
void ChargerSetPresentVoltage(int32_t mV)
{
    ChargerCtx.EVSE_PRESENT_VOLTAGE_CURRENT.EVSE_PRESENT_VOLTAGE = (int16_t) (mV / 100);
}

void ChargerSetPresentCurrent(int32_t mA)
{
    ChargerCtx.EVSE_PRESENT_VOLTAGE_CURRENT.EVSE_PRESENT_CURRENT = (int16_t) (mA / 100);
}

int32_t ChargerGetPresentVoltage()
{
    return (int32_t) ((int16_t)ChargerCtx.EVSE_PRESENT_VOLTAGE_CURRENT.EVSE_PRESENT_VOLTAGE * 100);
}

int32_t ChargerGetPresentCurrent()
{
    return (int32_t) ((int16_t)ChargerCtx.EVSE_PRESENT_VOLTAGE_CURRENT.EVSE_PRESENT_CURRENT * 100);
}


/* EV PARAMETERS */
int32_t ChargerGetEvMaximumVoltageLimit()
{
    return (int32_t) ChargerCtx.SECC_EV_CHARGE_PARAMETERS2.EV_MAXIMUM_VOLTAGE_LIMIT * 100;
}

int32_t ChargerGetEvMaximumCurrentLimit()
{
    return (int32_t) ChargerCtx.SECC_EV_CHARGE_PARAMETERS2.EV_MAXIMUM_CURRENT_LIMIT * 100;
}

/* Control Pilot */
int32_t ChargerGetCpVoltage()
{
    return (int32_t) ((int16_t)ChargerCtx.SECC_CP_PP_STATUS.CP_VOLTAGE * 100);
}

int32_t ChargerGetEvTargetVoltage()
{
    return (int32_t) (ChargerCtx.SECC_TARGET_VOLTATE_CURRENT.TARGET_VOLTAGE * 100);
}

int32_t ChargerGetEvTargetCurrent()
{
    return (int32_t) (ChargerCtx.SECC_TARGET_VOLTATE_CURRENT.TARGET_CURRENT * 100);
}

/* Timeout */
void ChargerSetChargingStartTimeout(TickType_t ms)
{
    ChargerCtx.ChargingStartTimeout = ms;
}

void ChargerSetCableCheckTimeout(TickType_t ms)
{
    ChargerCtx.CableCheckTimeout = ms;
}

void ChargerSetPreChargeTimeout(TickType_t ms)
{
    ChargerCtx.PreChargeTimeout = ms;
}

TickType_t ChargerGetChargingStartTimeout()
{
    return ChargerCtx.ChargingStartTimeout;
}

TickType_t ChargerGetCableCheckTimeout()
{
    return ChargerCtx.CableCheckTimeout;
}

TickType_t ChargerGetPreChargeTimeout()
{
    return ChargerCtx.PreChargeTimeout;
}
void ChargerSetTriggerStateF(EVSE_TRIGGER_F_TYPE Type)
{
    ChargerCtx.EVSE_STATUS.TRIGGER_STATE_E = Type;
}

SECC_CP_STATE_TYPE ChargerGetSeccStatus()
{
    SECC_CP_STATE_TYPE ret = SECC_CP_STATE_DEFAULT;
    int32_t CP_Level = (int32_t)(ChargerGetCpVoltage() / 100);

    //  TRACE_INFO("CP LEVEL %d\r\n", CP_Level);

    if((CP_Level >= (SECC_CP_VOLTAGE_A - SECC_CP_VOLTAGE_OFFSET)) && (CP_Level <= (SECC_CP_VOLTAGE_A + SECC_CP_VOLTAGE_OFFSET)))
    {
        ret = SECC_CP_STATE_A;
    }
    else if((CP_Level >= (SECC_CP_VOLTAGE_B - SECC_CP_VOLTAGE_OFFSET)) && (CP_Level <= (SECC_CP_VOLTAGE_B + SECC_CP_VOLTAGE_OFFSET)))
    {
        ret = SECC_CP_STATE_B;
    }
    else if((CP_Level >= (SECC_CP_VOLTAGE_C - SECC_CP_VOLTAGE_OFFSET)) && (CP_Level <= (SECC_CP_VOLTAGE_C + SECC_CP_VOLTAGE_OFFSET)))
    {
        ret = SECC_CP_STATE_C;
    }
    else if((CP_Level >= (SECC_CP_VOLTAGE_F - SECC_CP_VOLTAGE_OFFSET)) && (CP_Level <= (SECC_CP_VOLTAGE_F + SECC_CP_VOLTAGE_OFFSET)))
    {
        ret = SECC_CP_STATE_F;
    }
    return ret;
}

unsigned ChargerGetEvseIsolationStatus(void)
{
    return ChargerCtx.EVSE_STATUS.EVSE_ISOLATION_STATUS;
}

static void ChargerContextMappingInit()
{
    /* Charger TX(SECC RX) Message Mapping */
    //50ms
    EvseTxSeccMessage50ms[0].Data = &ChargerCtx.EVSE_STATUS;
    EvseTxSeccMessage50ms[1].Data = &ChargerCtx.EVSE_PRESENT_VOLTAGE_CURRENT;

    //200ms
    EvseTxSeccMessage200ms[0].Data = &ChargerCtx.EVSE_CONFIGURATION;
    EvseTxSeccMessage200ms[1].Data = &ChargerCtx.EVSE_CHARGE_PARAMETERS1;
    EvseTxSeccMessage200ms[2].Data = &ChargerCtx.EVSE_CHARGE_PARAMETERS2;

    //500ms
    EvseTxSeccMessage500ms[0].Data = &ChargerCtx.EVSE_DIN_ID1;
    EvseTxSeccMessage500ms[1].Data = &ChargerCtx.EVSE_DIN_ID2;
    EvseTxSeccMessage500ms[2].Data = &ChargerCtx.EVSE_DIN_ID3;
    EvseTxSeccMessage500ms[3].Data = &ChargerCtx.EVSE_DIN_ID4;
    EvseTxSeccMessage500ms[4].Data = &ChargerCtx.EVSE_ISO_ID1;
    EvseTxSeccMessage500ms[5].Data = &ChargerCtx.EVSE_ISO_ID2;
    EvseTxSeccMessage500ms[6].Data = &ChargerCtx.EVSE_ISO_ID3;
    EvseTxSeccMessage500ms[7].Data = &ChargerCtx.EVSE_ISO_ID4;
    EvseTxSeccMessage500ms[8].Data = &ChargerCtx.EVSE_ISO_ID5;

    //1000ms
    EvseTxSeccMessage1000ms[0].Data = &ChargerCtx.EVSE_SA_AGENT_CONNECTION_CONFIG;
    EvseTxSeccMessage1000ms[1].Data = &ChargerCtx.EVSE_SECC_PNC_CONFIG;
    EvseTxSeccMessage1000ms[2].Data = &ChargerCtx.EVSE_SA_AGENT_COMM_TIMEOUT;

    /* EVSE RX(SECC TX) Message Mapping */
    EvseRxSeccMessage[0].Data = &ChargerCtx.SECC_STATUS_LEGACY;
    EvseRxSeccMessage[1].Data = &ChargerCtx.SECC_CP_PP_STATUS;
    EvseRxSeccMessage[2].Data = &ChargerCtx.SECC_EV_SERVICE_SELECTION;
    EvseRxSeccMessage[3].Data = &ChargerCtx.SECC_SESSION_ID;
    EvseRxSeccMessage[4].Data = &ChargerCtx.SECC_EVCC_ID;
    EvseRxSeccMessage[5].Data = &ChargerCtx.SECC_EV_CHARGE_PARAMETERS1;
    EvseRxSeccMessage[6].Data = &ChargerCtx.SECC_EV_CHARGE_PARAMETERS2;
    EvseRxSeccMessage[7].Data = &ChargerCtx.SECC_EV_SOC_RELATED;
    EvseRxSeccMessage[8].Data = &ChargerCtx.SECC_TARGET_VOLTATE_CURRENT;
    EvseRxSeccMessage[9].Data = &ChargerCtx.SECC_TIMESTAMP;
    EvseRxSeccMessage[10].Data = &ChargerCtx.SECC_STATUS;
    EvseRxSeccMessage[11].Data = &ChargerCtx.SECC_EMERGENCY_NOTIFICATION;
    EvseRxSeccMessage[12].Data = &ChargerCtx.SECC_SA_COMM_STATUS;
    EvseRxSeccMessage[13].Data = &ChargerCtx.SECC_IP_STATUS;

}

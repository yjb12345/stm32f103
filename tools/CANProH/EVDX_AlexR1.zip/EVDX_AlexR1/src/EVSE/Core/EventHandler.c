/**
******************************************************************************
* @file           : EventHandler.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Liv EV Infra Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

EventHandler.c is a module that handles the main events of the charger.
This is the part that handles direct linkage with the HAL library of STM32.

******************************************************************************
*/

#include "EventControl.h"
#include "Secc.h"
#include "PowerModule.h"
#include "IsolationMonitor.h"
#include "Console.h"

#if _OLD_BD
extern UART_HandleTypeDef ConsoleHandle;
#else
extern UART_HandleTypeDef huart1;

#endif

#if _OLD_BD
// 사용되지 않는듯 한데... 왜 있는지,
extern UART_HandleTypeDef MeterMT4xHandle;
#endif

#ifdef _ALEX_FDCAN_USED_
extern FDCAN_HandleTypeDef hfdcan1;
extern FDCAN_HandleTypeDef PowerModuleCanHandle; // alex marked: not used in original code
#endif

#ifdef _GRIDWIZ_CAN_USED_
extern CAN_HandleTypeDef SeccCanHandle;
extern CAN_HandleTypeDef PowerModuleCanHandle;
#endif

extern uint8_t rxCharacter;
extern uint8_t prevrxCharacter;

#ifdef _GRIDWIZ_CAN_USED_
/* CAN ISR Handler -----------------------------------------------------------*/
void CAN1_RX0_IRQHandler(void)
{
    printf("EventHandler #1\n\r");

    HAL_CAN_IRQHandler(&SeccCanHandle);
}

void CAN1_SCE_IRQHandler(void)
{
    printf("EventHandler #2\n\r");
    HAL_CAN_IRQHandler(&SeccCanHandle);
}

void CAN2_RX0_IRQHandler(void)
{
    printf("EventHandler #3\n\r");
    HAL_CAN_IRQHandler(&PowerModuleCanHandle);
}

void CAN2_SCE_IRQHandler(void)
{
    printf("EventHandler #4\n\r");
    HAL_CAN_IRQHandler(&PowerModuleCanHandle);
}
#endif
#ifdef _ALEX_OLD_BD_
/* UART IRQ Handler_ ---------------------------------------------------------*/
void USART1_IRQHandler()
{
#ifdef _OLD_BD
    HAL_UART_IRQHandler(&ConsoleHandle);
#else
    HAL_UART_IRQHandler(&huart1);
#endif
}
#endif
/* EXT9_5 IRQ Handler --------------------------------------------------------*/
void EXTI9_5_IRQHandler(void)
{
    printf("EventHandler #5\n\r");
    HAL_NVIC_ClearPendingIRQ(EXTI9_5_IRQn);
}

void TIM6_DAC_IRQHandler(void)
{
    printf("EventHandler #6\n\r");
}
#ifdef _GRIDWIZ_CAN_USED_
/* CAN HAL Callback ----------------------------------------------------------*/
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    if (hcan->Instance == CAN1)
    {
        GW_SeccRxFifo0MsgPendingCallback();
    }
}

void HAL_CAN_RxFifo0FullCallback(CAN_HandleTypeDef *hcan)
{
    if (hcan->Instance == CAN1)
    {
        //        TRACE_WARN("EVSE CAN RX FIFO0 IS FULLED");
    }
}

void HAL_CAN_ErrorCallback(CAN_HandleTypeDef *hcan)
{
    if (hcan->Instance == CAN1)
    {
        if ((hcan->ErrorCode & HAL_CAN_ERROR_RX_FOV0) || (hcan->ErrorCode & HAL_CAN_ERROR_TX_ALST0) || (hcan->ErrorCode & HAL_CAN_ERROR_TX_ALST1) || (hcan->ErrorCode & HAL_CAN_ERROR_TX_ALST2))
        {
            //            TRACE_WARN("EVSE CAN ARBITRATION LOST");
        }
        else
        {
            TRACE_ERROR("EVSE CAN ERROR OCCURRED [0x%08x]", hcan->ErrorCode);
        }
    }
}
#endif

#ifdef _ALEX_FDCAN_USED_

void HAL_FDCAN_ErrorCallback(FDCAN_HandleTypeDef *hfdcan)
{
    if (hfdcan->Instance == FDCAN1)
    {
        printf("HAL_FDCAN_ErrorCallback \n\r");
        //        if (hfdcan->ErrorCode & HAL_FDCAN_ERROR_ARBITRATION_LOST)
        //        {
        //            //            TRACE_WARN("EVSE FDCAN ARBITRATION LOST");
        //        }
        //        else
        //        {
        //            TRACE_ERROR("EVSE FDCAN ERROR OCCURRED [0x%08x]", hfdcan->ErrorCode);
        //        }
    }
}

void FDCAN1_IT0_IRQHandler(void)
{
    printf("HAL_FDCAN_ErrorCallback \n\r");
    HAL_FDCAN_IRQHandler(&hfdcan1);
}

void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
    printf("HAL_FDCAN_RxFifo0Callback \n\r");
    uint8_t RxData[8];
    FDCAN_RxHeaderTypeDef RxHeader;
    if ((RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE) != RESET)
    {
        /* Retreive Rx messages from RX FIFO0 */
        if (HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK)
        {
            /* Reception Error */
            Error_Handler();
        }
        if (HAL_FDCAN_ActivateNotification(hfdcan, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0) != HAL_OK)
        {
            /* Notification Error */
            Error_Handler();
        }
    }
}
//
//void FDCAN2_IT0_IRQHandler(void)
//{
//    printf("HAL_FDCAN_ErrorCallback \n\r");
//    HAL_FDCAN_IRQHandler(&hfdcan2);
//}

#endif

/* UART HAL Callback ---------------------------------------------------------*/
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    printf("HAL_UART_TxCpltCallback #7\n\r");

    if (huart->Instance == USART1)
    {
        ;
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // printf("\n\r======>HAL_UART_RxCpltCallback new=%x prev=%x\n\r", rxCharacter, prevrxCharacter);
    if (huart->Instance == USART1)
    {
        // printf("HAL_UART_RxCpltCallback no JOB\n\r");

        // if (prevrxCharacter != rxCharacter)
        {
            // printf("rx=%c  prev=%c\n\r", rxCharacter, prevrxCharacter);
            //  GW_ConsoleRxHandler();
            // GW_EventNotify(GW_EVENT_KEY_PRESSED); // alex : 나중에 GW_ConsoleRxHandler()으로 옮기자.{
            prevrxCharacter = rxCharacter;
        }
        // else            printf("rxCharacter=%c  is same with prevrxCharacter, drop it\n\r", rxCharacter);

#ifdef _OLD_BD
        HAL_UART_Receive_IT(&ConsoleHandle, &rxCharacter, 1);
#else
        HAL_UART_Receive_IT(&huart1, &rxCharacter, 1);
#endif
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    printf("HAL_UART_ErrorCallback #9\n\r");
    if (huart->Instance == USART1)
    {
        ;
    }
}

/* ADC HAL Callback ----------------------------------------------------------*/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    printf("HAL_ADC_ConvCpltCallback #10\n\r");
#ifdef _ALEX_OLD_BD_
    if (hadc->Instance == ADC1)
    {
        GW_ADC_ConvCpltCallback(hadc);
    }
#endif
}

/* (__weak) User function ----------------------------------------------------*/
__weak void GW_PowerModuleRxFifo0MsgPendingCallback(void)
{
    /* Prevent unused argument(s) compilation warning */

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_PowerModuleRxFifo0MsgPendingCallback could be implemented in the user file
    */
}

__weak void GW_MeterMT4xCpltSendRequestCallback(void)
{
    /* Prevent unused argument(s) compilation warning */

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_MeterMT4xCpltSendRequestCallback could be implemented in the user file
    */
}

__weak void GW_MeterMT4xCpltReceiveResponseCallback(void)
{
    /* Prevent unused argument(s) compilation warning */

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_MeterMT4xCpltReceiveResponseCallback could be implemented in the user file
    */
}

__weak void GW_MeterMT4xErrorCallback(void)
{
    /* Prevent unused argument(s) compilation warning */

    /* NOTE : This function Should not be modified, when the callback is needed,
    the GW_MeterMT4xErrorCallback could be implemented in the user file
    */
}

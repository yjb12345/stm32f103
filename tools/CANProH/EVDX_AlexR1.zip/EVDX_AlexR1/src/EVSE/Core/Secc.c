/**
******************************************************************************
* @file           : Secc.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Secc Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

Secc.c is a module to communicate with SECC PLC MODEM.

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "Secc.h"
#include "Peppermint4xCan.h"
#include <string.h>

#include <timers.h> // alex added for type "TimerHandle_t"
/* Private variables ---------------------------------------------------------*/
static volatile uint32_t State = GW_INITIALIZE;

#ifdef _ALEX_CMSIS_V2_
static osMemoryPoolId_t MP;
static osMessageQueueId_t TransmitMQ;
osTimerId_t timerId = NULL;
#else
static osPoolId MP;
static osMessageQId TransmitMQ;
#endif

extern osThreadId SeccTransmitTaskId;
#ifdef _GRIDWIZ_CAN_USED_
/* Exported variables --------------------------------------------------------*/
CAN_HandleTypeDef SeccCanHandle;
CAN_FilterTypeDef SeccCanFilter;
#endif

#ifdef _ALEX_FDCAN_USED_
extern FDCAN_HandleTypeDef hfdcan1; // no neded ?

#endif

/* Private function prototypes -----------------------------------------------*/
#ifdef _ALEX_CMSIS_V2_
static void SeccTimerCallback(void *arg);

#else
osPoolDef(SeccMP, 40, GW_CanMessage);
osMessageQDef(SeccMQ, 40, GW_CanMessage);
osTimerDef(SeccTimer, SeccTimerCallback);
static void SeccTimerCallback(void const *arg);
#endif
/* Exported functions --------------------------------------------------------*/
// alex added : https://controllerstech.com/stm32-fdcan-in-loopback-mode/
osStatus GW_SeccInit(void)
{
#ifdef _GRIDWIZ_CAN_USED_
    /** CAN Instance */
    SeccCanHandle.Instance = GW_SECC_CAN_INSTANCE;
    SeccCanHandle.Init.Prescaler = GW_SECC_CAN_PRESCALER; // 6
    SeccCanHandle.Init.Mode = CAN_MODE_NORMAL;
    SeccCanHandle.Init.SyncJumpWidth = GW_SECC_CAN_SWJ;
    SeccCanHandle.Init.TimeSeg1 = GW_SECC_CAN_BS1; // alex added:  0x00090000
    SeccCanHandle.Init.TimeSeg2 = GW_SECC_CAN_BS2; //  alex added: 0x00000000
    SeccCanHandle.Init.TimeTriggeredMode = DISABLE;
    SeccCanHandle.Init.AutoBusOff = DISABLE;
    SeccCanHandle.Init.AutoWakeUp = DISABLE;
    SeccCanHandle.Init.AutoRetransmission = DISABLE;
    SeccCanHandle.Init.ReceiveFifoLocked = DISABLE;
    SeccCanHandle.Init.TransmitFifoPriority = DISABLE;
    if (HAL_CAN_Init(&SeccCanHandle) != HAL_OK)
    {
        _Error_Handler(__FILE__, __LINE__);
    }

    /** Filter: Peppermin Can  */
    uint32_t filterId = GW_SECC_CAN_FILTER_MASK;
    SeccCanFilter.FilterIdHigh = (filterId << 3) >> 16;
    SeccCanFilter.FilterIdLow = (0xffff & (filterId << 3)) | (1 << 2);
    SeccCanFilter.FilterMaskIdHigh = (filterId << 3) >> 16;
    SeccCanFilter.FilterMaskIdLow = (0xffff & (filterId << 3)) | (1 << 2);
    ;
    SeccCanFilter.FilterFIFOAssignment = 0;
    SeccCanFilter.FilterBank = 0;
    SeccCanFilter.FilterMode = CAN_FILTERMODE_IDMASK;
    SeccCanFilter.FilterScale = CAN_FILTERSCALE_32BIT;
    SeccCanFilter.FilterActivation = ENABLE;
    SeccCanFilter.SlaveStartFilterBank = 0;
    if (HAL_CAN_ConfigFilter(&SeccCanHandle, &SeccCanFilter) != HAL_OK)
    {
        _Error_Handler(__FILE__, __LINE__);
    }
#else
    FDCAN_FilterTypeDef sFilterConfig;
    // uint32_t filterId = GW_SECC_CAN_FILTER_MASK; // (0x15EC0000)
#if 1
    sFilterConfig.IdType = FDCAN_EXTENDED_ID; // Use FDCAN_STANDARD_ID for 11-bit IDs or FDCAN_EXTENDED_ID for 29-bit IDs
#else
    sFilterConfig.IdType = FDCAN_STANDARD_ID; // Use FDCAN_STANDARD_ID for 11-bit IDs or FDCAN_EXTENDED_ID for 29-bit IDs
#endif
    sFilterConfig.FilterIndex = 0;                        // Index of the filter
    sFilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0; // FDCAN_FILTER_TO_RXFIFO0, FDCAN_FILTER_TO_RXFIFO1, or other options
#if 0    
     sFilterConfig.FilterType = FDCAN_FILTER_MASK;         // Use FDCAN_FILTER_MASK or FDCAN_FILTER_RANGE
     sFilterConfig.FilterID1 = 0x00001f0   // RANGE FILTER BEGIN
     sFilterConfig.FilterID2 = 0x00001f1; // RANGE FILTER END   , RANGE 필터 적용 예정
#else
    sFilterConfig.FilterType = FDCAN_FILTER_RANGE; // Use FDCAN_FILTER_MASK or FDCAN_FILTER_RANGE
    sFilterConfig.FilterID1 = 0x000000;            // RANGE FILTER BEGIN
    sFilterConfig.FilterID2 = 0x1FFFFFFF;          // RANGE FILTER END   , RANGE 필터 적용 예정
#endif
    // uint32_t filterId = 0x15EC0000;
    //   sFilterConfig.FilterID1 = (filterId << 3) >> 16 | (0xffff & (filterId << 3)) | (1 << 2); // ID to be filtered
    //   sFilterConfig.FilterID2 = (filterId << 3) >> 16 | (0xffff & (filterId << 3)) | (1 << 2); // Mask for filtering (or second ID if using range filter)

    if (HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
    {
        // Filter configuration Error
        Error_Handler();
    }

#endif
#ifdef _ALEX_CMSIS_V2_
    MP = osMemoryPoolNew(40, sizeof(GW_CanMessage), NULL);
    if (MP == NULL)
    {
        printf("GW_CanMessage Memory pool creation failure\n\r");
    }
    TransmitMQ = osMessageQueueNew(sizeof(GW_CanMessage), 40, NULL);
    if (TransmitMQ == NULL)
    {
        // Handle message queue creation failure
        printf("osMessageQueueNew create failure\n\r");
    }
#else
    /** Message Q & Memory Pool */
    MP = osPoolCreate(osPool(SeccMP));
    TransmitMQ = osMessageCreate(osMessageQ(SeccMQ), NULL);
#endif

    State = GW_READY;

    return osOK;
}

void GW_SeccDeInit(void)
{
    ;
}

void GW_Secc_NVIC_Init(void)
{
#ifdef _GRIDWIZ_CAN_USED_
    HAL_NVIC_SetPriority(GW_SECC_RX0_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(GW_SECC_RX0_IRQn);
#endif

#ifdef _ALEX_FDCAN_USED_
    HAL_NVIC_SetPriority(FDCAN1_IT0_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(FDCAN1_IT0_IRQn);
#endif
}

void GW_Secc_NVIC_DeInit(void)
{
#ifdef _GRIDWIZ_CAN_USED_
    HAL_NVIC_DisableIRQ(GW_SECC_RX0_IRQn);
#endif

#ifdef _ALEX_FDCAN_USED_
    HAL_NVIC_DisableIRQ(FDCAN1_IT0_IRQn);
#endif
}

void GW_SeccStart(void)
{

#ifdef _GRIDWIZ_CAN_USED_
    /** Interrupt Enable */
    HAL_CAN_ActivateNotification(&SeccCanHandle, CAN_IT_TX_MAILBOX_EMPTY |
                                                     CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_RX_FIFO0_FULL |
                                                     CAN_IT_RX_FIFO0_OVERRUN | CAN_IT_BUSOFF);

    HAL_CAN_Start(&SeccCanHandle);
#endif

#ifdef _ALEX_FDCAN_USED_

    if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK)
    {
        printf("SeccStart HAL_FDCAN_Start Error\n\r");
        Error_Handler();
    }

    if (HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE | FDCAN_IT_RX_FIFO0_FULL, 0) != HAL_OK)
    {
        /* Notification Error */
        Error_Handler();
    }
#endif

#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsSet(SeccTransmitTaskId, 0xABCD);
#else
    osSignalSet(SeccTransmitTaskId, 0xABCD);
#endif
}

void GW_SeccStop(void)
{
#ifdef _GRIDWIZ_CAN_USED_
    HAL_CAN_Stop(&SeccCanHandle);
    HAL_CAN_DeactivateNotification(&SeccCanHandle, CAN_IT_TX_MAILBOX_EMPTY |
                                                       CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_RX_FIFO0_FULL |
                                                       CAN_IT_RX_FIFO0_OVERRUN | CAN_IT_BUSOFF);
#endif
}

void GW_SeccTransmitActivation(void)
{
    State = GW_RUNNING;
}

void GW_SeccTransmitDeActivation(void)
{
    State = GW_READY;
}

#ifdef _ALEX_CMSIS_V2_
GW_CONTROLSeccMailBoxId GW_SeccAttachCanMessage(osTimerType_t type, uint32_t ms, GW_Message aMsg[])
#else
GW_CONTROLSeccMailBoxId GW_SeccAttachCanMessage(os_timer_type type, uint32_t ms, GW_Message aMsg[])
#endif
{
#ifdef _ALEX_CMSIS_V2_
    osTimerId_t timerId = NULL;
    if (aMsg)
    {
        timerId = osTimerNew(SeccTimerCallback, type, aMsg, NULL);
        if (timerId == NULL)
        {
            printf("timerId == NULL\n\r");
            return;
        }
        osStatus_t status = osTimerStart(timerId, ms); // Timer period in ticks
        if (status != osOK)
        {
            printf("status != osOK\n\r");
        }
    }

    return timerId;
#else
    osTimerId timerId = NULL;
    if (aMsg)
    {
        timerId = osTimerCreate(osTimer(SeccTimer), type, aMsg);
        osTimerStart(timerId, ms);
    }

    return timerId;
#endif
}

void GW_SeccDeteachCanMessage(osTimerId timerId)
{
    if (timerId)
        osTimerDelete(timerId);
}

#ifdef _ALEX_CMSIS_V2_
void SeccTransmitTask(void *arguments)
#else
void SeccTransmitTask(void const *argument)
#endif
/* Privated functions --------------------------------------------------------*/
// void SeccTransmitTask(void const *argument)
{
    printf(">>>>>>>>>>>>>>>>>SeccTransmitTask  start\n\r");
    osDelay(3000);

    uint32_t pendingCnt = 0;
    uint32_t txMailBox;
    osEvent evt;

    uint8_t data[8];
    GW_Message *msg;
#ifdef _GRIDWIZ_CAN_USED_
    CAN_TxHeaderTypeDef canHeader;
    canHeader.IDE = CAN_ID_EXT;
    canHeader.RTR = 0;                      // Data Frame
    canHeader.DLC = 8;                      // 8 bytes
    canHeader.TransmitGlobalTime = DISABLE; // GlobalTime Disable : refer TGT Register
#else                                       //_ALEX_FDCAN_USED_
    FDCAN_TxHeaderTypeDef TxHeader = {};
    // uint8_t TxData[8] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
    uint8_t TxData[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    //  uint8_t TxData[8] = {0xf0, 0xf0, 0xf0, 0xf0, 0x07, 0x07, 0x07, 0x07};
#if 1
    // TxHeader.Identifier = 0x7fe;
    TxHeader.Identifier = 0x15ec0001;
    TxHeader.IdType = FDCAN_EXTENDED_ID; // FDCAN_STANDARD_ID; FDCAN_EXTENDED_ID
#else

    TxHeader.Identifier = 0x04;          // 0X04
    TxHeader.IdType = FDCAN_STANDARD_ID; // FDCAN_STANDARD_ID; FDCAN_EXTENDED_ID
#endif

    TxHeader.TxFrameType = FDCAN_DATA_FRAME; // FDCAN_REMOTE_FRAME
    TxHeader.DataLength = FDCAN_DLC_BYTES_8;
    // TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
    TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
    TxHeader.BitRateSwitch = FDCAN_BRS_OFF;
    TxHeader.FDFormat = FDCAN_CLASSIC_CAN; ////  TxHeader.FDFormat = FDCAN_FD_CAN;
    TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
    TxHeader.MessageMarker = 0;

#endif

#if 1
    while (1)
    {
        if (HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, TxData) != HAL_OK)
        {
            TRACE_ERROR("SECC CAN TX ERROR ID[0x%08x] ERR[0x%08x]", msg->Id, hfdcan1.ErrorCode);
            Error_Handler();
        }
        // printf(">>>>>>>>>>>>>>>> can tx ==> no\n\r");
        printf(">>>>>>>>>>>>>>>> can tx ==> going\n\r");
        osDelay(1000);
    }

#endif

#ifdef _ALEX_CMSIS_V2_
    osThreadFlagsWait(0xABCD, osFlagsWaitAny, osWaitForever);
#else
    osSignalWait(0xABCD, osWaitForever);
#endif
    /* Waiting ready state */
    printf(">>>>>>>>>>>>>>>>> SeccTransmitTask  #2\n\r");
    while (1)
    {
        if (State <= GW_INITIALIZE)
        {
            while (1)
            {
                osDelay(1000);
                if (State > GW_INITIALIZE)
                    break;

                printf(">>>>>>>>>>>>>>>>> SeccTransmitTask  State =%d > GW_INITIALIZE=%d\n\r", State, GW_INITIALIZE);
            }
        }
#ifdef _ALEX_CMSIS_V2_
        // osStatus_t ret = osMessageQueueGet(TransmitMQ, (void *)&evt, NULL, osWaitForever);
        osStatus_t ret = osMessageQueueGet(TransmitMQ, &msg, NULL, osWaitForever);
        if ((State & GW_RUNNING) && (evt.status == osEventMessage)) // ret check arequired
#else
        evt = osMessageGet(TransmitMQ, osWaitForever);
        if ((State & GW_RUNNING) && (evt.status == osEventMessage))
#endif
        {

#ifdef _GRIDWIZ_CAN_USED_
            /** Polling CAN Transfer */
            msg = evt.value.p;
            canHeader.ExtId = msg->Id;
            memcpy(data, msg->Data, sizeof(data));

            /* Pending Check */
            while (HAL_CAN_GetTxMailboxesFreeLevel(&SeccCanHandle) == 0)
            {
                osDelay(2);
                pendingCnt++;
                if (pendingCnt > 4)
                {
                    pendingCnt = 0;
                    /* Pending Check */
                }
                break;
            };

            if (HAL_CAN_AddTxMessage(&SeccCanHandle, &canHeader, data, &txMailBox) != HAL_OK)
            {
                TRACE_ERROR("SECC CAN TX ERROR ID[0x%08x] ERR[0x%08x]", msg->Id, SeccCanHandle.ErrorCode);
            }
            else
            {
            }
#else
            printf("SeccTransmitTask  X1  msg->Id=\n\r", msg->Id);
            printf("SeccTransmitTask  X1  msg->Data=\n\r", msg->Data);
            if (HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, msg->Data) != HAL_OK)
            {
                TRACE_ERROR("SECC CAN TX ERROR ID[0x%08x] ERR[0x%08x]", msg->Id, hfdcan1.ErrorCode);
                Error_Handler();
            }
#endif
        }
    }
}

#ifdef _ALEX_CMSIS_V2_
static void SeccTimerCallback(void *arg)
#else
static void SeccTimerCallback(void const *arg)
#endif
{
    uint32_t i = 0;
    // printf("SeccTimerCallback State=%d GW_RUNNING=%d\n\r", State, GW_RUNNING);
    if (State == GW_RUNNING)
    {
        GW_Message *aMsg = pvTimerGetTimerID((TimerHandle_t)arg);

        /** SendNotify to Transmit Task */
        while (aMsg[i].Data)
        {
            if (aMsg[i].Id == CAN_ID_H15ECC002)
                ((CANID_H15ECC002 *)(aMsg[i].Data))->EVSE_HEARTBEAT++;

#ifdef _ALEX_CMSIS_V2_
            osMessageQueuePut(TransmitMQ, (uint32_t)(aMsg + i), osPriorityAboveNormal, 1);
#else
            osMessagePut(TransmitMQ, (uint32_t)(aMsg + i), 1);
#endif
            i++;
        }
    }
}

/* HAL Callback functions ----------------------------------------------------*/
void GW_SeccRxFifo0MsgPendingCallback(void)
{
#ifdef _ALEX_CMSIS_V2_
#ifdef _GRIDWIZ_CAN_USED_
    CAN_RxHeaderTypeDef canHeader;
#endif
    // GW_CanMessage *msg = osPoolCAlloc(MP);
    // void *allocatedBlock = osMemoryPoolAlloc(MP, 0);
    GW_CanMessage *msg = (GW_CanMessage *)osMemoryPoolAlloc(MP, 0);
    if (msg == NULL)
    {
        TRACE_ERROR("osMemoryPoolAlloc failed\n\r");
        return;
    }
#ifdef _GRIDWIZ_CAN_USED_
    if (HAL_CAN_GetRxMessage(&SeccCanHandle, 0, &canHeader, msg->CanData) == HAL_OK)
    {
        msg->CanId = canHeader.ExtId;
        /** SendNotify to GW_CONTROL Loop */
        GW_EventNotifySend(GW_EVENT_SECC_CAN_RX_CPLT, MP, msg);
    }
    else
    {
        /* release memory pool */
        osPoolFree(MP, msg);
        TRACE_ERROR("SECC CAN RX ERROR [0x%08x]", SeccCanHandle.ErrorCode);
    }
#endif
    osStatus_t status = osMemoryPoolFree(MP, msg);
    if (status != osOK)
    {
        // Handle free failure
    }

#else
    CAN_RxHeaderTypeDef canHeader;
    GW_CanMessage *msg = osPoolCAlloc(MP);

    if (HAL_CAN_GetRxMessage(&SeccCanHandle, 0, &canHeader, msg->CanData) == HAL_OK)
    {
        msg->CanId = canHeader.ExtId;
        /** SendNotify to GW_CONTROL Loop */
        GW_EventNotifySend(GW_EVENT_SECC_CAN_RX_CPLT, MP, msg);
    }
    else
    {
        /* release memory pool */
        osPoolFree(MP, msg);
        TRACE_ERROR("SECC CAN RX ERROR [0x%08x]", SeccCanHandle.ErrorCode);
    }
#endif
}

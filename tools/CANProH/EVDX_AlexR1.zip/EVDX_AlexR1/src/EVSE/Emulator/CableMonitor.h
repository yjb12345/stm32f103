/*
 * CableMonitor.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EMULATOR_CABLEMONITOR_H_
#define AP_EMULATOR_CABLEMONITOR_H_


#include "EventControl.h"

#define DEFAULT_CABLE_MONITOR_PERIOD            (100) //ms

typedef struct {
  uint16_t      Id;
  int32_t       Value;
  uint32_t      Scale;
} CableMonitorItem;

void GW_CableMonitorInit(void);
void GW_CableMonitorDeInit(void);

void GW_CableMonitorStart(void);
void GW_CableMonitorStop(void);

GW_CONTROLStateEnum   GW_CableMonitorGetState(void);
GW_CONTROLStatus      GW_CableMonitorSetResponseSpeed(uint32_t ms);

void CableMonitorTask(void const *argument);

#endif /* AP_EMULATOR_CABLEMONITOR_H_ */

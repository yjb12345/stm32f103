/*
 * PowerModule.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EMULATOR_POWERMODULE_H_
#define AP_EMULATOR_POWERMODULE_H_

#define _NO_CAN_BY_ALEX

#include "EventControl.h"

#pragma pack(push, 1)
typedef union {
    uint8_t Raw[8];
    struct {
        uint32_t HighWord;
        float    Voltage;
    };
    struct {
        uint32_t LowWord;
        float    Current;
    };
} InfyPowerOutputValue;

typedef union {
    uint8_t Raw[8];
    struct {
        unsigned Reseverd0         : 8;
        unsigned Reseverd1         : 8;
        unsigned ModuleGroup       : 8;
        unsigned Reseverd2         : 8;
        unsigned ModuleTemprature  : 8;
        struct {
            unsigned ModuleOff       : 1;
            unsigned InputOverVolt   : 1;
            unsigned InputUnderVolt  : 1;
            unsigned InputUnbalance  : 1;
            unsigned InputPhaseLost  : 1;
            unsigned LoadUnsharing   : 1;
            unsigned ModuleIdRepetition : 1;
            unsigned PowerLimit         : 1;
        } ModuleState2;
        struct {
            unsigned CommInterrupt      : 1;
            unsigned WalkInEnable       : 1;
            unsigned OutputOverVolt     : 1;
            unsigned OverTemprature     : 1;
            unsigned FanFault           : 1;
            unsigned ModuleProtect      : 1;
            unsigned ModuleFault        : 1;
            unsigned ModuleOffState     : 1;
        } ModuleState1;
        struct {
            unsigned Reserved           : 7;
            unsigned OutputShort        : 1;
        } ModuleState0;
    };
} InfyPowerState;
#pragma pack(pop)

void GW_PowerModuleInit(void);
void GW_PowerModuleDeInit(void);
void GW_PowerModule_NVIC_Init(void);
void GW_PowerModule_NVIC_DeInit(void);
void GW_PowerModuleStart(void);
void GW_PowerModuleStop(void);

GW_CONTROLStatus GW_PowerModuleSetResponseSpeed(uint32_t ms);

void GW_PowerModuleAllOn(void);
void GW_PowerModuleAllOff(void);
uint32_t GW_PowerModuleGetOutputStatus(void);
void GW_PowerModuleSetTotalOutput(int32_t mV, int32_t mA);
void GW_PowerModuleGetTotalOutput(uint32_t *mV, uint32_t *mA);
void GW_PowerModuleSetMaximunOutput(uint32_t mV, uint32_t mA);
void GW_PowerModuleGetTotalNum(void);

void GW_PowerModuleRxFifo0MsgPendingCallback(void);

void PowerModuleTransmitTask(void const *argument);


#endif /* AP_EMULATOR_POWERMODULE_H_ */

/*
 * IsolationMonitor.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EMULATOR_ISOLATIONMONITOR_H_
#define AP_EMULATOR_ISOLATIONMONITOR_H_


#include "EvseConfig.h"

#define ISOLATION_CNT 250
#define ISOLATION_WAIT_CNT 100
#define DC_PLUS_MAXVALUE 0.30007
#define DC_MINUS_MINVALUE 2.5487

#define DC_PLUS_500K_Coefficient1 0.002048
#define DC_PLUS_500K_Coefficient2 0.0051

#define DC_PLUS_100K_Coefficient1 0.000612
#define DC_PLUS_100K_Coefficient2 0.0021

#define DC_MINUS_500K_Coefficient1 0.003682
#define DC_MINUS_500K_Coefficient2 0.0071

#define DC_MINUS_100K_Coefficient1 0.005138
#define DC_MINUS_100K_Coefficient2 0.017

typedef struct{
    uint16_t status;
}ISOLATION_MSG;

typedef enum{
    ISOLATION_INVALID = 0,
    ISOLATION_VALID = 1,
    ISOLATION_WARING = 2,
    ISOLATION_FAULT = 3
}ISOLATION_STATUS_ENUM;

typedef enum{
    DC_MINUS = 0,
    DC_PLUS = 1,
    DC_WAIT = 2
}DC_TYPE_ENUM;

void GW_IsolationMonitorInit();
void GW_IsolationMonitorDeInit();
void GW_IsolationMonitorStart();

void GW_IsolationMonitorGetValue(uint32_t *adcValue);
void GW_IsolationMonitorCalibration();

// alex marked :  error for  "ADC_HandleTypeDef"
//void GW_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);

void GW_IsolationStatusMoniteringStart();
void GW_IsolationStatusMoniteringEnd();
void GW_CheckIsolationTimerOn();
void GW_CheckIsolationTimerOff();
void GW_IsolationEventSend(uint16_t status);

double GW_CalculateIsolationThreshold(double Coefficient1, double Coefficient2, uint32_t Value);


#endif /* AP_EMULATOR_ISOLATIONMONITOR_H_ */

/*
 * IsolationMonitorEmul.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : IsolationMonitorEmul.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Isolation Monitoring Emulator Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

IsolationMonitorEmul.c is an emulator module for checking the sample code.
In the emulator module, it operates as a timer,
It is composed of logic that checks from the point of CableCheck to the point of termination.

configure the insulation check ADC circuit in hardware and implement the check logic.
or Insulation check must be confirmed by the separately configured IMD module.

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "EventControl.h"
#include "IsolationMonitor.h"
#include "Relay.h"
#include "EvseContext.h"
#include "main.h"

/* Private variables ---------------------------------------------------------*/
__IO uint32_t AdcValue[1000];
__IO uint32_t AdcDCValue;
__IO uint32_t DcMinus;

#define _ADC_MARKED_BY_ALEX
#ifndef _ADC_MARKED_BY_ALEX
// 소스에서 사용이 않되는 것임.
ADC_HandleTypeDef IsolationAdcHandle;
#endif

/* Isolation Event MP */
#ifdef _ALEX_CMSIS_V2_
static osMemoryPoolId_t IsolationMP;
osTimerId_t CheckIsolationTimerId = NULL;
void GW_CheckIsolationCallback(void *arg);
#else
static osPoolId IsolationMP;
osPoolDef(MP_t, 20, ISOLATION_MSG);
osTimerId CheckIsolationTimerId = NULL;

void GW_CheckIsolationCallback(void const *arg);
osTimerDef(CheckIsolationTimer, GW_CheckIsolationCallback);
#endif

void GW_IsolationMonitorInit()
{
#ifdef _ALEX_CMSIS_V2_
    IsolationMP = osMemoryPoolNew(20, sizeof(ISOLATION_MSG), NULL);
    if (IsolationMP == NULL)
    {
        printf("ISOLATION_MSG Memory pool creation failure\n\r");
    }
#else
    IsolationMP = osPoolCreate(osPool(MP_t));
#endif
}

void GW_IsolationMonitorDeInit()
{
}

void GW_IsolationMonitorCalibration()
{
}

void GW_IsolationMonitorGetValue(uint32_t *adcValue)
{
    *adcValue = AdcDCValue;
}

/** ADC callback **/
// alex marked :  error for  "ADC_HandleTypeDef"
// void GW_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
//{
//    /* Block Average */
//    uint32_t i;
//    uint32_t tempDC;
//    tempDC = 0;
//    for (i = 0; i < 1000; i++)
//    {
//        tempDC = tempDC + AdcValue[i];
//    }
//
//    AdcDCValue = tempDC / 1000;
//}

void GW_IsolationStatusMoniteringStart()
{
#ifdef _ALEX_CMSIS_V2_
    if (CheckIsolationTimerId == NULL)
    {
        CheckIsolationTimerId = osTimerNew(GW_CheckIsolationCallback, osTimerPeriodic, NULL, NULL);
        if (CheckIsolationTimerId != NULL)
            GW_CheckIsolationTimerOn();
        else
        {
            TRACE_ERROR("Isolation Timer init error");
        }
    }
#else
    if (CheckIsolationTimerId == NULL)
    {
        CheckIsolationTimerId = osTimerCreate(osTimer(CheckIsolationTimer), osTimerPeriodic, NULL);
        if (CheckIsolationTimerId != NULL)
        {
            GW_CheckIsolationTimerOn();
        }
        else
        {
            TRACE_ERROR("Isolation Timer init error");
        }
    }
#endif
}

void GW_IsolationStatusMoniteringEnd()
{
    osStatus status;
    if (CheckIsolationTimerId != NULL)
    {
        GW_CheckIsolationTimerOff();

        status = osTimerDelete(CheckIsolationTimerId);
        if (status == osOK)
        {
            CheckIsolationTimerId = NULL;
        }
        else
        {
            TRACE_ERROR("Isolation Timer Deinit error");
        }
    }
}

void GW_CheckIsolationTimerOn()
{
    osStatus onStatus;
    if (CheckIsolationTimerId != NULL)
    {
        onStatus = osTimerStart(CheckIsolationTimerId, 50);
        if (onStatus == osOK)
            TRACE_TRACE("EVSE ISOLATION MONITERING START!!");
    }
}

void GW_CheckIsolationTimerOff()
{
    osStatus offStatus;
    if (CheckIsolationTimerId != NULL)
    {
        offStatus = osTimerStop(CheckIsolationTimerId);
        if (offStatus == osOK)
            TRACE_TRACE("EVSE ISOLATION MONITERING END!!");
    }
}

void GW_IsolationEventSend(uint16_t status)
{
#ifdef _ALEX_CMSIS_V2_
    ISOLATION_MSG *msg = (ISOLATION_MSG *)osMemoryPoolAlloc(IsolationMP, 0);
    msg->status = status;
    GW_EventNotifySend(GW_EVENT_ISOLATION_CPLT, IsolationMP, msg);
#else
    ISOLATION_MSG *msg;
    msg = osPoolCAlloc(IsolationMP);
    msg->status = status;
    GW_EventNotifySend(GW_EVENT_ISOLATION_CPLT, IsolationMP, msg);
#endif
}

double GW_CalculateIsolationThreshold(double Coefficient1, double Coefficient2, uint32_t Value)
{
    return ((Coefficient1 * Value) - Coefficient2);
}

/** Timer callback **/

#ifdef _ALEX_CMSIS_V2_
void GW_CheckIsolationCallback(void *arg)
#else

void GW_CheckIsolationCallback(void const *arg)
#endif

{
    static uint16_t DummyCnt = 0;

    /** Below is isolation check logic, so insert your code **/
    if (DummyCnt > 60)
    {
        GW_IsolationEventSend(ISOLATION_VALID);
    }
    else
    {
        DummyCnt++;
    }
}

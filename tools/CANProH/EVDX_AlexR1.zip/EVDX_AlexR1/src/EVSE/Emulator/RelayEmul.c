/**
******************************************************************************
* @file           : Relay.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : High Voltage Relay Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

Relay.c is the module that controls the power relay.
You have to implement the part that actually controls the power relay. 

******************************************************************************
*/
#include "Relay.h"

/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

void GW_RelayInit(RelayStatusEnum status)
{
    /*
    GPIO_InitTypeDef GPIO_InitStruct;
    
    GPIO_InitStruct.Pin = GW_RELAY_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GW_RELAY_PORT, &GPIO_InitStruct);
    
    HAL_GPIO_WritePin(GW_RELAY_PORT, GW_RELAY_PIN, (GPIO_PinState)status);
    */
}

void GW_RelayDeInit(void)
{
    ;
}

void GW_RelaySet(RelayStatusEnum status)
{
    //HAL_GPIO_WritePin(GW_RELAY_PORT, GW_RELAY_PIN, (GPIO_PinState)status);
}

GPIO_PinState GW_RelayGet(void)
{
    //return HAL_GPIO_ReadPin(GW_RELAY_PORT, GW_RELAY_PIN);
}

/*
 * Relay.h
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

#ifndef AP_EMULATOR_RELAY_H_
#define AP_EMULATOR_RELAY_H_

#include "EventControl.h"

typedef enum {
    RELAY_OPEN = GPIO_PIN_RESET,
    RELAY_CLOSE = GPIO_PIN_SET
} RelayStatusEnum;

void GW_RelayInit(RelayStatusEnum status);
void GW_RelaySet(RelayStatusEnum status);
GPIO_PinState GW_RelayGet(void);

#endif /* AP_EMULATOR_RELAY_H_ */

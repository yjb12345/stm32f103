/*
 * PowerModuleEmul.c
 *
 *  Created on: May 26, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : PowerModuleEmul.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : DC Power Module Emulate
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

PowerModuleEmul.c is an emulator module for checking the sample code.
The part that communicates with the actual power module and controls it should be implemented.

******************************************************************************

How to turn on
+ Relay CLOSE
+ GW_PowerModuleAllOn()
+ GW_PowerModuleSetTotalOutput(mV, mA)
How to turn off
+ GW_PowerModuleSetTotalOutput(0,0)
+ GW_PowerModuleAllOff()
+ Relay OPEN
How to get a PowerModule Output Voltage/Current
+

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "PowerModule.h"
#include "GW_Message.h"
#include "Tools.h"
#include <string.h>
#include <math.h>

/* Private define ------------------------------------------------------------*/
#define POWER_MODULE_LIMIT_VOLTAGE (500 * 1000) // 500V
#define POWER_MODULE_LIMIT_CURRENT (100 * 1000) // 100A

#define POWER_MODULE_ON 0
#define POWER_MODULE_OFF 1

/* Private typedef -----------------------------------------------------------*/
typedef struct
{
    uint32_t MaximumVoltageLimit;
    uint32_t MaximumCurrentLimit;

    uint32_t OutputStatus;
    uint32_t OutputMilliV;
    uint32_t OutputMilliA;
} PowerModuleConfig;

/* Private variables ---------------------------------------------------------*/
static volatile uint32_t State = GW_INITIALIZE;
static uint32_t ResponseSpeed = 50; // 50ms is default
static PowerModuleConfig PowerModuleCfg;

static int32_t outputMilliV = 0;
static int32_t outputMilliA = 0;

#ifdef _GRIDWIZ_CAN_USED_
/* Exported variables --------------------------------------------------------*/
CAN_HandleTypeDef PowerModuleCanHandle;
CAN_FilterTypeDef PowerModuleCanFilter;
#endif

#ifdef _ALEX_FDCAN_USED_
FDCAN_HandleTypeDef PowerModuleCanHandle;
// CAN_FilterTypeDef PowerModuleCanFilter;
#endif

/* Private function prototypes -----------------------------------------------*/

/* Exported functions --------------------------------------------------------*/
void GW_PowerModuleInit(void)
{
    /** Create Thread (Ready State) */
    State = GW_READY;

    /* Clear PowrPack Config */
    memset(&PowerModuleCfg, 0, sizeof(PowerModuleConfig));
    PowerModuleCfg.OutputStatus = POWER_MODULE_OFF;
}

void GW_PowerModuleDeInit(void)
{
    ;
}

void GW_PowerModule_NVIC_Init(void)
{
    ;
}

void GW_PowerModule_NVIC_DeInit(void)
{
    ;
}

void GW_PowerModuleStart(void)
{
    State = GW_RUNNING;
}

void GW_PowerModuleStop(void)
{
    State = GW_READY;
}

uint32_t GW_PowerModuleGetOutputStatus(void)
{
    return PowerModuleCfg.OutputStatus;
}

GW_CONTROLStatus GW_PowerModuleSetResponseSpeed(uint32_t ms)
{
    if (ms < 40) // minimun response time
        return GW_ERROR;

    ResponseSpeed = ms;
    return GW_OK;
}

void GW_PowerModuleGetTotalNum(void)
{
    ;
}

void GW_PowerModuleAllOn(void)
{
    PowerModuleCfg.OutputStatus = POWER_MODULE_ON;
}

void GW_PowerModuleAllOff(void)
{
    PowerModuleCfg.OutputStatus = POWER_MODULE_OFF;
}

void GW_PowerModuleSetTotalOutput(int32_t mV, int32_t mA)
{
    if (mV > PowerModuleCfg.MaximumVoltageLimit)
        PowerModuleCfg.OutputMilliV = PowerModuleCfg.MaximumVoltageLimit;
    else
        PowerModuleCfg.OutputMilliV = mV;

    if (mA > PowerModuleCfg.MaximumCurrentLimit)
        PowerModuleCfg.OutputMilliA = PowerModuleCfg.MaximumCurrentLimit;
    else
        PowerModuleCfg.OutputMilliA = mA;
}

void GW_PowerModuleGetTotalOutput(uint32_t *mV, uint32_t *mA)
{
    *mV = outputMilliV;
    *mA = outputMilliA;
}

void GW_PowerModuleGetTotalLimitOutput(uint32_t *mV, uint32_t *mA)
{
    *mV = POWER_MODULE_LIMIT_VOLTAGE; // 500V
    *mA = POWER_MODULE_LIMIT_CURRENT; // 100A
}

void GW_PowerModuleSetMaximunOutput(uint32_t mV, uint32_t mA)
{
    PowerModuleCfg.MaximumVoltageLimit = mV;
    PowerModuleCfg.MaximumCurrentLimit = mA;
}

/* Task functions ------------------------------------------------------------*/
void PowerModuleTransmitTask(void const *argument)
{
    TickType_t startTick = 0;
    TickType_t elaspedTick = 0;
    printf("PowerModuleTransmitTask  start\n\r");
#ifdef _THREAD_TEST_ONLY_
    for (;;)
    {
        printf("PowerModuleTransmitTask running\n\r");
        osDelay(3000);
    }
#endif
    while (State > GW_INITIALIZE)
    {
        // printf("ChargeTask  State=%d\n\r", State);
        // osDelay(1000);

        if (PowerModuleCfg.OutputStatus == POWER_MODULE_ON)
        {
            elaspedTick = diffTick(startTick, xTaskAlexGetTickCount());
            /* Voltage */
            outputMilliV += 125 * elaspedTick; // delta is 125mV/ms;
            outputMilliV = outputMilliV > PowerModuleCfg.OutputMilliV ? PowerModuleCfg.OutputMilliV : outputMilliV;

            /* Current */
            outputMilliA += 10 * elaspedTick; // delta is 10mA/ms
            outputMilliA = outputMilliA > PowerModuleCfg.OutputMilliA ? PowerModuleCfg.OutputMilliA : outputMilliA;
        }
        else
        {
            elaspedTick = diffTick(startTick, xTaskAlexGetTickCount());
            /* Voltage */
            outputMilliV -= 250 * elaspedTick; // delta is -250mV/ms
            outputMilliV = outputMilliV <= 0 ? 0 : outputMilliV;

            /* Current */
            outputMilliA -= 20 * elaspedTick; // delta is -20mA/ms
            outputMilliA = outputMilliA <= 0 ? 0 : outputMilliA;
        }

        startTick = xTaskAlexGetTickCount();

        osDelay(ResponseSpeed);
    }
}

/* Timer Callback functions --------------------------------------------------*/

/* Privated functions --------------------------------------------------------*/

/* HAL Callback functions ----------------------------------------------------*/

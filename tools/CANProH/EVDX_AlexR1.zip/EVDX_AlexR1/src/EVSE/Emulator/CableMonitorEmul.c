/*
 * CableMonitorEmul.c
 *
 *  Created on: Jun 3, 2024
 *      Author: A
 */

/**
******************************************************************************
* @file           : CableMonitorEmul.c
* @author         : GRIDWIZ EV Infra Team @jason
* @brief          : Cable Monitoring Emulation Module
******************************************************************************
Copyright (c) 2021 Gridwiz Inc. All rights reserved.
* Support & Technical Information
25, Sanun-ro 208beon-gil, Bundang-gu
Seongnam-si, Gyeonggi-do, 13460 Republic of Korea
Web : www.gridwiz.com
E-mail : yjs@gridwiz.com
******************************************************************************
##### How to use this module #####

CableMonitorEmul.c is an emulator module for checking sample code.
This emulator module utilizes CMSIS V1's memory pool and message queue.

You need to implement code that actually reads data from the meter (watt-hour meter) and processes it.

******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "CableMonitor.h"
#include "PowerModule.h"
#include "..\Util\Tools.h"

/* Private define ------------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
#define SIGNAL_RESPONSE_SPEED (0x0008)
#define SIGNAL_MASK SIGNAL_RESPONSE_SPEED
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static volatile GW_CONTROLStateEnum State = GW_INITIALIZE;

#ifdef _ALEX_CMSIS_V2_
static osMemoryPoolId_t MP;
#else
static osPoolId MP;
#endif

static uint32_t ResponseSpeed = DEFAULT_CABLE_MONITOR_PERIOD;

/* Private function prototypes -----------------------------------------------*/
// osPoolDef(CableMonitorMP, 20, CableMonitorItem);

/* Exported functions --------------------------------------------------------*/
void GW_CableMonitorInit(void)
{
#ifdef _ALEX_CMSIS_V2_
    MP = osMemoryPoolNew(20, sizeof(CableMonitorItem), NULL);
    if (MP == NULL)
    {
        printf("CableMonitorItem Memory pool creation failure\n\r");
    }
#else
    MP = osPoolCreate(osPool(CableMonitorMP));
#endif
    State = GW_READY;
}

void GW_CableMonitorDeInit(void)
{
    State = GW_STOP;
}

GW_CONTROLStateEnum GW_CableMonitorGetState(void)
{
    return State;
}

void GW_CableMonitorStart(void)
{
    State = GW_RUNNING;
}

void GW_CableMonitorStop(void)
{
    State = GW_READY;
}

GW_CONTROLStatus GW_CableMonitorSetResponseSpeed(uint32_t ms)
{
    if (ms < 80)
        return GW_ERROR;

    ResponseSpeed = ms;
    return GW_OK;
}

/* Privated functions --------------------------------------------------------*/
void CableMonitorTask(void const *argument)
{
#ifdef _ALEX_CMSIS_V2_
    printf("CableMonitorTask  start\n\r");
#ifdef _THREAD_TEST_ONLY_
    for (;;)
    {
        printf("CableMonitorTask   running\n\r");
        osDelay(3000);
    }
#endif
    uint8_t slaveId[2] = {0x01, 0x02}; // Voltage, Current */
    CableMonitorItem *item;
    uint32_t voltage, current;

    printf("CableMonitorTask Start\n\r");
    while (State > GW_INITIALIZE)
    {
        // printf("CableMonitorTask  #3\n\r");
        // osDelay(5000); // alex added for test
        // continue;
        // ;

        // printf("CableMonitorTask  State=%d\n\r", State);
        // osDelay(1000);

        GW_PowerModuleGetTotalOutput(&voltage, &current);

        item = (CableMonitorItem *)osMemoryPoolAlloc(MP, 0);
        item->Id = slaveId[0];
        item->Value = (int32_t)voltage;
        item->Scale = (uint32_t)1000; // default scale is 10; ex) 12.1 -> 121
        // printf("\n\rCM send1 \n\r");
        GW_EventNotifySend(GW_EVENT_CABLE_MONITOR_CPLT, MP, item);

        item = (CableMonitorItem *)osMemoryPoolAlloc(MP, 0);
        item->Id = slaveId[1];
        item->Value = (int32_t)current;
        item->Scale = (uint32_t)1000; // default scale is 10; ex) 12.1 -> 121

        // printf("\n\rCM send2 \n\r");
        GW_EventNotifySend(GW_EVENT_CABLE_MONITOR_CPLT, MP, item);

        osDelay(ResponseSpeed);
    }
#else
    uint8_t slaveId[2] = {0x01, 0x02}; // Voltage, Current */
    CableMonitorItem *item;
    uint32_t voltage, current;

    while (State > GW_INITIALIZE)
    {
        GW_PowerModuleGetTotalOutput(&voltage, &current);

        item = osPoolCAlloc(MP);
        item->Id = slaveId[0];
        item->Value = (int32_t)voltage;
        item->Scale = (uint32_t)1000; // default scale is 10; ex) 12.1 -> 121

        GW_EventNotifySend(GW_EVENT_CABLE_MONITOR_CPLT, MP, item);

        item = osPoolCAlloc(MP);
        item->Id = slaveId[1];
        item->Value = (int32_t)current;
        item->Scale = (uint32_t)1000; // default scale is 10; ex) 12.1 -> 121

        GW_EventNotifySend(GW_EVENT_CABLE_MONITOR_CPLT, MP, item);

        osDelay(ResponseSpeed);
    }
#endif
}

/*
 * hw.h
 *
 *  Created on: Jul 5, 2024
 *      Author: A
 */

#ifndef SRC_HW_HW_H_
#define SRC_HW_HW_H_

#include "hw_def.h"

void hwInit(void);

#endif /* SRC_HW_HW_H_ */

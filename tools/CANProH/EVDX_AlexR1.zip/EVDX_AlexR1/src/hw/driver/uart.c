/*
 * uart.c
 *
 *  Created on: 2021. 6. 21.
 *      Author: baram
 */

/*
 *
 * _DEF_UART1
 *      USB CDC
 */

#include "uart.h"
#include "cdc.h"
#include "qbuffer.h"

#ifdef _USE_HW_UART

#define UART_RX_BUF_LENGTH 1024

typedef enum
{
  UART_HW_TYPE_STM32,
  UART_HW_TYPE_USB,
  UART_HW_TYPE_BT_SPP,
} UartHwType_t;

typedef struct
{
  bool is_open;
  uint32_t baud;
  UartHwType_t type;

  uint8_t rx_buf[UART_RX_BUF_LENGTH];
  qbuffer_t qbuffer;
  UART_HandleTypeDef *p_huart;
  DMA_HandleTypeDef *p_hdma_rx;

} uart_tbl_t;

static uart_tbl_t uart_tbl[UART_MAX_CH];

extern UART_HandleTypeDef huart4;
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart7;
extern UART_HandleTypeDef huart8;
extern UART_HandleTypeDef huart9;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart6;
extern UART_HandleTypeDef huart10;

bool uartInit(void)
{
  for (int i = 0; i < UART_MAX_CH; i++)
  {
    uart_tbl[i].is_open = false;
    uart_tbl[i].baud = 57600;
  }

  return true;
}

bool uartOpen(uint8_t ch, uint32_t baud)
{
  bool ret = false;

  switch (ch)
  {
  case _DEF_UART1:
    uart_tbl[ch].type = UART_HW_TYPE_USB;
    uart_tbl[ch].baud = baud;
    uart_tbl[ch].is_open = true;

  case _DEF_UART2:
    // MX_USART1_UART_Init();  already init in bspInit()
    is_open[ch] = true;
    ret = true;
    break;
  }

  return ret;
}

bool uartClose(uint8_t ch)
{
  return true;
}

uint32_t uartAvailable(uint8_t ch)
{
  uint32_t ret = 0;

  switch (ch)
  {
  case _DEF_UART1:
    ret = cdcAvailable();
    break;
  }

  return ret;
}

bool uartFlush(uint8_t ch)
{
  uint32_t pre_time;

  pre_time = millis();
  while (uartAvailable(ch))
  {
    if (millis() - pre_time >= 10)
    {
      break;
    }
    uartRead(ch);
  }

  return true;
}

uint8_t uartRead(uint8_t ch)
{
  uint8_t ret = 0;

  switch (ch)
  {
  case _DEF_UART1:
    ret = cdcRead();
    break;
  }

  return ret;
}

uint32_t uartWrite(uint8_t ch, uint8_t *p_data, uint32_t length)
{
  HAL_StatusTypeDef status;
  uint32_t ret = 0;

  switch (ch)
  {
  case _DEF_UART1:
    ret = cdcWrite(p_data, length);
    break;
  case _DEF_UART2:
    status = HAL_UART_Transmit_DMA(&huart1, p_data, length, 100);
    if (status == HAL_OK)
      return length;
  }

  return ret;
}

uint32_t uartPrintf(uint8_t ch, const char *fmt, ...)
{
  char buf[256];
  va_list args;
  int len;
  uint32_t ret;

  va_start(args, fmt);
  len = vsnprintf(buf, 256, fmt, args);

  ret = uartWrite(ch, (uint8_t *)buf, len);

  va_end(args);

  return ret;
}

uint32_t uartGetBaud(uint8_t ch)
{
  uint32_t ret = 0;

  switch (ch)
  {
  case _DEF_UART1:
    ret = cdcGetBaud();
    break;
  }

  return ret;
}

#endif

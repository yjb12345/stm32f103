/*
 * hw.c
 *
 *  Created on: Jul 5, 2024
 *      Author: A
 */


#include "hw.h"


void hwInit(void)
{
  bspInit();

}

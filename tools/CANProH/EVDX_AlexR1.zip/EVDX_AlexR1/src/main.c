/*
 * main.c
 *
 *  Created on: Jul 5, 2024
 *      Author: A
 */

#include "main.h"

int main(void)
{
    hwInit();
    // apInit();
    // apMain();

    printf("main called\n\r");

    osKernelInitialize();
    /* Call init function for freertos objects (in cmsis_os2.c) */
    // MX_FREERTOS_Init();

    EVSE_Init();
    EVSE_Start();

    osKernelStart();

    while (1)
    {
    }
}

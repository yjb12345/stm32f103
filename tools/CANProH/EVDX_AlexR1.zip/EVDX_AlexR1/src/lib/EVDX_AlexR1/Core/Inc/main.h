/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SPI6_NSS_Pin GPIO_PIN_4
#define SPI6_NSS_GPIO_Port GPIOE
#define PWM_EN_Pin GPIO_PIN_13
#define PWM_EN_GPIO_Port GPIOC
#define LOCKED_Pin GPIO_PIN_14
#define LOCKED_GPIO_Port GPIOC
#define PHY_RESET_Pin GPIO_PIN_1
#define PHY_RESET_GPIO_Port GPIOB
#define SPI4_NSS_1_Pin GPIO_PIN_15
#define SPI4_NSS_1_GPIO_Port GPIOE
#define SPI4_NSS_Pin GPIO_PIN_10
#define SPI4_NSS_GPIO_Port GPIOB
#define DI_1_Pin GPIO_PIN_14
#define DI_1_GPIO_Port GPIOB
#define DI_2_Pin GPIO_PIN_15
#define DI_2_GPIO_Port GPIOB
#define DI_3_Pin GPIO_PIN_8
#define DI_3_GPIO_Port GPIOD
#define DI_4_Pin GPIO_PIN_9
#define DI_4_GPIO_Port GPIOD
#define DI_5_Pin GPIO_PIN_10
#define DI_5_GPIO_Port GPIOD
#define DI_6_Pin GPIO_PIN_11
#define DI_6_GPIO_Port GPIOD
#define DI_7_Pin GPIO_PIN_12
#define DI_7_GPIO_Port GPIOD
#define DI_8_Pin GPIO_PIN_13
#define DI_8_GPIO_Port GPIOD
#define DOUT_1_Pin GPIO_PIN_14
#define DOUT_1_GPIO_Port GPIOD
#define DOUT_2_Pin GPIO_PIN_15
#define DOUT_2_GPIO_Port GPIOD
#define DOUT_3_Pin GPIO_PIN_2
#define DOUT_3_GPIO_Port GPIOG
#define DOUT_4_Pin GPIO_PIN_3
#define DOUT_4_GPIO_Port GPIOG
#define DOUT_5_Pin GPIO_PIN_4
#define DOUT_5_GPIO_Port GPIOG
#define DOUT_6_Pin GPIO_PIN_5
#define DOUT_6_GPIO_Port GPIOG
#define DOUT_7_Pin GPIO_PIN_6
#define DOUT_7_GPIO_Port GPIOG
#define DOUT_8_Pin GPIO_PIN_7
#define DOUT_8_GPIO_Port GPIOG
#define E2P_WP_Pin GPIO_PIN_8
#define E2P_WP_GPIO_Port GPIOG
#define UART4_DE_Pin GPIO_PIN_8
#define UART4_DE_GPIO_Port GPIOC
#define UART3_DE_Pin GPIO_PIN_15
#define UART3_DE_GPIO_Port GPIOA
#define UART5_DE_Pin GPIO_PIN_0
#define UART5_DE_GPIO_Port GPIOD
#define UART2_DE_Pin GPIO_PIN_1
#define UART2_DE_GPIO_Port GPIOD
#define nLED_S1_Pin GPIO_PIN_3
#define nLED_S1_GPIO_Port GPIOD
#define nLED_S2_Pin GPIO_PIN_4
#define nLED_S2_GPIO_Port GPIOD
#define nLED_S3_Pin GPIO_PIN_7
#define nLED_S3_GPIO_Port GPIOD
#define nLED_S4_Pin GPIO_PIN_11
#define nLED_S4_GPIO_Port GPIOG
#define nLED_S5_Pin GPIO_PIN_15
#define nLED_S5_GPIO_Port GPIOG
#define nLED_S6_Pin GPIO_PIN_3
#define nLED_S6_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
